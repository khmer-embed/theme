<?php
/**
 * Template Name: Continue Watching (history)
 *
 * @package Kiranime
 */

get_header( 'single' ); ?>
<?php get_template_part( 'template-parts/sections/component/use', 'user-heading' ); ?>

<section class="lg:w-3/4 w-full mli-auto">
	<h2 class="text-2xl plb-5 lg:pli-0 leading-10 font-medium mbe-5 flex items-center gap-4">
		<span class="material-icons-round text-3xl">
			restore
		</span>
		<?php the_title(); ?>
	</h2>
	<div id="continue-watching" class="mlb-5"></div>
</section>

<?php get_footer(); ?>
