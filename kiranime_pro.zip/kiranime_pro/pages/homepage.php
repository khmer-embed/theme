<?php
/**
 * Template Name: Homepage
 *
 * @package Kiranime
 */

get_header();

Kira_Utility::show( 'template-parts/packs/file', 'homepage' );

get_footer();
