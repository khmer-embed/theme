<?php
/**
 * Template Name: Advanced Search
 *
 * @package Kiranime
 */

get_header();
$params = $_GET;

$search_queries = [
	'keyword'  => sanitize_text_field( trim( ( get_query_var( 's_keyword' ) ) ? get_query_var( 's_keyword' ) : '' ) ),
	'page'     => sanitize_text_field( ! empty( $params['asp'] ) ? intval( $params['asp'] ) : 1 ),
	'status'   => Kira_Utility::sanitize_text_array( ! empty( $params['s_status'] ) && is_array( $params['s_status'] ) ? $params['s_status'] : [] ),
	'order'    => sanitize_text_field( $params['s_order'] ?? 'desc' ),
	'orderby'  => sanitize_text_field( $params['s_orderby'] ?? 'popular' ),
	'genre'    => Kira_Utility::sanitize_text_array( ! empty( $params['s_genre'] ) && is_array( $params['s_genre'] ) ? $params['s_genre'] : [] ),
	'producer' => Kira_Utility::sanitize_text_array( ! empty( $params['s_producer'] ) && is_array( $params['s_producer'] ) ? $params['s_producer'] : [] ),
	'studio'   => Kira_Utility::sanitize_text_array( ! empty( $params['s_studio'] ) && is_array( $params['s_studio'] ) ? $params['s_studio'] : [] ),
	'licensor' => Kira_Utility::sanitize_text_array( ! empty( $params['s_licensor'] ) && is_array( $params['s_licensor'] ) ? $params['s_licensor'] : [] ),
	'year'     => sanitize_text_field( ! empty( $params['s_year'] ) ? $params['s_year'] : '' ),
	'type'     => Kira_Utility::sanitize_text_array( ! empty( $params['s_type'] ) ? $params['s_type'] : [] ),
	'season'   => sanitize_text_field( ! empty( $params['s_season'] ) ? $params['s_season'] : '' ),
];

$q       = new Kira_Query( [], 'anime', false, true );
$r       = $q->advanced_search_first_page( $search_queries );
$queries = Kira_Utility::get_advanced_search_queries( $search_queries );

?>
<script>
	var krSconf = "<?php echo base64_encode( json_encode( $queries ) ); ?>";
	var firstPage = <?php echo json_encode( $r['pagination'] ); ?>;
</script>
<div id="first_load_result" class="hidden">
<?php if ( $r['data'] ) : ?>
	<?php echo $r['data']; ?>
	<?php endif; ?>
</div>
<section class="mbs-0 min-h-screen pbs-17 lg:pbs-10 w-11/12 mli-auto" id="advanced-search">
</section>
<?php
get_footer();
