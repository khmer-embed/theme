<?php
/**
 * Template Name: User notification
 *
 * @package Kiranime
 */

if ( ! is_user_logged_in() ) {
	wp_redirect( home_url( '/' ) );
	exit();
}
get_header( 'single' );
$notifications = Kiranime_Notification::get();

?>
<?php get_template_part( 'template-parts/sections/component/use', 'user-heading' ); ?>

<section class="lg:w-9/12 w-full mli-auto">
	<h2 class="text-2xl plb-5 lg:pli-0 leading-10 font-medium mbe-5 flex items-center gap-4">
		<span class="material-icons-round text-3xl">
			notifications
		</span>
		<?php the_title(); ?>
	</h2>
	<div id="notification" class="mlb-5 max-h-[400px] overflow-y-scroll overflow-x-hidden">
		<?php if ( $notifications ) : ?>
			<div>
				<?php foreach ( $notifications as $notif ) : ?>
					<div class="relative pis-32 w-full p-5 bg-overlay mbe-2 bg-opacity-75 group">
						<a href="<?php echo $notif['url']; ?>" class="w-28 absolute inset-y-0 start-0 overflow-hidden">
							<?php echo $notif['featured']; ?>
						</a>
						<div class="text-xs mbe-1"><?php echo $notif['published']; ?></div>
						<div class="mbe-5 font-medium text-sm lg:text-xl leading-normal line-clamp-2">
							<a href="<?php echo $notif['url']; ?>">
								<span class="text-accent">
									<?php echo $notif['title']; ?>
								</span> -
								<?php
								/* translators: 1: episode number */
								printf( esc_html__( 'Episode %1$s Available NOW!', 'kiranime' ), $notif['number'] )
								?>
								</a>
						</div>
						<div class="text-sm">
							<?php
							$current_link = '<a href="' . $notif['url'] . '">' . __( 'here', 'kiranime' ) . '</a>';
							/* translators: 1: "here" html tag */
							printf( esc_html__( 'Click %1$s to watch it now.', 'kiranime' ), $current_link );
							?>
						</div>
					</div>
				<?php endforeach; ?>
			</div>
		<?php endif; ?>
	</div>
</section>

<?php get_footer(); ?>
