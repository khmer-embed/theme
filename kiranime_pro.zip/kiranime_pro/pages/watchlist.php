<?php
/**
 * Template Name: User Watch List Page
 *
 * @package Kiranime
 */

$is_public       = get_query_var( 'is_public' ) ? get_query_var( 'is_public' ) : false;
$user_identifier = get_query_var( 'user_identifier' );
$user            = false;

if ( ! $is_public && ! is_user_logged_in() ) {
	wp_redirect( '/' );
	exit();
}

$user = $is_public && $user_identifier ? ( is_numeric( $user_identifier ) ? get_userdata( $user_identifier ) : get_user_by( 'login', $user_identifier ) ) : wp_get_current_user();

if ( ! $user ) {
	wp_redirect( '/' );
	exit();
}

$share_url = Kira_Utility::page_link( 'pages/watchlist.php' ) . $user->user_login . '/';

Kiranime_Watchlist::metadata( $user );

get_header( 'single' );

$scripts = 'let animewatchlistparam = "all";';

if ( $is_public && get_current_user_id() !== $user_identifier ) {
	$scripts .= 'let public_watchlist = Number("' . $user->ID . '");';
}

?>
<?php get_template_part( 'template-parts/sections/component/use', 'user-heading', $is_public ? [ 'public' => $user->ID ] : [] ); ?>
<section class="w-full lg:w-3/4 mli-auto min-h-[75svh]">
	<h2 class="text-lg lg:text-2xl pli-2 md:pli-0 plb-5 lg:pli-0 leading-10 font-medium md:mbe-5 flex items-center gap-4">
		<span class="material-icons-round text-3xl">
			favorite
		</span>

		<?php _e( 'Watch List', 'kiranime' ); ?>
	</h2>
	<script>
		<?php echo $scripts; ?>
	</script>
	<div class="flex flex-wrap sm:flex-nowrap items-center justify-center lg:justify-start sm:gap-4 mbe-5 lg:mb-0">
		<span class="block min-w-fit"><?php _e( 'Share this playlist:', 'kiranime' ); ?></span>
		<div class="flex justify-start items-center flex-col sm:flex-row gap-2 lg:gap-0">
			<span data-share-url class="text-xs md:text-sm"><?php echo $share_url; ?></span>
			<span data-copy-share-url="icon" class="material-icons-round text-lg mis-2 cursor-pointer">content_copy</span>
			<span data-copy-share-url="copied" class="hidden text-sm lg:mis-1"><?php _e( 'URL Copied', 'kiranime' ); ?></span>
		</div>
	</div>
	<div id="watchlist-content" class="md:mlb-5 pli-2 md:pli-0"></div>
</section>
<script>
	const shares = document.querySelector('[data-copy-share-url="icon"]');
	shares.addEventListener('click', async e => {
		e.preventDefault();
		if (!navigator.clipboard) {
			alert('Your browser does not support clipboard!');
			return;
		}
		await navigator?.clipboard?.writeText(document.querySelector('[data-share-url]').textContent);
		document.querySelectorAll('[data-copy-share-url]').forEach(e => e.classList.add('text-accent-2'));
		document.querySelector('[data-copy-share-url="copied"]').classList.remove('hidden');
		setTimeout(() => {
			document.querySelector('[data-copy-share-url="copied"]').classList.add('hidden');
			document.querySelectorAll('[data-copy-share-url]').forEach(e => e.classList.remove(
				'text-accent-2'));
		}, 2000);
	})
</script>
<?php get_footer(); ?>
