<?php
/**
 * Template Name: News Archive Template
 *
 * @package Kiranime
 */

get_header( 'single' );
$sidebar_active = is_active_sidebar( 'archive-sidebar' );
$newspage       = ( get_query_var( 'paged' ) ) ? get_query_var( 'paged' ) : 1;
$cache          = new Kiranime_Cache( 'archive_data_news_' );
$cached         = $cache->get( $newspage );
if ( false === $cached ) :
	$news = new WP_Query(
		[
			'post_type'      => 'post',
			'posts_per_page' => 7,
			'paged'          => $newspage,
			'order'          => 'DESC',
			'orderby'        => 'date',
		]
	);

	ob_start();
	?>
		<div class="mbs-17"></div>
	<div class="mbe-17 lg:flex items-start justify-between plb-4 mli-auto w-full gap-5">
		<section class="w-full 
		<?php
		if ( $sidebar_active ) {
								echo 'main-width';
		} else {
			echo 'lg:pli-12';
		}
		?>
								">
			<h1 class="mbe-4 text-2xl font-semibold leading-10 text-accent">
				<?php _e( 'All News', 'kiranime' ); ?>
			</h1>
			<div class="space-y-5">
				<?php
				foreach ( $news->posts as $data ) :
					?>
					<article <?php post_class( 'w-full lg:flex gap-10 py-5 border-b border-gray-400 border-opacity-75', $data->ID ); ?>>
						<a href="<?php the_permalink( $data->ID ); ?>" class="w-full lg:w-1/4 lg:min-w-25 h-auto max-h-60 overflow-hidden relative block">
							<?php if ( has_post_thumbnail( $data->ID ) ) : ?>
								<?php echo get_the_post_thumbnail( post:$data->ID, attr: [ 'class' => ' object-cover w-full h-full' ] ); ?>
							<?php endif; ?>
						</a>
						<div class="w-full lg:w-3/4 space-y-5 lg:space-y-2 mt-5 lg:mt-0">
							<a href="<?php the_permalink( $data->ID ); ?>">
								<h3 class="text-2xl font-semibold"><?php echo esc_attr( $data->post_title ); ?></h3>
							</a>
							<div class="text-sm font-normal truncate lg:max-w-[50svw]">
								<?php echo wp_kses( $data->post_content, [] ); ?>
							</div>
							<span class="inline-block text-sm text-accent"><?php /* Translators: relative time. */ printf( __( 'Published %1$s ago.', 'kiranime' ), Kira_Utility::get_relative_time( strtotime( $data->post_date ) ) ); ?></span>
						</div>
					</article>
				<?php endforeach; ?>
			</div>
			<?php
				echo paginate_links(
					array(
						'base'         => str_replace( 999999999, '%#%', esc_url( get_pagenum_link( 999999999 ) ) ),
						'total'        => $news->max_num_pages,
						'current'      => max( 1, get_query_var( 'paged' ) ),
						'format'       => '?paged=%#%',
						'show_all'     => false,
						'type'         => 'list',
						'end_size'     => 2,
						'mid_size'     => 1,
						'prev_next'    => false,
						'add_args'     => false,
						'add_fragment' => '',
					)
				);
			?>
		</section>
		<?php if ( $sidebar_active ) : ?>
			<aside class="w-full sidebar-width p-4 mbs-5 lg:mbs-0">
				<?php dynamic_sidebar( 'archive-sidebar' ); ?>
			</aside>
		<?php endif; ?>
	</div>
 
	<?php
		$cached = ob_get_clean();
		$cache->set( $newspage, $cached, get_option( '__kira_cache_time', 300 ) );
endif;
echo $cached;
get_footer();
?>
