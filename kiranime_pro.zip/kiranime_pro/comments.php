<?php

/**
 * If the current post is protected by a password and
 * the visitor has not yet entered the password we will
 * return early without loading the comments.
 */
if ( post_password_required() ) {
	return;
}

$need_login = false;
/**
 * is comments need user to logged in
 */
if ( get_option( 'comment_registration' ) ) {
	$need_login = get_option( 'comment_registration', false );
}
if ( is_user_logged_in() ) {
	$user     = get_userdata( get_current_user_id() );
	$username = $user->display_name;
}
?>

<style>
	ol.comment-list ol.children {
		margin-block: 0.75rem !important;
	}

	ol.children li~.comment-respond {
		margin-block-end: .75rem;
	}

	#comments #reply-title {
		padding-block: 0;
		padding-block-end: .5rem;
	}

	ol.children {
		padding-block-end: .75rem;
	}

	ol.children ol.children:last-child {
		padding-block-end: 0;
	}
</style>
<div id="comments" class="comments-area mlb-8">

	<?php
	if ( ( is_user_logged_in() || ! $need_login ) ) {
		comment_form(
			[
				'class_submit'  => 'bg-accent-3 hover:bg-accent-4 text-text-color cursor-pointer rounded font-medium text-[0.925rem] plb-2 pli-4',
				'comment_field' => '<textarea id="comment" name="comment" required="true" class="bg-tertiary border-none outline-none focus:ring ring-accent-3 mlb-2 w-full plb-2 pli-3 rounded" aria-required="true" row="10"></textarea>',
				'logged_in_as'  => isset( $username ) ? sprintf(
					'<p class="logged-in-as">%s</p>',
					sprintf(
						/* translators: 1: User name, 2: Edit user link, 3: Logout URL, 4: html data attribute */
						__( 'Logged in as %1$s. <a href="%2$s">Edit your profile</a>. <a href="%3$s" %4$s>Log out?</a>' ),
						$username,
						Kira_Utility::page_link( 'pages/profile.php' ),
						'#',
						"data-comment-logout-trigger=''"
					)
				) : '',
			]
		);
	} else {
		?>
		<div>
			<h3 id="reply-title" class="comment-reply-title"><?php _e( 'Leave a reply', 'kiranime' ); ?></h3>
			<span class="block">
				<?php
				$link = '<a href="#" class="text-accent-2" data-comment-login-button>' . __( 'logged in', 'kiranime' ) . '</a>';
				/* translators: "logged in" */
				printf( esc_html__( 'You must be %1$s to post a comment', 'kiranime' ), $link );
				?>
			</span>
		</div>
		<?php
	}
	if ( have_comments() ) :
		?>
		<div class=" flex items-center justify-start mbe-3 mbs-4 relative before:inset-y-0 before:start-0 before:absolute before:w-1 before:block before:bg-accent-3 font-medium pis-4 min-h-full bg-gradient-to-tr from-secondary/20">
			<h2 class="w-full block leading-[3rem]">
				<?php
				printf(
					_nx( 'One comment', '%1$s comments', get_comments_number(), 'comments title', 'kiranime' ),
					number_format_i18n( get_comments_number() ),
					get_the_title()
				);
				?>
			</h2>
		</div>

		<ol class="comment-list">
			<?php
			wp_list_comments(
				array(
					'style'       => 'ol',
					'short_ping'  => true,
					'avatar_size' => 56,
					'callback'    => 'kiranime_better_comments',
				)
			);
			?>
		</ol>

	<?php endif; ?>

	<?php if ( get_comment_pages_count() > 1 && get_option( 'page_comments' ) ) : ?>

		<nav class="comment-navigation" id="comment-nav-above">

			<h1 class="screen-reader-text"><?php esc_html_e( 'Comment navigation', 'kiranime' ); ?></h1>

			<?php if ( get_previous_comments_link() ) { ?>
				<div class="nav-previous">
					<?php previous_comments_link( __( '&larr; Older Comments', 'kiranime' ) ); ?>
				</div>
			<?php } ?>

			<?php if ( get_next_comments_link() ) { ?>
				<div class="nav-next">
					<?php next_comments_link( __( 'Newer Comments &rarr;', 'kiranime' ) ); ?>
				</div>
			<?php } ?>

		</nav><!-- #comment-nav-above -->

	<?php endif; ?>

	<?php if ( ! comments_open() && get_comments_number() && post_type_supports( get_post_type(), 'comments' ) ) : ?>
		<p class="no-comments"><?php esc_html_e( 'Comments are closed.', 'kiranime' ); ?></p>
	<?php endif; ?>


</div>
