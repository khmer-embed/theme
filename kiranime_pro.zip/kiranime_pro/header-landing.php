<!DOCTYPE html>
<html <?php language_attributes(); ?>>

<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="profile" href="http://gmpg.org/xfn/11">
	<?php kiranime_show_ads( '__ads_header', true ); ?>
	<?php wp_head(); ?>
</head>

<body <?php body_class( 'bg-primary text-text-color antialiased font-montserrat' ); ?>>
	<?php wp_body_open(); ?>
