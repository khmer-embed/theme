<?php

get_header( 'single' );
$sidebar_active = is_active_sidebar( 'archive-sidebar' );
$current        = get_queried_object();
$id             = get_queried_object_id();
$page           = ( get_query_var( 'tag_page' ) ) ? get_query_var( 'tag_page' ) : 1;
$cache          = new Kiranime_Cache( 'archive_data_' . $id . '_' . $page );
if ( false === ( $tax_page = $cache->get( '' ) ) ) :
	$tax_name = 'post_tag';
	$animes   = new Kira_Query(
		[
			'paged'          => $page,
			'posts_per_page' => get_theme_mod( '__archive_count', 24 ),
			'tag_id'         => $id,
		]
	);

	ob_start();
	?>
	<?php if ( get_theme_mod( '__show_share_button', 'show' ) === 'show' ) : ?>
		<style>
			:root {
				--justify-space: 
				<?php
				echo $animes->count > 7 ? 'space-around' : 'flex-start';
				?>
				;
			}
		</style>
		<div class="mbs-17 inline-block mbe-5 bg-darkest w-full">
			<div class="pli-4">
				<div class="pli-5 plb-0 relative flex items-center gap-5">
					<div class="block text-xs pis-5 plb-1 relative border-s-2 border-accent">
						<span class="text-sm font-semibold text-accent">
							<?php printf( esc_html__( 'Share %1$s', 'kiranime' ), get_bloginfo( 'name' ) ); ?>
						</span>
						<p class="mbe-0"><?php _e( 'to your friends', 'kiranime' ); ?></p>
					</div>
					<?php get_template_part( 'template-parts/sections/component/use', 'share' ); ?>
				</div>
			</div>
		</div>
	<?php else : ?>
		<div class="mbs-17"></div>
	<?php endif; ?>
	<div class="mbe-17 lg:flex items-start justify-between plb-4 mli-auto w-full gap-5">
		<section class="w-full <?php echo $sidebar_active ? 'main-width' : 'lg:pli-12'; ?>">
			<h1 class="mbe-4 text-2xl font-semibold leading-10 text-accent">
				<?php echo ucfirst( $current->name ); ?>
			</h1>
			<div class="grid grid-anime-auto gap-4">
				<?php
				if ( $animes->animes ) :
					get_template_part(
						'template-parts/sections/listing/use',
						'grid',
						[
							'animes'     => $animes->animes,
							'is_archive' => true,
						]
					);
				endif;
				?>
			</div>
			<ul class="page-numbers">

				<?php
				$data = paginate_links(
					array(
						'base'         => '%_%',
						'total'        => $animes->pages,
						'current'      => max( 1, get_query_var( 'tag_page' ) ),
						'format'       => '?tag_page=%#%',
						'show_all'     => false,
						'type'         => 'array',
						'end_size'     => 2,
						'mid_size'     => 1,
						'prev_next'    => false,
						'add_args'     => false,
						'add_fragment' => '',
					)
				);
				foreach ( ( $data ?? [] ) as $key => $v ) :
					echo '<li>';
					$link = str_replace( '?tag_page=' . $page, '', get_pagenum_link( false ) );
					if ( $key === 0 ) {
						echo preg_replace( '/href=\"(.*)\"/', "href='$link'", $v );
					} else {
						echo $v;
					}
					echo '</li>';
				endforeach;
				?>
			</ul>

		</section>
		<?php if ( $sidebar_active ) : ?>
			<aside class="w-full sidebar-width p-4 mbs-5 lg:mbs-0">
				<?php dynamic_sidebar( 'archive-sidebar' ); ?>
			</aside>
		<?php endif; ?>
	</div>

	<?php
	$tax_page = ob_get_clean();
	$cache->set( '', $tax_page, get_option( '__kira_cache_time', 300 ) );
endif;
echo $tax_page;
get_footer();
?>
