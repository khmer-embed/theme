</main>
<?php do_action( 'kiranime_show_ads', '__ads_footer', true ); ?>
<?php $footer_image = get_theme_mod( '__footer_image' ); ?>
<footer class=" max-w-[120rem] mli-auto text-start relative z-39 bg-cover after:absolute after:w-full after:inset-0 after:bg-gradient-to-tr after:from-primary after:to-primary/70" style="background: <?php echo $footer_image ? 'url(' . $footer_image . ') center center no-repeat' : ''; ?> #2a2c31; ">
	<div class="plb-8 pli-5 relative z-40">
		<div class="sm:mbe-5 pbe-5 sm:border-b border-gray-400 border-opacity-40 sm:max-w-max sm:mli-auto lg:mli-0 lg:justify-start flex flex-col sm:flex-row items-center  w-full">
			
				<?php
				if ( get_theme_mod( 'custom_logo' ) ) {
					the_custom_logo();
				} else {
					?>
					<a href="/" id="logo-footer" class="block sm:inline-block sm:mie-10 mbe-5 sm:mbe-0" title="<?php echo get_bloginfo( 'name' ); ?>">
									
						<?php echo get_bloginfo( 'name' ); ?>
					</a>
					<?php
				}
				?>
			<div class="sm:pis-8 sm:border-s border-gray-400 border-opacity-40 flex gap-5 items-center">
				<div class="hidden sm:block w-max">
					<span class="block text-xs"><?php esc_html_e( 'Join Now', 'kiranime' ); ?></span>
					<span class="block text-sm">
						<?php echo get_bloginfo( 'name' ); ?>
					</span>
				</div>
				<div class="flex items-center justify-center sm:justify-start flex-wrap md:flex-nowrap gap-2 sm:gap-4">
					<?php
					if ( get_theme_mod( '__show_social_link', 'show' ) === 'show' ) :
						$socials = Kira_Utility::social();
						foreach ( $socials as $key => $val ) :
							if ( ! empty( $val['link'] ) ) :
								if ( 'instagram' === $key ) :
									?>
									<div>
										<a href="<?php echo esc_url( $val['link'] ); ?>" class="w-10 h-10 flex items-center justify-center rounded-sm icon-instagram" target="_blank">
											<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-instagram w-5 h-5 icon-instagram">
												<rect x="2" y="2" width="20" height="20" rx="5" ry="5"></rect>
												<path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"></path>
												<line x1="17.5" y1="6.5" x2="17.5" y2="6.5"></line>
											</svg>
										</a>
									</div>
								<?php else : ?>
									<div>
										<a href="<?php echo esc_url( $val['link'] ); ?>" class="w-10 h-10 flex items-center justify-center rounded-sm" target="_blank" style="background: <?php echo $val['color']; ?>;">
											<svg xmlns="http://www.w3.org/2000/svg" class="w-5 h-5" viewBox="<?php echo $val['vbox']; ?>">
												<path fill="currentColor" d="<?php echo $val['icon']; ?>" />
											</svg>
										</a>
									</div>
									<?php
								endif;
							endif;
						endforeach;
					endif;
					?>
				</div>
			</div>
		</div>
			<?php
			$page_link = Kira_Utility::page_link( 'pages/az-list.php' );
			if ( $page_link ) :
				?>
			<div class="mbe-3 hidden sm:block sm:text-center lg:text-start">
				<div class="block mbe-3">
					<span class="inline-block pie-5 mie-5 border-e border-gray-400 border-opacity-40 leading-4 text-xl font-semibold"><?php _e( 'A-Z LIST', 'kiranime' ); ?></span>
					<span class="text-xs"><?php _e( 'Searching anime order by alphabet name A to Z.', 'kiranime' ); ?></span>
				</div>
				<ul class="mbs-2 m-0 p-0 list-none">
					<?php
					$alphabet = [ 'All', '#', '0-9', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z' ];

					foreach ( $alphabet as $key => $value ) {
						$the_link = match ( $key ) {
							0 => $page_link,
							1 => $page_link . '?letter=other',
							default => $page_link . '?letter=' . $value
						};
						$text = match ( $key ) {
							0 => 'All',
							1 => '#',
							default => $value
						};

						echo '<li class="mie-3 mbe-3 inline-block"><div class="text-sm plb-1 pli-2 bg-opacity-4 hover:bg-accent-3 bg-secondary rounded-sm cursor-pointer" data-alphabet-link="' . esc_url( $the_link ) . '" rel="nofollow noopener noreferrer ">' . esc_html( $text ) . '</div></li>';
					}
					?>
				</ul>
			</div>
			<?php endif; ?>
		<?php if ( has_nav_menu( 'footer' ) ) : ?>
			<div class="flex items-center gap-5 mbe-3 justify-center md:justify-start">
				<?php
				wp_nav_menu(
					[
						'theme_location'  => 'footer',
						'container_class' => 'w-full menu-footer',
						'menu_class'      => 'flex text-sm p-0 m-0 items-center gap-2 flex-wrap md:flex-nowrap lg:flex-start justify-center lg:justify-start',
					]
				)
				?>
			</div>
		<?php endif; ?>
		<!-- credit start -->
		<?php
		if ( ( $credit = get_theme_mod( '__footer_credit', false ) ) && ! empty( $credit ) ) :
			echo $credit;
		else :
			?>
			<div class="text-xs  text-text-color text-opacity-80 text-center md:text-start">
				<?php
				/* translators: 1: sitename */
				printf( esc_html__( '%1$s does not store any files on our server, we only linked to the media which is hosted on 3rd party services.', 'kiranime' ), get_bloginfo( 'name' ) );
				?>
			</div>
			<p class="text-xs  text-text-color text-opacity-80 mbe-3 text-center md:text-start">©
				<?php echo get_bloginfo( 'name' ); ?> | presented by
				<?php
				if ( is_home() || is_page_template( 'pages/homepage.php' ) ) :
					?>
					<a href="https://tukutema.com/product/kiranime" title="Tukutema - premium WordPress theme">Tukutema</a>
				<?php else : ?>
					<span>Tukutema</span>
				<?php endif; ?>
			</p> 
		<?php endif; ?>
		<!-- credit end -->
	</div>
</footer>
<?php wp_footer(); ?>
</body>

</html>
