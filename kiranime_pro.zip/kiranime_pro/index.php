<?php
$is_landing    = get_theme_mod( '__is_landing', false );
$header_footer = $is_landing ? 'landing' : '';
$template      = $is_landing ? 'landing' : 'homepage';
get_header( $header_footer );

get_template_part( 'template-parts/packs/file', $template );

get_footer( $header_footer );
