</body>
<footer class="w-full plb-5 md:pli-10 md:plb-10">
	<span class="w-full block text-center font-medium text-accent">
		<span class="rtl:hidden">©<?php echo gmdate( 'Y' ); ?></span>
		<span class="rtl:order-2"><?php echo get_bloginfo( 'name' ); ?> | <?php esc_html_e( 'All rights reserved.', 'kiranime' ); ?></span>
	</span>
</footer>
<?php
wp_footer()
?>
