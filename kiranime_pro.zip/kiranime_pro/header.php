<?php
$main_class = 'use-narrow';
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>

<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<?php kiranime_show_ads( '__ads_header', true ); ?>
	<?php wp_head(); ?>
</head>

<body <?php body_class( 'bg-primary text-text-color antialiased font-montserrat' ); ?>>
	<?php wp_body_open(); ?>
	<div id="history-area"></div>
	<header id="header-data" class="bg-opacity-0 h-[50px] md:h-[70px] max-w-[120rem] mli-auto bg-primary text-text-color text-sm relative md:fixed xl:pli-8 4xl:pli-0 inset-0 z-999 leading-5 p-0 text-start transition-all duration-200 <?php echo is_admin_bar_showing() ? 'md:mbs-[2.875rem] lg:mbs-8' : ''; ?>">
		<?php Kira_Utility::show( 'template-parts/sections/site', 'header' ); ?>
	</header>

	<!-- login modal -->
	<?php Kira_Utility::show( 'template-parts/sections/component/auth', 'form' ); ?>
	<?php Kira_Utility::show( 'template-parts/sections/component/use', 'floating-sidebar' ); ?>
	<main class="<?php echo $main_class; ?> min-h-screen overflow-visible overflow-x-hidden z-40 mbe-10">
