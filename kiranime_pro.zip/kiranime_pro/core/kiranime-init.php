<?php


/**
 * Kiranime_Init class.
 *
 * @package Kiranime
 */
class Kiranime_Init {

	/**
	 * Kiranime_Init constructor.
	 */
	public function __construct() {

		$required_files = glob( KIRA_DIR . '/**/*.php' );
		foreach ( $required_files as $file ) {
			require_once $file;
		}

		// post-type.
		require_once KIRA_DIR . '/posttype.php';

		// taxonomies.
		require_once KIRA_DIR . '/taxonomies.php';

		// enqueue scripts.
		add_action( 'wp_enqueue_scripts', [ $this, 'enqueue_kiranime_frontend' ] );
		add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_kiranime_backend' ] );

		// add filter.
		add_filter( 'nav_menu_css_class', [ $this, 'navigation_li_class' ], 10, 4 );
		add_filter( 'nav_menu_submenu_css_class', [ $this, 'navigation_submenu_class' ], 10, 3 );
		add_filter( 'wp_nav_menu', [ $this, 'navigation_ul_class' ] );

		// remove default images.
		add_filter( 'intermediate_image_sizes_advanced', [ $this, 'remove_default_image' ] );

		// theme setup.
		add_action( 'after_setup_theme', [ $this, 'kiranime_theme_setup' ] );

		// advanced search.
		add_filter( 'query_vars', [ $this, 'advanced_search_variables' ] );

		// add filter for comments link.
		add_filter( 'comment_form_logged_in', [ $this, 'comment_link' ], 10, 3 );

		// initialize widget.
		add_action( 'widgets_init', [ $this, 'load_widget_class' ] );

		add_action( 'after_switch_theme', [ $this, 'ceck_change_theme' ] );

		// disable block editor.
		add_filter( 'use_block_editor_for_post_type', [ $this, 'disable_block_editor' ], 10, 2 );

		// redirect wp default login page.
		add_action( 'init', [ $this, 'disable_default_login_page' ], 10 );

		// preload modules.
		add_filter( 'script_loader_tag', [ $this, 'add_type_attribute' ], 10, 3 );

		add_action(
			'save_post_anime',
			function ( $id ) {
				$anime = new Anime( $id );
				return $anime->save_post_anime();
			},
			10
		);

		add_action(
			'save_post_episode',
			function ( $id, $post, $update ) {
				$episode = new Episode( $id );
				return $episode->save_post_episode( $post, $update );
			},
			10,
			3
		);

		add_action(
			'transition_post_status',
			function ( $old, $new, $post ) {
				if ( 'episode' !== $post?->post_type || 'publish' === $old || 'publish' !== $new ) {
					return $post->ID;
				}
				$episode = new Episode( $post->ID );
				return $episode->publish_scheduled( $old, $new, $post );
			},
			10,
			3
		);

		add_action( 'add_meta_boxes', fn () => new Kiranime_MetaBox() );

		// rewrite rule for watchlist.
		add_action(
			'init',
			function () {
				add_rewrite_rule( '(.?.+?)(?:/([^/]+))?/?$', 'index.php?pagename=$matches[1]&is_public=$matches[2]&user_identifier=$matches[2]', 'top' );
			}
		);

		// register kiranime endpoint.
		add_action(
			'rest_api_init',
			fn()=> ( new Kiranime_Endpoint() )?->register_routes()
		);

		add_action( 'init', [ $this, 'check_theme_update_schedule' ] );
		add_action( 'kiranime_check_update', [ $this, 'is_there_new_update' ] );

		add_filter( 'admin_post_thumbnail_html', [ $this, 'admin_post_thumbnail_' ] );
		add_filter( 'post_thumbnail_html', [ $this, 'post_thumbnail_html' ], 10, 2 );

		$updated = get_option( 'kiranime_update_available' );
		$theme   = wp_get_theme();
		$version = $theme->parent() ? $theme->parent()->get( 'Version' ) : $theme->get( 'Version' );
		if ( $updated && version_compare( $version, $updated['version'] ) === -1 ) {
			add_action( 'admin_notices', [ $this, 'create_new_update_notification' ], 10, 1 );
		}

		new Kiranime_Ajax();
		new Kira_Options();
	}

	/**
	 * Enqueues scripts and styles for the front-end.
	 *
	 * @return void
	 */
	public function enqueue_kiranime_frontend() {
		// Load theme textdomain.
		load_theme_textdomain( 'kiranime', get_template_directory() . '/languages' );

		// Enqueue Material Icons style.
		wp_enqueue_style( 'material-icons', 'https://fonts.googleapis.com/icon?family=Material+Icons', [], KIRA_VER );

		// Enqueue Montserrat font style.
		wp_enqueue_style( 'montserrat-font', 'https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;500;600;700;800;900&display=swap', [], KIRA_VER );
		wp_add_inline_style( 'montserrat-font', Kira_Utility::get_color_variables() );

		// Define dependencies array.
		$deps = [];

		// Check if lazy load is enabled.
		if ( get_option( 'kira_use_lazy_load' ) ) {
			// Enqueue lazy load script.
			wp_enqueue_script( 'lazy-load-js', KIRA_URI . '/core/helper/lazysizes.min.js', [], KIRA_VER, true );
		}

		// Check if Kiranime is in development mode.
		if ( KIRA_MODE ) {
			$assets  = json_decode( file_get_contents( KIRA_ASSETS . '/manifest.json' ), true );
			$version = $assets['hash'] ?: KIRA_VER;
			wp_enqueue_style( 'kiranime-style', KIRA_URI . '/assets/style.css', [], $version );
			wp_enqueue_script( 'kiranime-frontend', KIRA_URI . '/assets/kiranime-frontend.js', [], $version, true );
		} else {
			$loads = [ 'kiranime-frontend', '@vite/client' ];
			$local = 'http://localhost:3000/';
			foreach ( $loads as $load ) {
				$link = $local . $load;
				wp_enqueue_script( 'kira-' . $load, $link, $deps, KIRA_VER, true );
			}
		}

		// Check if comments are open and thread comments are enabled.
		if ( is_singular() && comments_open() && ( get_option( 'thread_comments' ) === 1 ) ) {
			// Enqueue comment reply script.
			wp_enqueue_script( 'comment-reply', '/wp-includes/js/comment-reply.min.js', array(), KIRA_VER, true );
		}

		// Enqueue JavaScript holder script.
		wp_enqueue_script( 'kira-js-holder', KIRA_URI . '/core/helper/jsholder.js', [], KIRA_VER, false );

		// Define watchlist types as JSON.
		$lists = json_encode( Kiranime_Watchlist::get_static_types() );

		// Define other variables.
		$js_config     = get_option( gtAcCLK( 3 ), '' );
		$logged_in     = is_user_logged_in();
		$inline_script = $this->is_active();
		$site_url      = get_site_url();
		$use_recaptcha = get_option( '__use_recaptcha', false ) ? 1 : 0;
		$site_rest_url = get_site_url( path: '/wp-json/kiranime/v1/' );
		$ajax_url      = admin_url( 'admin-ajax.php' );
		$custom_avatar = get_option( '__enable_custom_avatar', '' );
		$sitekey       = '';
		if ( $use_recaptcha ) {
			$sitekey = get_option( 'kiranime_recaptcha_sitekey' );
		}

		// Add inline script with variables.
		wp_add_inline_script( 'kira-js-holder', 'var WatchlistTypes = ' . $lists . ';var enableCustomAvatar = "' . $custom_avatar . '";var current_user_id = parseInt("' . get_current_user_id() . '");var isloggedIn = ' . json_encode( $logged_in ) . ';var js_configs = "' . $js_config . '";var inline_scripts=JSON.parse("' . $inline_script . '");var use_captcha=JSON.parse("' . $use_recaptcha . '");var site_url="' . $site_url . '";var sitekey="' . $sitekey . '";var site_rest_url="' . $site_rest_url . '";var ajax_url="' . $ajax_url . '";', 'before' );

		// Load JSON translation.
		$this->load_json_translation();
	}

	/**
	 * Loads JSON translation file based on the current locale.
	 *
	 * This function checks if a translation file exists for the current locale in the 'languages' directory.
	 * If the file exists, it retrieves the content and adds it as an inline script to the 'kira-js-holder' script.
	 *
	 * @return void
	 */
	public function load_json_translation() {
		$lang_file = get_template_directory() . '/languages/' . get_locale() . '.json';
		if ( file_exists( $lang_file ) ) {
			$is_translate_exist = file_get_contents( $lang_file );

			wp_add_inline_script( 'kira-js-holder', 'var tranlationData = ' . $is_translate_exist, 'after' );
		}
	}

	/**
	 * Adds a script tag to the header based on the provided type, handle, and source.
	 *
	 * This function checks if the handle contains the string 'kiranime'. If it does,
	 * it modifies the source URL based on the KIRA_MODE constant. If KIRA_MODE is false,
	 * it removes the 'ver' query parameter from the source URL.
	 *
	 * @param string $t The type attribute of the script tag.
	 * @param string $h The handle of the script tag.
	 * @param string $s The source URL of the script tag.
	 *
	 * @return string The modified script tag with the updated source URL.
	 */
	public function add_type_attribute( string $t, string $h, string $s ) {
		if ( str_contains( $h, 'kiranime' ) ) {
			if ( ! KIRA_MODE ) {
				$s = remove_query_arg( 'ver', $s );
			}

			$t = '<script type="module" id="' . $h . '" src="' . esc_url( $s ) . '"></script>';
		}

		return $t;
	}

	/**
	 * This function is responsible for enqueuing a custom JavaScript file based on the provided argument.
	 *
	 * @param string $args The name of the JavaScript file to enqueue. This argument should be a valid file name
	 *                      without the file extension.
	 *
	 * @return void This function does not return any value.
	 *
	 * @since 1.0.0
	 */
	public static function custom_queue( string $args ) {
		wp_enqueue_script( "kiranime-$args", KIRA_URI . '/assets/' . $args . '.js', [ 'kira-js-holder' ], KIRA_VER, true );
	}

	/**
	 * Enqueue scripts and styles on administration pages
	 *
	 * @param string $hook The hook name for the current page.
	 * @return void
	 */
	public function enqueue_kiranime_backend( string $hook ) {
		if ( stripos( $hook, 'kiranime_tools' ) !== false || ( isset( $_GET['post_type'] ) && in_array( $_GET['post_type'], [ 'anime', 'episode' ] ) && ! in_array( $hook, [ 'edit.php', 'edit-tags.php' ] ) ) || ( 'post.php' === $hook && isset( $_GET['action'] ) && 'edit' === $_GET['action'] ) ) {

			wp_enqueue_style( 'material-icons', 'https://fonts.googleapis.com/icon?family=Material+Icons', [], KIRA_VER, 'all' );
			wp_add_inline_style( 'material-icons', Kira_Utility::get_color_variables() );

			if ( KIRA_MODE ) {
				$assets  = json_decode( file_get_contents( KIRA_ASSETS . 'manifest.json' ), true );
				$version = $assets['hash'] ?: KIRA_VER;
				wp_enqueue_style( 'kiranime-style', KIRA_URI . '/assets/style.css', [], $version );
				wp_enqueue_script( 'kiranime-backend', KIRA_URI . '/assets/kiranime-backend.js', [], $version, true );
			} else {
				$loads = [ '@vite/client', 'kiranime-backend' ];
				$local = 'http://localhost:3000/';
				foreach ( $loads as $load ) {
					$link = $local . $load;
					wp_enqueue_script( 'kira-' . $load, $link, [], KIRA_VER, true );
				}
			}

			// Inline scripts.
			wp_enqueue_script( 'kira-js-holder', KIRA_URI . '/core/helper/jsholder.js', [], KIRA_VER, false );
			$js_config      = get_option( gtAcCLK( 3 ), '' );
			$tmdbdeflang    = get_option( '__u_def_language', 'en' );
			$site_url       = get_site_url();
			$site_rest_url  = get_site_url( path: '/wp-json/kiranime/v1/' );
			$ajax_url       = admin_url( 'admin-ajax.php' );
			$external_image = get_option( '__kira_external_images', false );

			wp_add_inline_script( 'kira-js-holder', 'var external_image = ' . intval( $external_image ) . ';var current_user_id = parseInt("' . get_current_user_id() . '");var tmdblang = "' . $tmdbdeflang . '";var js_configs = "' . $js_config . '";var site_url="' . $site_url . '";var site_rest_url="' . $site_rest_url . '";var ajax_url="' . $ajax_url . '";var isloggedIn = ' . json_encode( 'true' ) . '', 'before' );

			// load json translation.
			$this->load_json_translation();
		}
	}

	/**
	 * Modifies the CSS classes for list items in the navigation menu.
	 *
	 * This function adds custom classes to the list item classes based on the provided arguments.
	 * It checks if the 'li_class' and 'li_class_$depth' properties are set in the $args object, and adds
	 * those classes to the $classes array. It also checks if the current menu item is being displayed,
	 * and adds the 'active' class to the $classes array. If the theme location is 'header-menu', it adds
	 * the 'nav-link' class to the $classes array.
	 *
	 * @param array $classes The current CSS classes for the list item.
	 * @param mixed $item The menu item object.
	 * @param mixed $args The arguments passed to the function.
	 * @param mixed $depth The depth of the menu item.
	 *
	 * @return array The modified CSS classes for the list item.
	 */
	public function navigation_li_class( array $classes, mixed $item, mixed $args, mixed $depth ) {
		if ( isset( $args->li_class ) ) {
			$classes[] = $args->li_class;
		}

		if ( isset( $args->{"li_class_$depth"} ) ) {
			$classes[] = $args->{"li_class_$depth"};
		}

		if ( in_array( 'current-menu-item', $classes ) ) {
			$classes[] = 'active ';
		}

		if ( 'header-menu' === $args->theme_location ) {
			$classes[] = 'nav-link';
		}

		return $classes;
	}

	/**
	 * Modifies the CSS classes for submenu items in the navigation menu.
	 *
	 * This function adds custom classes to the submenu item classes based on the provided arguments.
	 * It checks if the 'submenu_class' and 'submenu_class_$depth' properties are set in the $args object, and adds
	 * those classes to the $classes array.
	 *
	 * @param array  $classes The current CSS classes for the submenu item.
	 * @param object $args The arguments passed to the function.
	 * @param mixed  $depth The depth of the submenu item.
	 *
	 * @return array The modified CSS classes for the submenu item.
	 */
	public function navigation_submenu_class( array $classes, object $args, mixed $depth ): array {
		if ( isset( $args->submenu_class ) ) {
			$classes[] = $args->submenu_class;
		}

		if ( isset( $args->{"submenu_class_$depth"} ) ) {
			$classes[] = $args->{"submenu_class_$depth"};
		}

		return $classes;
	}

	/**
	 * Modifies the HTML class for the unordered list in the navigation menu.
	 *
	 * @param string $ulclass The current HTML class for the unordered list.
	 *
	 * @return string The modified HTML class for the unordered list.
	 */
	public function navigation_ul_class( $ulclass ) {
		return preg_replace( '/<a /', '<a class="nav-link"', $ulclass );
	}

	/**
	 * Modifies the default image sizes for WordPress.
	 *
	 * This function removes the 'small', 'medium', 'medium_large', 'large', '1536x1536', and '2048x2048' image sizes from the
	 * default image sizes array.
	 *
	 * @param array $sizes The default image sizes array.
	 *
	 * @return array The modified image sizes array.
	 */
	public function remove_default_image( $sizes ) {
		return array_filter( $sizes, fn ( $val ) => ! in_array( $val, [ 'small', 'medium', 'medium_large', 'large', '1536x1536', '2048x2048' ] ) );
	}

	/**
	 * Modifies the query variables for the advanced search functionality.
	 *
	 * This function adds custom query variables to the $vars array to handle the advanced search functionality.
	 * It adds variables for keyword, genre, type, status, season, year, orderby, order, artist, personal watchlist,
	 * user identifier, public status, and tag page.
	 *
	 * @param array $vars The current query variables.
	 *
	 * @return array The modified query variables.
	 */
	public function advanced_search_variables( $vars ) {
		$vars[] = 's_keyword';
		$vars[] = 's_genre';
		$vars[] = 's_type';
		$vars[] = 's_status';
		$vars[] = 's_season';
		$vars[] = 's_year';
		$vars[] = 's_orderby';
		$vars[] = 's_order';
		$vars[] = 'arty';
		$vars[] = 'kira_pwl';
		$vars[] = 'user_identifier';
		$vars[] = 'is_public';
		$vars[] = 'tag_page';

		return $vars;
	}

	/**
	 * Check if the theme is active.
	 *
	 * @return int 1 if active, 0 otherwise.
	 */
	public function is_active() {
		$result        = 0;
		$active_status = get_option( 'is_active', 0 );

		if ( ! $active_status ) {
			$result = 0;
		}

		return $result;
	}

	/**
	 * Filters the SQL WHERE clause for the search functionality.
	 *
	 * @param string   $where The current SQL WHERE clause.
	 * @param WP_Query $wp_query The current WP_Query object.
	 *
	 * @return string The modified SQL WHERE clause.
	 */
	public static function title_filter( $where, $wp_query ) {
		global $wpdb;
		$search_term = $wp_query->get( 'keyword' );
		if ( ! empty( $search_term ) ) {
			$where .= ' AND ' . $wpdb->posts . '.post_title LIKE \'%' . esc_sql( $wpdb->esc_like( $search_term ) ) . '%\'';
		}
		return $where;
	}

	/**
	 * Initialize the theme and setup the necessary functions.
	 *
	 * @since 1.0.0
	 */
	public function kiranime_theme_setup() {
		/**
		 * Add theme support for title tag.
		 */
		add_theme_support( 'title-tag' );

		/**
		 * Register navigation menus.
		 */
		register_nav_menus(
			array(
				'footer'         => 'Footer Menu',
				'header_side'    => 'Header Side Menu',
				'landing_header' => 'Landing Header',
			)
		);

		/**
		 * Add theme support for HTML5 markup.
		 */
		add_theme_support(
			'html5',
			array(
				'search-form',
				'comment-form',
				'comment-list',
				'caption',
			)
		);

		/**
		 * Register widget areas for homepage main listing and main sidebar.
		 */
		register_sidebar(
			array(
				'name'          => 'Main Homepage Anime List',
				'id'            => 'homepage-main-list',
				'description'   => 'Homepage Main List',
				'before_widget' => '',
				'after_widget'  => '<div class="mbe-6"></div>',
				'before_title'  => '',
				'after_title'   => '',
			)
		);

		register_sidebar(
			array(
				'name'          => 'Homepage Sidebar',
				'id'            => 'homepage-sidebar',
				'description'   => 'Homepage sidebar',
				'before_widget' => '',
				'after_widget'  => '<div class="mbe-6"></div>',
				'before_title'  => '<div class="text-2xl leading-10 font-semibold plb-5 lg:p-0 m-0 text-accent-3 mbe-4">',
				'after_title'   => '</div>',
			)
		);

		/**
		 * Register widget areas for single anime.
		 */
		register_sidebar(
			array(
				'name'          => 'Single Info Sidebar',
				'id'            => 'anime-info-sidebar',
				'description'   => 'Show widget on anime/episode',
				'before_widget' => '',
				'after_widget'  => '<div class="mbe-6"></div>',
				'before_title'  => '<div class="text-2xl leading-10 font-semibold plb-5 lg:p-0 m-0 text-accent-3 mbe-4">',
				'after_title'   => '</div>',
			)
		);

		/**
		 * Register widget areas for pages.
		 */
		register_sidebar(
			array(
				'name'          => 'Archive Sidebar',
				'id'            => 'archive-sidebar',
				'description'   => 'Show widget on archive',
				'before_widget' => '',
				'after_widget'  => '<div class="mbe-6"></div>',
				'before_title'  => '<div class="text-2xl leading-10 font-semibold plb-5 lg:p-0 m-0 text-accent-3 mbe-4">',
				'after_title'   => '</div>',
			)
		);

		/**
		 * Register widget areas for news or posts.
		 */
		register_sidebar(
			array(
				'name'          => 'Article Sidebar',
				'id'            => 'article-sidebar',
				'description'   => 'Show widget on article archive and single',
				'before_widget' => '',
				'after_widget'  => '<div class="mbe-6"></div>',
				'before_title'  => '<div class="text-2xl leading-10 font-semibold plb-5 lg:p-0 m-0 text-accent-3 mbe-4">',
				'after_title'   => '</div>',
			)
		);

		/**
		 * Add theme support for custom logo.
		 */
		add_theme_support( 'custom-logo' );

		/**
		 * Add theme support for post thumbnails.
		 */
		add_theme_support( 'post-thumbnails' );

		/**
		 * Add theme support for align-wide and wp-block-styles.
		 */
		add_theme_support( 'align-wide' );
		add_theme_support( 'wp-block-styles' );

		/**
		 * Add theme support for editor-styles and load editor-style.css.
		 */
		add_theme_support( 'editor-styles' );
		add_editor_style( 'css/editor-style.css' );

		/**
		 * Load theme textdomain for localization.
		 */
		load_theme_textdomain( 'kiranime', get_template_directory() . '/languages' );

		/**
		 * Hide admin bar for users who cannot edit posts.
		 */
		if ( ! current_user_can( 'edit_posts' ) ) {
			show_admin_bar( false );
		}

		/**
		 * Add custom image sizes.
		 */
		add_image_size( 'kirathumb', 448 );
		add_image_size( 'smallthumb', 96 );
		add_image_size( 'featuredthumb', 552 );
		add_image_size( name: 'spotlight_thumb', height: 720 );
	}

	/**
	 * Loads the required widget files and registers the widgets.
	 *
	 * @since 1.0.0
	 */
	public function load_widget_class() {
		// Require the necessary widget files.
		require_once KIRA_DIR . '/widget/genre-list.php';
		require_once KIRA_DIR . '/widget/most-popular.php';
		require_once KIRA_DIR . '/widget/popular-list.php';
		require_once KIRA_DIR . '/widget/module/listing.php';
		require_once KIRA_DIR . '/widget/module/scheduled.php';
		require_once KIRA_DIR . '/widget/module/news.php';

		// Register the widgets.
		register_widget( 'Kiranime_Popular_List' );
		register_widget( 'Kiranime_Genre_List' );
		register_widget( 'Kiranime_Most_Popular' );
		register_widget( 'Listing_Module' );
		register_widget( 'News_Module' );
		register_widget( 'Kira_Scheduled_Module' );
	}

	/**
	 * Performs necessary checks and actions to ensure the theme's functionality.
	 *
	 * This function initializes taxonomies and pages required for the theme.
	 *
	 * @return bool Always returns true.
	 */
	public function ceck_change_theme() {
		// Call the private methods to initialize taxonomies and pages.
		$this->check_taxonomies_creation()->check_pages_creation();
		return true;
	}

	/**
	 * Check if the theme is active.
	 *
	 * @return void
	 */
	public function check_active() {
		$_inline_act = get_option( '__a_act_inline', false );
		if ( ! $_inline_act ) {
			update_option( 'is_active', 0 );
			return;
		}

		$res = wp_remote_post(
			'https://tukutema.com/api/check_theme',
			[
				'headers' => [
					'Content-type' => 'Application/json',
				],
				'body'    => json_encode(
					[
						'key'   => get_option( '__a_act_key', '' ),
						'email' => get_option( '__a_act_email', '' ),
						'ref'   => get_bloginfo( 'url' ),
						'theme' => 'kiranime',
					]
				),
			]
		);

		$header = wp_remote_retrieve_headers( $res );
		$value  = wp_remote_retrieve_body( $res );
		if ( ! isset( $header['t-x-auth-theme'] ) || empty( $header['t-x-auth-theme'] ) || ! $value['status'] ) {
			update_option( 'is_active', 0 );
			delete_option( '__a_act_inline' );
			return;
		}

		update_option( 'is_active', 1 );
		return;
	}

	/**
	 * Initializes and registers custom taxonomies for the Kiranime theme.
	 *
	 * This function iterates through an array of required taxonomies and their terms.
	 * For each term, it checks if the term already exists in the taxonomy.
	 * If the term does not exist, it inserts the term into the taxonomy.
	 *
	 * @return Kiranime_Init $this The instance of the Kiranime_Init class.
	 */
	private function check_taxonomies_creation() {
		$required_terms = [
			'status'          => [
				'upcoming'  => __( 'Upcoming', 'kiranime' ),
				'airing'    => __( 'Airing', 'kiranime' ),
				'completed' => __( 'Completed', 'kiranime' ),
			],
			'anime_attribute' => [
				'sub' => 'SUB',
				'dub' => 'DUB',
				'hd'  => 'HD',
			],
			'episode_type'    => [
				'series' => __( 'TV', 'kiranime' ),
				'movie'  => __( 'Movie', 'kiranime' ),
			],
			'anime_type'      => [
				'ova'     => __( 'OVA', 'kiranime' ),
				'movie'   => __( 'movie', 'kiranime' ),
				'ona'     => __( 'ONA', 'kiranime' ),
				'tv'      => __( 'TV', 'kiranime' ),
				'special' => __( 'Special', 'kiranime' ),
			],
		];

		foreach ( $required_terms as $name => $terms ) {
			foreach ( $terms as $term_slug => $term_name ) {
				$exist = get_term_by( 'slug', $term_slug, $name );

				if ( empty( $exist ) ) {
					wp_insert_term(
						$term_name,
						$name,
						[
							'slug' => $term_slug,
						]
					);
				}
			}
		}

		return $this;
	}

	/**
	 * Initializes and registers custom pages for the Kiranime theme.
	 *
	 * This function iterates through an array of required pages and their templates.
	 * For each page, it checks if the page already exists.
	 * If the page does not exist, it inserts the page into the database with the specified title, type, content, status, name, and template.
	 *
	 * @return Kiranime_Init $this The instance of the Kiranime_Init class.
	 */
	private function check_pages_creation() {
		$pages = [
			'profile'           => __( 'My Profile', 'kiranime' ),
			'continue-watching' => __( 'Continue Watching', 'kiranime' ),
			'watchlist'         => __( 'Watchlist', 'kiranime' ),
			'notification'      => __( 'Notification', 'kiranime' ),
			'search'            => __( 'Advanced Search', 'kiranime' ),
			'az-list'           => __( 'A-Z Anime List', 'kiranime' ),
			'homepage'          => __( 'Home', 'kiranime' ),
		];

		foreach ( $pages as $page_template => $page_name ) {
			$template = 'pages/' . $page_template . '.php';
			$exist    = Kira_Utility::page_link( $template );

			if ( empty( $exist ) ) {
				wp_insert_post(
					[
						'post_title'    => $page_name,
						'post_type'     => 'page',
						'post_content'  => '',
						'post_status'   => 'publish',
						'post_name'     => $page_template,
						'page_template' => $template,
					]
				);
			}
		}

		return $this;
	}

	/**
	 * Replaces the comment author link with a link to the user's profile page.
	 *
	 * @param string $html The original HTML for the comment author link.
	 * @param array  $commenter An array containing the commenter's information.
	 * @param int    $user_identity The user's ID.
	 *
	 * @return string The modified HTML for the comment author link.
	 */
	public function comment_link( $html, $commenter, $user_identity ) {
		$profile_page = Kira_Utility::page_link( 'pages/profile.php' );
		$url          = '<a href="' . $profile_page . '">$1</a>';
		return preg_replace( '#<a href="[^"]*" aria-label="[^"]*">([^<]*)</a>#', $url, $html, 1 );
	}

	/**
	 * Disables the block editor for specific post types.
	 *
	 * @param bool   $current_status The current status of the block editor.
	 * @param string $post_type      The post type being checked.
	 *
	 * @return bool The new status of the block editor. If the post type is 'anime' or 'episode', the block editor is disabled.
	 */
	public function disable_block_editor( $current_status, $post_type ) {
		if ( in_array( $post_type, [ 'anime', 'episode' ] ) ) {
			return false;
		}

		return $current_status;
	}

	/**
	 * Disables the default login page if the option 'kira_disable_login_page' is set to true.
	 *
	 * @param string $url The original URL for the login page.
	 *
	 * @return void
	 *
	 * @global string $pagenow The current page being viewed.
	 *
	 * @since 1.0.0
	 */
	public function disable_default_login_page( $url ) {
		global $pagenow;
		$disabled = get_option( 'kira_disable_login_page', false );

		$new_url = preg_replace( '/(wp-login\.php).*/', '/', $pagenow, -1, $counted );
		if ( $disabled && $counted ) {
			wp_redirect( $new_url );
			exit();
		}
	}

	/**
	 * Check if the current post type is not 'episode' and redirect to a custom 404 page.
	 *
	 * @param string|false $post_type The current post type.
	 *
	 * @return void|true
	 */
	public static function check_is_not_broken( string|false $post_type ) {
		if ( empty( $post_type ) || 'episode' !== $post_type ) {
			return true;
		}

		$is_anime_exist = get_post_meta( get_the_ID(), 'kiranime_episode_parent_id', true );
		if ( $is_anime_exist ) {
			return true;
		}
		wp_redirect( '/x-wp-not-found-episode' );
		exit();
	}

	/**
	 * Checks and schedules the theme update check event.
	 *
	 * This function checks if the 'check_kiranime_update' event is scheduled.
	 * If it's not scheduled, it schedules the event to run daily.
	 *
	 * @since 1.0.0
	 */
	public function check_theme_update_schedule() {
		if ( ! wp_next_scheduled( 'kiranime_check_update' ) ) {
			wp_schedule_event( time(), 'daily', 'kiranime_check_update' );
		}
	}
	/**
	 * Checks and schedules the theme update check event.
	 *
	 * This function sends a request to the specified URL to check for a new version of the theme.
	 * If the request is successful and the new version is available, it displays a message to the user
	 * with a link to download the new version.
	 *
	 * @return void
	 */
	public function is_there_new_update() {
		$req = wp_remote_get( 'https://tukutema.com/api/theme/check?theme=kiranime&version=' . KIRA_VER );
		if ( is_wp_error( $req ) ) {
			return;
		}

		$res = wp_remote_retrieve_body( $req );
		$res = json_decode( $res, true );
		if ( empty( $res['status'] ) ) {
			return;
		}
		if ( version_compare( KIRA_VER, $res['version'] ) === -1 ) {
			update_option( 'kiranime_update_available', $res );
		}
	}

	/**
	 * Displays a notification with a link to download a new version of the Kiranime theme.
	 *
	 * @param array $args Additional arguments passed to the function.
	 *
	 * @return void
	 */
	public function create_new_update_notification( $args ) {
		$options = get_option( 'kiranime_update_available' );
		if ( ! $options ) {
			return;
		}

		echo '<div class="notice notice-info kiranime-notice is-dismissible">';
		echo '<p>';
		printf( 'New Kiranime version available: %1$s, <a href=\'%2$s\'>Download Now</a>', $options['version'], 'https://tukutema.com/auth/login' );
		echo '</p>';
		echo '</div>';
	}

	public function admin_post_thumbnail_( $html ) {
		global $post;
		$type     = KiraType::fromName( get_post_type( $post->ID ) );
		$prefix   = MetaPrefix::fromName( $type->value );
		$meta_key = match ( $type ) {
			KiraType::anime => $prefix->value . 'featured',
			KiraType::episode => $prefix->value . 'thumbnail',
			default => 'kiranime_external_thumbnail',
		};
		$value = get_post_meta( $post->ID, $meta_key, true ) ?: '';
		$html .= '<div><p>' . __( 'Or', 'kiranime' ) . '</p>';
		$html .= '<p>' . __( 'Enter the url for external featured image', 'kiranime' ) . '</p>';
		$html .= '<p><input type="text" id="' . $meta_key . '" name="' . $meta_key . '" value="' . $value . '"></p>';
		if ( ! empty( $value ) && Kira_Utility::is_image( $value ) ) {
			$html .= '<p><img style="max-width:150px;height:auto;" src="' . esc_url( $value ) . '"></p>';
			$html .= '<p>' . __( 'Leave url blank to remove.', 'kiranime' ) . '</p>';
		}
		$html .= '</div>';
		return $html;
	}

	public static function post_thumbnail_html( $html, $post_id ) {
		$post_type = get_post_type( $post_id );
		$type      = KiraType::fromName( $post_type );
		if ( empty( $type ) ) {
			return $html;
		}
		$prefix   = MetaPrefix::fromName( $type->value );
		$meta_key = match ( $type ) {
			KiraType::anime => $prefix->value . 'featured',
			KiraType::episode => $prefix->value . 'thumbnail',
			default => '',
		};
		$url = get_post_meta( $post_id, $meta_key, true );
		if ( empty( $url ) || ! Kira_Utility::is_image( $url ) ) {
			return $html;
		}
		$alt  = get_post_field( 'post_title', $post_id ) . ' ' . __( 'thumbnail', 'kiranime' );
		$attr = array( 'alt' => $alt );
		$attr = apply_filters( 'wp_get_attachment_image_attributes', $attr, null );
		$attr = array_map( 'esc_attr', $attr );
		$html = sprintf( '<img src="%s"', esc_url( $url ) );
		foreach ( $attr as $name => $value ) {
			$html .= " $name=" . '"' . $value . '"';
		}
		$html .= ' />';
		return $html;
	}
}

/**
 * Initialize Kiranime
 */
new Kiranime_Init();
