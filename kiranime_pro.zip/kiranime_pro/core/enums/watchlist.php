<?php

enum WatchlistType: string {

	case plan_to_watch = 'plan_to_watch';
	case watching      = 'watching';
	case completed     = 'completed';
	case on_hold       = 'on_hold';
	case dropped       = 'dropped';

	public static function fromName( string $name ): self|false {
		foreach ( self::cases() as $prefix ) {
			if ( $name === $prefix->name ) {
				return $prefix;
			}
		}
		return false;
	}
}
