<?php

enum KiraType: string {

	case anime   = 'anime';
	case episode = 'episode';

	public static function fromName( string|null $name ): self|null {
		if ( empty( $name ) ) {
			return null;
		}
		foreach ( self::cases() as $type ) {
			if ( $name === $type->name ) {
				return $type;
			}
		}

		return null;
	}
}
