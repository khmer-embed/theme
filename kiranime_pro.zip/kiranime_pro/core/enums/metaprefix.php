<?php

enum MetaPrefix: string {

	case anime   = 'kiranime_anime_';
	case episode = 'kiranime_episode_';

	public static function fromName( string|null $name ): self|null {
		if ( empty( $name ) ) {
			return null;
		}
		foreach ( self::cases() as $prefix ) {
			if ( $name === $prefix->name ) {
				return $prefix;
			}
		}

		return null;
	}
}
