<?php

function load_widget_news_data( array $opts = [] ): string|false {
	$cache     = new Kiranime_Cache( 'widget_block' );
	$cache_key = md5( json_encode( $opts ) );
	$cached    = $cache->get( $cache_key );

	if ( $cached ) {
		return $cached;
	}

	$data_opts = [
		'posts_per_page'      => $opts['post_count'] ?? 5,
		'post_type'           => 'post',
		'orderby'             => 'date',
		'order'               => 'desc',
		'no_found_rows'       => true,
		'ignore_sticky_posts' => true,
	];

	$query        = new WP_Query( $data_opts );
	$archive_link = Kira_Utility::page_link( 'pages/news.php' );
	ob_start();
	?>

	<div class="w-full">
		<div class="mie-4 md:pli-5 lg:pli-0 plb-2 sm:mbe-4">
			<h2 class="text-lg lg:text-xl xl:text-2xl leading-10 font-semibold p-0 m-0 text-accent"><?php echo $opts['title'] ?? ''; ?></h2>
		</div>
		<div class="w-full news-data">
			<?php get_template_part( 'template-parts/sections/listing/use', 'news', [ 'posts' => $query->posts ] ); ?>
			<?php if ( $archive_link ) : ?>
				<a href="<?php echo esc_url( $archive_link ); ?>" target="_blank" title="<?php echo esc_attr( $opts['title'] ); ?>">
					<?php esc_attr_e( 'All News', 'kiranime' ); ?>
				</a>
			<?php endif; ?>
		</div>
	</div>

	<?php
	$result = ob_get_clean();
	$cache?->set( $cache_key, $result, 30 );
	return $result;
}
