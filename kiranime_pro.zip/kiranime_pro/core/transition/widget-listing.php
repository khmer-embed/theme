<?php

/**
 * Initializes and displays a widget listing with lazy loading capabilities.
 *
 * @param array $configs An associative array of configurations for the widget listing.
 * @return void Prints the HTML markup for the widget listing.
 * @since 1.0.0
 */
function load_init_widget_listing( $configs = [] ) {
	?>
	<div data-lazy-load-components-id="<?php echo base64_encode( json_encode( $configs ) ); ?>" data-component-name="listing" style="height: 20rem;">
		<?php get_template_part( 'template-parts/sections/component/use', 'loader' ); ?>
	</div>
	<?php
}

/**
 * Fetches and displays a widget listing based on the provided ID and configurations.
 * The function uses caching to improve performance and fetches data from the database.
 * It also handles different post types and ordering options.
 *
 * @param array $opts The unique identifier for the widget listing.
 *
 * @return string|false The HTML markup for the widget listing or false if an error occurs.
 *
 * @since 1.0.0
 */
function load_widget_listing_data( array $opts ): string|false {

	$cache = new Kiranime_Cache( 'widget_block' );
	if ( $cache->enabled ) {
		$cache_key = md5( json_encode( $opts ) );
		$cached    = $cache?->get( $cache_key );
		if ( ! empty( $cached ) ) {
			return $cached;
		}
	}
	$data_opts = array_merge(
		[
			'post_count' => 12,
			'post_type'  => 'anime',
			'orderby'    => 'popular',
			'order'      => 'desc',
			'title'      => 'new title',
		],
		$opts
	);

	if ( KiraType::anime->value === $data_opts['post_type'] ) {
		$orderby = match ( $data_opts['orderby'] ) {
			'popular' => [
				'orderby'  => 'meta_value_num',
				'meta_key' => 'total_kiranime_views',
			],
			'favorite' => [
				'orderby'  => 'meta_value_num',
				'meta_key' => 'bookmark_count',
			],
			'updated' => [
				'orderby'  => 'meta_value_num',
				'meta_key' => 'kiranime_anime_updated',
			],
			'date' => [
				'orderby' => 'date',
			],
			'title' => [
				'orderby' => 'title',
			],
			'random' => [
				'orderby' => 'rand',
			]
		};
	}
	$default_query = [
		'posts_per_page' => intval( $data_opts['post_count'] ),
		'post_type'      => $data_opts['post_type'],
		'order'          => $data_opts['order'],
	];
	$query         = match ( $data_opts['post_type'] ) {
		'episode'   => array_merge(
			$default_query,
			[
				'orderby' => 'date',
			]
		),
		'anime' => array_merge( $default_query, $orderby )
	};

	if ( KiraType::anime->value === $data_opts['post_type'] ) {
		if ( isset( $data_opts['status'] ) && ! empty( $data_opts['status'] ) ) {
			$query['tax_query'] = [
				'relation' => 'AND',
				[
					'taxonomy' => 'status',
					'field'    => 'slug',
					'terms'    => $data_opts['status'],
				],
			];
		}
		if ( isset( $data_opts['anime_type'] ) && ! empty( $data_opts['anime_type'] ) ) {
			$query['tax_query'][] = [
				'taxonomy' => 'type',
				'field'    => 'slug',
				'terms'    => $data_opts['anime_type'],
			];
		}
	}

	$s_q = [];
	foreach ( $data_opts as $key => $val ) {
		$k         = 'anime_type' === $key ? 's_type' : 's_' . $key;
		$s_q[ $k ] = $val;
	}
	unset( $s_q['s_title'], $s_q['s_post_type'], $s_q['s_post_count'], $s_q['s_display'], $s_q['s_view_more'] );
	$archive_link = ! empty( $data_opts['view_more'] ) ? $data_opts['view_more'] : Kira_Utility::page_link( 'pages/search.php' ) . '?' . http_build_query( $s_q );
	$opts         = [
		'title'   => $data_opts['title'] ?? '',
		'query'   => $query,
		'slider'  => isset( $data_opts['display'] ) ? 'slider' === $data_opts['display'] : false,
		'archive' => $archive_link,
		'loop'    => $data_opts['loop'] ?? true,
	];

	ob_start();
	get_template_part( 'template-parts/sections/home', $data_opts['post_type'] . '-listing', $opts );
	$result = ob_get_clean();
	if ( $cache->enabled ) {
		$cache?->set( $cache_key, $result, 30 );
	}
	return $result;
}

/**
 * Displays a section with recommended anime based on the provided arguments.
 *
 * @param array $args An array of arguments.
 *     @type int    $id         The ID of the post to get recommendations for.
 *     @type string $post_type  The post type to get recommendations for. Default is 'anime'.
 *     @type string $display    The display style for the recommendations. Can be 'slider' or 'grid'. Default is 'grid'.
 *
 * @return string The HTML markup for the recommended anime section.
 *
 * @since 1.0.0
 */
function load_widget_recommendations( array $args = [] ) {
	$cache = new Kiranime_Cache( 'widget_block' );

	$args['post_type'] ??= 'anime';
	$hash                = md5( json_encode( $args ) );
	$cached              = $cache->get( $hash );
	if ( $cached ) {
		return $cached;
	}

	$id         = $args['id'];
	$post_type  = $args['post_type'];
	$related_by = get_theme_mod( '__show_related_' . $post_type . '_by', 'genre' );
	$total      = get_theme_mod( '__show_related_' . $post_type . '_count', 12 );
	$title      = get_theme_mod( '__show_related_' . $post_type . '_label', __( 'Recomended For You!', 'kiranime' ) );
	$style      = $args['display'];

	$taxs = wp_get_post_terms( $id, $related_by );

	$posts = new WP_Query(
		[
			'tax_query'           => [
				'relation' => 'AND',
				[
					'taxonomy' => $related_by,
					'terms'    => array_map(
						function ( $val ) {
							return $val->term_id;
						},
						$taxs
					),
					'field'    => 'term_id',
				],
			],
			'posts_per_page'      => $total + 1,
			'orderby'             => 'rand',
			'post_type'           => 'anime',
			'post_status'         => 'publish',
			'no_found_rows'       => 1,
			'ignore_sticky_posts' => 1,
			'fields'              => 'ids',
		]
	);

	$animes = array_filter( $posts->posts, fn ( $v ) => ! in_array( $v, [ $id ] ) );
	if ( count( $animes ) > $total ) {
		array_pop( $animes );
	}
	$animes = array_map( fn ( $val ) => new Anime( $val ), $animes );
	ob_start();
	?>
	<section>
		<div class="w-full mbe-4 flex items-center justify-between mbs-10 plb-0">
			<div class="mie-4 flex justify-between items-center w-full">
				<h2 class="text-xl md:text-2xl md:leading-10 font-semibold p-0 m-0 text-accent mbe-6">
					<?php echo $title; ?>
				</h2>
				<?php if ( 'slider' === $style ) : ?>
					<div class="swiper-navigation navigate-sections navigate-recommended flex items-center justify-between gap-1 w-max">
						<div class="navigate-recommended-prev cursor-pointer group plb-1 pli-2 rounded-l hover:bg-accent-2 hover:text-text-color">
							<svg class="w-5 h-5 xl:w-6 xl:h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
								<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7">
								</path>
							</svg>
						</div>
						<div class="navigate-recommended-next cursor-pointer group plb-1 pli-2 rounded-r hover:bg-accent-2 hover:text-text-color">
							<svg class="w-5 h-5 xl:w-6 xl:h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
								<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"></path>
							</svg>
						</div>
					</div>
				<?php endif; ?>
			</div>
		</div>
		<?php if ( 'slider' !== $style ) : ?>
			<section class="grid grid-anime-auto gap-2 sm:gap-4 justify-evenly w-full flex-auto">
				<?php get_template_part( 'template-parts/sections/listing/use', 'grid', [ 'animes' => $animes ] ); ?>
			</section>
		<?php else : ?>
			<section class="w-full flex-auto">
				<div data-current-slider="recommended" data-is-loop="0" class="swiper swiper-sections swiper-recommended">
					<div class="swiper-wrapper" style="min-width: 100vw;">
						<!-- Slides -->
						<?php get_template_part( 'template-parts/sections/listing/use', 'slider', [ 'animes' => $animes ] ); ?>
					</div>
				</div>
			</section>
		<?php endif; ?>
	</section>
	<?php

	$res = ob_get_clean();
	$cache->set( $hash, $res, get_option( '__kira_cache_time', 300 ) );
	return $res;
}
