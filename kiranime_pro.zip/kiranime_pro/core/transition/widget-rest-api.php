<?php

add_action( 'rest_api_init', 'kira_widget_rest_api' );
/**
 * Registers the REST API endpoint for the Kira Widget.
 *
 * @since 1.0.0
 */
function kira_widget_rest_api() {
	$version   = '1';
	$namespace = 'kiranime/v' . $version;
	register_rest_route(
		$namespace,
		'/widget',
		[
			'methods'             => WP_REST_Server::READABLE,
			'permission_callback' => '__return_true',
			'args'                => [],
			'callback'            => 'kiranime_get_widget_data',
		]
	);
}

/**
 * Processes the REST API request for the Kira Widget and returns the appropriate data based on the provided name.
 *
 * @since 1.0.0
 *
 * @param WP_REST_Request $args The REST API request object.
 *
 * @return WP_REST_Response The response object containing the status, result, and parameters.
 */
function kiranime_get_widget_data( WP_REST_Request $args ) {
	$name   = $args['name'];
	$params = $args->get_query_params();

	$result = null;

	$result = match ( $name ) {
		'listing' => load_widget_listing_data( $params ),
		'recommended'   => load_widget_recommendations( $params ),
		'news'  => load_widget_news_data( $params ),
		default => null,
	};

	return new WP_REST_Response(
		[
			'status' => true,
			'result' => $result,
		]
	);
}
