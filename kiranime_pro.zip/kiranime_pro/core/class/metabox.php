<?php

/**
 * Class for processing metaboxes
 *
 * @package   Kiranime
 * @since   2.0.0
 * @link      https://kiranime.moe
 * @author    Dzul Qurnain
 * @license   GPL-2.0+
 */
class Kiranime_MetaBox {


	use Kira_Meta;

	/**
	 * Current post id
	 *
	 * @var string|int $id
	 */
	public string|int $id = 0;

	/**
	 * Current post with anime/episode instance
	 *
	 * @var Anime|Episode|null $instance
	 */
	public Anime|Episode|null $instance = null;

	/**
	 * Contruct the metabox instance
	 */
	public function __construct() {
		$this->init_meta_boxes();
	}

	/**
	 * Initializes meta boxes for the custom post types.
	 *
	 * @since 1.0.0
	 */
	public function init_meta_boxes() {

		add_meta_box(
			'kiranime_anime_fetch',
			__( 'Fetch Anime Info', 'kiranime' ),
			[ $this, 'anime_fetch_metabox' ],
			[ 'anime', 'movie' ]
		);
		add_meta_box(
			'kiranime_anime_metabox_id',
			__( 'Anime Info', 'kiranime' ),
			[ $this, 'anime_info_metabox' ],
			[ 'anime' ]
		);
		add_meta_box(
			'kiranime_character_data',
			__( 'Characters', 'kiranime' ),
			[ $this, 'character_info_metabox' ],
			[ 'anime' ]
		);
		add_meta_box(
			'kiranime_download_metabox',
			__( 'Download', 'kiranime' ),
			[ $this, 'download_metabox' ],
			[ 'anime', 'episode', 'movie' ]
		);

		add_meta_box(
			'kiranime_episode_metabox_parent',
			'Anime Info',
			[ $this, 'episode_anime_info_metabox' ],
			[ 'episode' ]
		);
		add_meta_box(
			'kiranime_episode_metabox_fetch',
			'Episode Info Grabber',
			[ $this, 'episode_fetch_metabox' ],
			[ 'episode' ],
		);
		add_meta_box(
			'kiranime_episode_metabox',
			'Episode Information',
			[ $this, 'episode_info_metabox' ],
			[ 'episode' ],
		);
		add_meta_box(
			'kiranime_episode_metabox_player',
			'Player Embed',
			[ $this, 'stream_metabox' ],
			[ 'episode' ],
		);
	}



	/**
	 * Displays the anime info metabox in the post editor.
	 *
	 * @param \WP_Post $post The post object being edited.
	 *
	 * @return void
	 */
	public function anime_info_metabox( \WP_Post $post ) {
		if ( ! $post ) {
			return;
		}
		$this->id = $post->ID;
		$block    = get_current_screen()->is_block_editor();

		$keys = [
			[
				'name'   => __( 'spotlight', 'kiranime' ),
				'key'    => 'spotlight',
				'detail' => '',
			],
			[
				'name'   => __( 'rate', 'kiranime' ),
				'key'    => 'rate',
				'detail' => '',
			],
			[
				'name'   => __( 'native', 'kiranime' ),
				'key'    => 'native',
				'detail' => '',
			],
			[
				'name'   => __( 'english', 'kiranime' ),
				'key'    => 'english',
				'detail' => '',
			],
			[
				'name'   => __( 'synonyms', 'kiranime' ),
				'key'    => 'synonyms',
				'detail' => '',
			],
			[
				'name'   => __( 'aired', 'kiranime' ),
				'key'    => 'aired',
				'detail' => '',
			],
			[
				'name'   => __( 'premiered', 'kiranime' ),
				'key'    => 'premiered',
				'detail' => '',
			],
			[
				'name'   => __( 'duration', 'kiranime' ),
				'key'    => 'duration',
				'detail' => '',
			],
			[
				'name'   => __( 'episodes', 'kiranime' ),
				'detail' => '',
				'key'    => 'episodes',
			],
			[
				'name'   => __( 'score', 'kiranime' ),
				'key'    => 'score',
				'detail' => '',
			],
			[
				'name'   => __( 'Trailer URL', 'kiranime' ),
				'key'    => 'trailer',
				'detail' => 'The trailer URL',
			],
			[
				'name'   => __( 'background', 'kiranime' ),
				'key'    => 'background',
				'detail' => '',
			],
		];
		$vals = [];

		if ( empty( $this->instance ) ) {
			$this->instance = new Anime( $post->ID );

			if ( empty( $this->instance->meta ) ) {
				$this->instance->gets( MetaPrefix::anime );
			}
		}

		foreach ( $keys as $meta ) {
			$meta_key = MetaPrefix::anime->value . $meta['key'];

			if ( in_array( $meta['key'], [ 'featured', 'background' ] ) ) {
				$this->instance->meta[ $meta['key'] ] = $this->instance->get( $meta_key );
			}

			$vals[ $meta_key ] = [
				'val'    => $this->instance?->meta[ $meta['key'] ] ?? '',
				'detail' => $meta['detail'],
				'name'   => $meta['name'],
			];
		} ?>
		<script>
			const is_block = parseInt("<?php echo $block ? 1 : 0; ?>");
		</script>
		<div data-anime-infomation class="w-full h-auto bg-white space-y-1">
			<?php wp_nonce_field( 'kiranime_anime_editor_nonce', 'kiranime_anime_editor_nonce' ); ?>
			<input type="hidden" name="using_block_editor" value="<?php echo json_encode( $block ); ?>">
			<?php
			foreach ( $vals as $key => $val ) :
				?>
				<?php if ( stripos( $key, 'background' ) !== false ) : ?>
					<div class="w-full h-auto p-2 lg:flex font-medium items-center space-y-1 relative">
						<label for="<?php echo $key; ?>" class="text-xs font-medium text-slate-800 active:text-slate-900 hover:text-slate-900 focus-within:text-slate-900 min-w-max lg:w-2/12 flex-shrink-0"><?php echo ucfirst( $val['name'] ); ?></label>
						<input type="text" name="<?php echo $key; ?>" id="<?php echo $key; ?>" placeholder="<?php echo $val['detail'] ? $val['detail'] : ''; ?>" class="pli-4 plb-2 text-sm font-normal text-slate-900 flex-auto" value="<?php echo $val['val'] ? $val['val'] : ''; ?>">
						<label class="pli-3 plb-1 text-white bg-accent-2 self-stretch mis-2 rounded-sm" for="upload_background_url">Upload
							Background</label>
						<input type="file" id="upload_background_url" style="display: none;">
					</div>
					<?php
					continue;
				endif;
				?>
				<?php
				if ( ! str_contains( $key, 'spotlight' ) ) {

					if ( 'kiranime_anime_synonyms' === $key && ! empty( $val['val'] ) ) {
						$val['val'] = is_string( $val['val'] ) ? $val['val'] : implode( ',', $val['val'] );
					}
					?>
					<div class="w-full h-auto p-2 lg:flex font-medium items-center space-y-1 relative">
						<label for="<?php echo $key; ?>" class="text-xs font-medium text-slate-800 active:text-slate-900 hover:text-slate-900 focus-within:text-slate-900 min-w-max lg:w-2/12 flex-shrink-0"><?php echo ucfirst( $val['name'] ); ?></label>
						<input type="text" name="<?php echo $key; ?>" id="<?php echo $key; ?>" placeholder="<?php echo $val['detail'] ? $val['detail'] : ''; ?>" class="pli-4 plb-2 text-sm font-normal text-slate-900 flex-auto" value='<?php echo esc_attr( $val['val'] ?: '' ); ?>'>
					</div>
					<?php
				} else {
					?>

					<div class="w-full h-auto p-2 lg:flex font-medium items-center space-y-1">
						<label for="<?php echo $key; ?>" class="text-xs font-medium text-slate-800 active:text-slate-900 hover:text-slate-900 focus-within:text-slate-900 min-w-max lg:w-2/12 flex-shrink-0"><?php echo ucfirst( $val['name'] ); ?></label>
						<input type="checkbox" name="<?php echo $key; ?>" id="<?php echo $key; ?>" <?php checked( ! empty( $val['val'] ) ); ?>>
					</div>
				<?php } ?>
			<?php endforeach; ?>
			<div id="season-setting-wrapper" class="w-full h-auto p-2 lg:flex font-medium items-center space-y-1">
				<button type="button" id="open-season-settings" class="w-full bg-accent-2/75 hover:bg-accent-2 py-2 flex items-center justify-center min-h-8 text-text-color font-semibold rounded">
					<?php _e( 'Season Settings', 'kiranime' ); ?>
				</button>
			</div>
			<template id="anime-input-field">
				<div class="hidden">
					<input type="text" name="" id="" class="pli-4 plb-2 text-sm font-normal text-slate-900 flex-auto" value="">
				</div>
			</template>
			<template id="anime-connector-season-field">
				<div class="modal-anime-season-field hidden fixed inset-0 z-50 max-w-full sm:max-w-md md:max-w-lg xl:max-w-2xl p-4 rounded start-1/2 top-1/2 transform -translate-x-1/2 -translate-y-1/2 border-primary/50 border-2 bg-white" style="border-style: groove;">
					<div class="w-full h-auto p-2 lg:flex font-medium items-center space-y-1 relative">
						<label for="<?php echo MetaPrefix::anime->value . 'name'; ?>" class="text-xs font-medium text-slate-800 active:text-slate-900 hover:text-slate-900 focus-within:text-slate-900 min-w-max lg:w-2/12 flex-shrink-0"><?php echo ucfirst( __( 'name', 'kiranime' ) ); ?></label>
						<div class="relative w-full">
							<input type="text" name="<?php echo MetaPrefix::anime->value . 'name'; ?>" id="<?php echo MetaPrefix::anime->value . 'name'; ?>" placeholder="season connector. For season list slider on anime page." class="pli-4 block w-full min-h-5 plb-2 pe-10 text-sm font-normal text-slate-900 flex-auto" value="<?php echo esc_attr( get_post_meta( $post->ID, MetaPrefix::anime->value . 'name', true ) ); ?>" autocomplete="off">
							<small>Write the name to search and select the title.</small>
							<span class="search-anime-name-icon absolute end-0 top-1/5 transform -translate-y-1/4 ">
								<svg xmlns="http://www.w3.org/2000/svg" class="size-6 text-primary -rotate-90 transition-transform duration-300 ease-in-out" viewBox="0 0 12 12">
									<path fill="currentColor" d="M2.22 4.47a.75.75 0 0 1 1.06 0L6 7.19l2.72-2.72a.75.75 0 0 1 1.06 1.06L6.53 8.78a.75.75 0 0 1-1.06 0L2.22 5.53a.75.75 0 0 1 0-1.06" />
								</svg>
							</span>
							<div class="w-full absolute top-[32px] rounded border-accent-2 inset-x-0 z-999 max-h-80 overflow-auto bg-white border-collapse border-2 hidden" id="anime-season-search-result">

							</div>
						</div>
					</div>
					<div class="w-full h-auto p-2 lg:flex font-medium items-center space-y-1 relative">
						<label for="<?php echo MetaPrefix::anime->value . 'season'; ?>" class="text-xs font-medium text-slate-800 active:text-slate-900 hover:text-slate-900 focus-within:text-slate-900 min-w-max lg:w-2/12 flex-shrink-0"><?php echo ucfirst( __( 'season', 'kiranime' ) ); ?></label>
						<input type="text" name="<?php echo MetaPrefix::anime->value . 'season'; ?>" id="<?php echo MetaPrefix::anime->value . 'season'; ?>" placeholder="season connector. For season list slider on anime page." class="pli-4 plb-2 text-sm font-normal text-slate-900 flex-auto" value="<?php echo esc_attr( get_post_meta( $post->ID, MetaPrefix::anime->value . 'season', true ) ); ?>">
					</div>
					<div class="p-2">
						<button id="close-modal-season-button" type="button" class="w-max px-6 bg-accent-2 flex items-center justify-center py-3 rounded font-semibold font-montserrat text-text-color relative bottom-0">Finish</button>
					</div>
				</div>
		</div>
		</template>
		</div>
		<?php
	}

	/**
	 * Displays a metabox for fetching anime data.
	 *
	 * @param WP_Post $post The WordPress post object.
	 *
	 * @return void
	 */
	public function anime_fetch_metabox( WP_Post $post ) {

		if ( ! $post ) {
			return;
		}
		$this->id = $post->ID;

		$jikan = get_option( '__a_jikan', 'https://api.jikan.moe/v4' );
		$tmdb  = get_option( '__a_tmdb' );

		if ( empty( $this->instance ) ) {
			$this->instance = new Anime( $post->ID );
			if ( empty( $this->instance->meta ) ) {
				$this->instance->gets( MetaPrefix::anime );
			}
		}

		$anime_id     = $this->instance->meta['id'] ?? '';
		$tmdb_type    = $this->instance->meta['tmdb_type'] ?? '';
		$service_name = $this->instance->meta['service_name'] ?? '';
		?>
		<div class="w-full h-auto bg-white space-y-1">
			<input type="hidden" id="jikan_url" value="<?php echo $jikan && strlen( $jikan ) > 0 ? $jikan : 'https://api.jikan.moe/v4'; ?>">
			<input type="hidden" id="tmdb_api" value="<?php echo $tmdb; ?>">
			<span data-notifications class="w-full block h-auto p-2 lg:flex text-base font-medium items-center space-y-1 error-1">

			</span>
			<div class="w-full h-auto p-2 lg:flex items-center space-y-1 gap-2">
				<label for="kiranime_anime_service_name" class="text-xs font-medium uppercase text-slate-800 active:text-slate-900 hover:text-slate-900 focus-within:text-slate-900 min-w-max lg:w-3/12 flex-shrink-0">Choose
					Service</label>
				<select name="kiranime_anime_service_name" id="kiranime_anime_service_name" class="lg:w-9/12">
					<option value="tmdb" <?php selected( $service_name, 'tmdb' ); ?> >TMDB</option>
					<option value="anilist" <?php selected( $service_name, 'anilist' ); ?> >Anilist</option>
					<option value="mal" <?php selected( $service_name, 'mal' ); ?> >MAL</option>
				</select>
			</div>
			<div data-tmdb-only class="w-full h-auto p-2 <?php echo 'tmdb' !== $service_name ? 'hidden' : 'flex'; ?> items-center space-y-1 gap-2">
				<label for="kiranime_anime_tmdb_type" class="text-xs font-medium uppercase text-slate-800 active:text-slate-900 hover:text-slate-900 focus-within:text-slate-900 min-w-max lg:w-3/12 flex-shrink-0">TMDB
					Type</label>
				<select name="kiranime_anime_tmdb_type" id="kiranime_anime_tmdb_type" class="lg:w-9/12">
					<option value="tv" <?php selected( $tmdb_type, 'tv' ); ?> >TV Series</option>
					<option value="movie" <?php selected( $tmdb_type, 'movie' ); ?>>Movie</option>
				</select>
			</div>
			<div class="w-full h-auto p-2 lg:flex items-center space-y-1 gap-2">
				<label for="kiranime_anime_id" class="text-xs font-medium uppercase text-slate-800 active:text-slate-900 hover:text-slate-900 focus-within:text-slate-900 min-w-max lg:w-3/12 flex-shrink-0">Anime ID</label>
				<input type="text" name="kiranime_anime_id" id="kiranime_anime_id" class="pli-4 plb-2 text-sm font-normal text-slate-900 flex-auto lg:w-9/12" value="<?php echo $anime_id; ?>">
			</div>
			<div class="w-max h-auto p-2 space-y-1 gap-2">
				<input type="button" name="get-anime" id="get-anime" class="pli-4 plb-2 text-sm font-normal cursor-pointer w-max text-text-color bg-accent-3 flex-auto" title="Get Anime" value="Get Anime" />
			</div>
		</div>
		<?php
	}

	/**
	 * Displays the character information metabox.
	 *
	 * @param WP_Post $post The post object.
	 *
	 * @return void
	 */
	public function character_info_metabox( WP_Post $post ) {
		if ( ! $post ) {
			return;
		}
		$this->id = $post->ID;

		if ( empty( $this->instance ) ) {
			$this->instance = new Anime( $post->ID );
			if ( empty( $this->instance->meta ) ) {
				$this->instance->gets( MetaPrefix::anime );
			}
		}

		$characters = $this->instance->meta['characters'] ?? [];
		$echo_val   = is_string( $characters ) ? $characters : json_encode( $characters );
		?>
		<script>
			<?php
			if ( $characters && ! empty( $characters ) ) {
				echo 'window.characters = ' . $echo_val . ';';
			} else {
				echo 'window.characters = null;';
			}
			?>
		</script>
		<div>
			<div id="characters-meta"></div>
		</div>
		<?php
	}


	/**
	 * Displays the download information metabox.
	 *
	 * @param WP_Post $post The post object.
	 *
	 * @return void
	 */
	public function download_metabox( WP_Post $post ) {

		if ( ! $post ) {
			return;
		}
		$this->id = $post->ID;

		$m = get_post_meta( $post->ID, 'kiranime_download_data', true );
		if ( ! empty( $m ) & '"[]"' !== $m ) {
			$downloads = is_string( $m ) ? json_decode( stripslashes( $m ) ) : null;
		} else {
			$downloads = null;
		}
		?>
		<script>
			window.downloadsData =
				<?php echo null !== $downloads && ! empty( $downloads ) ? json_encode( $downloads ) : json_encode( null ); ?>;
		</script>
		<div id="downloads-meta"></div>
		<?php
	}

	/**
	 * Displays the episode information metabox.
	 *
	 * @param WP_Post $post The post object.
	 *
	 * @return void
	 */
	public function episode_info_metabox( WP_Post $post ) {

		if ( ! $post ) {
			return;
		}
		$this->id = $post->ID;

		if ( empty( $this->instance ) ) {
			$this->instance = new Episode( $post->ID );
			if ( empty( $this->instance->meta ) ) {
				$this->instance->gets( MetaPrefix::episode );
			}
		}

		$prefix              = MetaPrefix::episode->value;
		$keys                = $this->meta_keys[ KiraType::episode->value . '_show' ];
		$vals                = [];
		$create_notification = get_post_meta( $post->ID, 'create_notification', true );
		$create_notification = ! empty( $create_notification ) ? $create_notification : 1;
		foreach ( $keys as $key ) {
			if ( 'thumbnail' === $key ) {
				continue;
			}
			$meta_key = $prefix . $key;
			if ( 'released' === $key ) {
				$vals[ $meta_key ] = $this->instance->meta[ $key ] ?? $post->post_date;
			} else {
				$vals[ $meta_key ] = $this->instance->meta[ $key ] ?? '';
			}
		}
		?>

		<div class="w-full h-auto bg-white space-y-1">
			<?php wp_nonce_field( 'kiranime_episode_editor_nonce', 'kiranime_episode_editor_nonce' ); ?>
			<input type="hidden" name="create_notification" value="<?php echo json_encode( $create_notification ); ?>">
			<?php foreach ( $vals as $key => $val ) : ?>
				<div>
					<span class="text-xs font-semibold inline-block plb-1 pli-2 rounded-t text-slate-700 bg-slate-300 uppercase w-2/12 mie-1 flex-shrink-0">
						<?php echo str_replace( $prefix, '', $key ); ?>
					</span>
					<div class="mbe-3 pbs-0 flex-auto">
						<input type="text" placeholder="Episode <?php echo str_replace( $prefix, '', $key ); ?>" name="<?php echo $key; ?>" id="<?php echo $key; ?>" value="<?php echo $val; ?>" class="pli-3 plb-3 placeholder-gray-400 text-blueGray-600 relative bg-white rounded text-sm border-none ring-1 ring-sky-200 shadow outline-none focus:outline-none focus:ring w-full" />
					</div>
				</div>
			<?php endforeach; ?>
		</div>
		<?php
	}

	/**
	 * Displays the anime information metabox in the episode editor.
	 *
	 * @param WP_Post $post The post object for which the metabox is being displayed.
	 *
	 * @return void
	 */
	public function episode_anime_info_metabox( WP_Post $post ) {

		if ( ! $post ) {
			return;
		}
		$this->id = $post->ID;

		if ( empty( $this->instance ) ) {
			$this->instance = new Episode( $post->ID );
			if ( empty( $this->instance->meta ) ) {
				$this->instance->gets( MetaPrefix::episode );
			}
		}

		$prefix = MetaPrefix::episode->value;
		$keys   = [ 'parent_id', 'parent_name', 'parent_slug' ];
		$vals   = [];

		foreach ( $keys as $key ) {
			$meta_key = $prefix . $key;

			$vals[ $meta_key ] = $this->instance->meta[ $key ] ?? '';
		}
		?>

		<div class="w-full h-auto bg-white space-y-1">
			<div>
				<span class="text-xs font-semibold inline-block plb-1 pli-2 rounded-t text-slate-700 bg-slate-300 uppercase w-2/12 mie-1 flex-shrink-0">
					Anime title
				</span>
				<div class="mbe-3 pbs-0 flex-auto relative">
					<input data-anime-name-input type="text" autocomplete="off" name="kiranime_episode_parent_name" id="kiranime_episode_parent_name" placeholder="Anime title" class="pli-3 plb-3 placeholder-gray-400 text-blueGray-600 relative bg-white rounded text-sm border-none ring-1 ring-sky-200 shadow outline-none focus:outline-none focus:ring w-full" value="<?php echo $vals['kiranime_episode_parent_name']; ?>" />
					<div class="w-full mbs-2 p-2 absolute hidden top-full start-0 flex-col gap-2 bg-white z-50" data-anime-name-result>

					</div>
					<input type="number" name="kiranime_episode_parent_id" value="<?php echo $vals['kiranime_episode_parent_id']; ?>" data-anime-id class="hidden">
					<input type="text" name="kiranime_episode_parent_slug" value="<?php echo $vals['kiranime_episode_parent_slug']; ?>" data-anime-slug class="hidden">
				</div>
			</div>


		</div>
		<?php
	}

	/**
	 * Displays the stream information metabox in the episode editor.
	 *
	 * @param WP_Post $post The post object for which the metabox is being displayed.
	 *
	 * @return void
	 */
	public function stream_metabox( WP_Post $post ) {

		if ( ! $post ) {
			return;
		}
		$this->id = $post->ID;

		$episode = new Episode( $post->ID );
		$episode->get_streams( KiraType::episode, true );
		$players = $episode->streams;
		?>
		<script>
			let players =
				<?php echo null !== $players && ! empty( $players ) ? ( is_array( $players ) ? json_encode( $players ) : $players ) : json_encode( [] ); ?>;

			players = players && typeof players === 'string' ? JSON.parse(players) : players;
		</script>
		<div id="player-meta">

		</div>
		<?php
	}

	/**
	 * Displays the episode grabber information metabox in the episode editor.
	 *
	 * @param WP_Post $post The post object for which the metabox is being displayed.
	 *
	 * @return void
	 */
	public function episode_fetch_metabox( WP_Post $post ) {

		if ( ! $post ) {
			return;
		}
		$this->id = $post->ID;

		$jikan = get_option( '__a_jikan', 'https://api.jikan.moe/v4' );
		$tmdb  = get_option( '__a_tmdb' );

		if ( empty( $this->instance ) ) {
			$this->instance = new Episode( $post->ID );
			if ( empty( $this->instance->meta ) ) {
				$this->instance->gets( MetaPrefix::episode );
			}
		}

		$fetch_meta = [ 'anime_id', 'anime_season', 'anime_type', 'tmdb_fetch_episode' ];
		$vals       = [];
		foreach ( $fetch_meta as $key ) {
			$vals[ $key ] = $this->instance->meta[ $key ] ?? '';
		}
		?>
		<div class="w-full h-auto bg-white space-y-1">
			<input type="hidden" id="jikan_url" value="<?php echo $jikan && strlen( $jikan ) > 0 ? $jikan : 'https://api.jikan.moe/v4'; ?>">
			<input type="hidden" id="tmdb_api" value="<?php echo $tmdb; ?>">
			<span data-notifications class="w-full block h-auto p-2 lg:flex text-base font-medium items-center space-y-1 error-1">

			</span>
			<div class="w-full h-auto p-2 lg:flex items-center space-y-1 gap-2">
				<label for="kiranime_episode_anime_id" class="text-xs font-medium uppercase text-slate-800 active:text-slate-900 hover:text-slate-900 focus-within:text-slate-900 min-w-max lg:w-3/12 flex-shrink-0">
					TMDB Anime ID
				</label>
				<input type="text" name="kiranime_episode_anime_id" id="kiranime_episode_anime_id" class="pli-4 plb-2 text-sm font-normal text-slate-900 flex-auto lg:w-10/12" value="<?php echo $vals['anime_id']; ?>">
			</div>
			<div class="w-full h-auto p-2 lg:flex items-center space-y-1 gap-2">
				<label for="kiranime_episode_anime_type" class="text-xs font-medium uppercase text-slate-800 active:text-slate-900 hover:text-slate-900 focus-within:text-slate-900 min-w-max lg:w-3/12 flex-shrink-0">Choose
					Type</label>
				<select name="kiranime_episode_anime_type" id="kiranime_episode_anime_type" class="lg:w-10/12">
					<option value="series" <?php selected( $vals['anime_type'], 'tv' ); ?>>TV Series</option>
					<option value="movie" <?php selected( $vals['anime_type'], 'movie' ); ?>>Movie</option>
				</select>
			</div>
			<div class="w-full h-auto p-2 lg:flex items-center space-y-1 gap-2">
				<label for="kiranime_episode_anime_season" class="text-xs font-medium uppercase text-slate-800 active:text-slate-900 hover:text-slate-900 focus-within:text-slate-900 min-w-max lg:w-3/12 flex-shrink-0">
					TMDB Anime Season
				</label>
				<input type="text" name="kiranime_episode_anime_season" id="kiranime_episode_anime_season" class="pli-4 plb-2 text-sm font-normal text-slate-900 flex-auto lg:w-10/12" value="<?php echo $vals['anime_season']; ?>">
			</div>
			<div class="w-full h-auto p-2 lg:flex items-center space-y-1 gap-2">
				<label for="kiranime_episode_tmdb_fetch_episode" class="text-xs font-medium uppercase text-slate-800 active:text-slate-900 hover:text-slate-900 focus-within:text-slate-900 min-w-max lg:w-3/12 flex-shrink-0">
					Episode Number
				</label>
				<input type="text" name="kiranime_episode_tmdb_fetch_episode" id="kiranime_episode_tmdb_fetch_episode" class="pli-4 plb-2 text-sm font-normal text-slate-900 flex-auto lg:w-10/12" value="<?php echo $vals['tmdb_fetch_episode']; ?>">
			</div>
			<div id="episode-info-notification" class="w-full hidden h-auto p-2 space-y-1 gap-2">
				<span class="text-primary border-2 border-accent"></span>
			</div>
			<div class="w-max h-auto p-2 space-y-1 gap-2">
				<input type="button" name="get-episode-info" id="get-episode-info" class="pli-4 plb-2 text-sm font-normal cursor-pointer w-max text-text-color bg-accent-3 flex-auto rounded" title="Get Episode Info" value="Get Episode Info" />
			</div>
		</div>
		<?php
	}
}
