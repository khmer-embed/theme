<?php

/**
 * Class Episode
 *
 * This class represents an episode in the Kiranime plugin.
 * It provides methods for managing episode data, taxonomies, and other related functionalities.
 */
class Episode {

	use Kira_Meta;

	/**
	 * WP_Post object for current episode
	 *
	 * @var WP_Post $post The WordPress post object representing the episode.
	 */
	public ?WP_Post $post = null;

	/**
	 * The URL of the episode.
	 *
	 * @var string|null $url
	 */
	public string|null $url = null;

	/**
	 * An array containing the taxonomies associated with the episode.
	 *
	 * @var array $taxonomies
	 */
	public array $taxonomies = [];

	/**
	 * A flag indicating whether the episode object is empty.
	 *
	 * @var bool $empty
	 */
	public bool $empty = false;

	/**
	 * The video metadata in JSON format.
	 *
	 * @var string $video_meta
	 */
	public string $video_meta = '';

	/**
	 * An array containing the streaming URLs associated with the episode.
	 *
	 * @var array $streams
	 */
	public array $streams = [];

	/**
	 * The parent URL of the episode
	 *
	 * @var string $parent_url
	 */
	public string $parent_url = '';

	/**
	 * Episode constructor.
	 *
	 * Initializes the Episode object with the given ID and update data.
	 *
	 * @param string|int $id The ID of the episode.
	 * @param array      $update The update data for the episode.
	 */
	public function __construct( public string|int $id = 0, public array $update = [] ) {
		if ( $this->id ) {
			$this->init();
		}
	}

	/**
	 * Initializes the Episode object.
	 *
	 * Retrieves the WordPress post object for the given ID and sets the URL and taxonomies.
	 *
	 * @return Episode The initialized Episode object.
	 */
	private function init(): self {
		$this->post = get_post( $this->id );

		if ( ! $this->post ) {
			$this->empty = true;
			return $this;
		}
		$this->url = get_post_permalink( $this->id );
		return $this;
	}

	/**
	 * Retrieves the taxonomies associated with the episode.
	 *
	 * Fetches the taxonomies for the given taxonomies and stores them in the $taxonomies property.
	 *
	 * @param string ...$args The taxonomies to retrieve.
	 * @return Episode The Episode object with the retrieved taxonomies.
	 */
	public function get_taxonomies( ...$args ): self {
		if ( empty( $this->id ) ) {
			return $this;
		}

		$this->taxonomies = array_reduce(
			$args,
			function ( $results, $arg ) {
				$results[ $arg ] = wp_get_post_terms( $this->id, $arg );
				return $results;
			},
			[]
		);

		return $this;
	}

	/**
	 * Updates the taxonomies associated with the episode.
	 *
	 * Sets the taxonomies for the given taxonomies based on the update data.
	 *
	 * @return Episode The Episode object with the updated taxonomies.
	 */
	public function update_taxonomies(): self {
		if ( empty( $this->id ) ) {
			return $this;
		}

		$taxonomies = [ 'episode_type' ];
		foreach ( $taxonomies as $tax ) {
			$tax_ids = [];

			if ( ! isset( $this->update[ $tax ] ) ) {
				continue;
			}

			$terms = is_array( $this->update[ $tax ] ) ? $this->update[ $tax ] : [ $this->update[ $tax ] ];
			foreach ( $terms as $term ) {
				$get_if_exist = term_exists( $term, $tax );
				$tax_ids[]    = $get_if_exist ? $get_if_exist['term_id'] : ( wp_insert_term( $term, $tax )['term_id'] ?? null );
			}

			wp_set_post_terms( $this->id, $tax_ids, $tax );
		}

		return $this;
	}

	/**
	 * Creates a new episode based on the given update data.
	 *
	 * Inserts a new episode into the WordPress database with the provided update data.
	 *
	 * @param array $updates The update data for the episode.
	 * @return Episode|null The created Episode object, or null if the update failed.
	 * @throws Exception If the update failed.
	 */
	public function create_episode( array $updates = [] ): ?self {
		if ( empty( $updates ) ) {
			return null;
		}

		$title = "{$updates['parent_name']} " . __( 'Episode', 'kiranime' ) . " {$updates['number']}";
		$slug  = get_option( '__q_use_rand_prefix', false ) ? $this->randomize_slug( true ) : sanitize_title( $title );

		$is_already_created = new WP_Query(
			[
				'post_type'      => 'episode',
				'post_status'    => 'any',
				'posts_per_page' => 1,
				'meta_query'     => [
					'relation' => 'AND',
					[
						'key'     => MetaPrefix::episode->value . 'parent_id',
						'value'   => strval( $updates['parent_id'] ),
						'compare' => '=',
					],
					[
						'key'     => MetaPrefix::episode->value . 'number',
						'value'   => strval( $updates['number'] ),
						'compare' => '=',
					],
				],
			]
		);

		$defined_release     = ! empty( $updates['released'] ) ? strtotime( str_ireplace( '/', '-', $updates['released'] ?? '' ) ) : time();
		$updates['released'] = gmdate( 'Y-m-d H:i:s', $defined_release );
		$status              = $defined_release > time()
			? ( 'draft' !== $updates['status'] ? 'future' : 'draft' )
			: match ( $updates['status'] ?? 'publish' ) {
				'draft' => 'draft',
				'pending' => 'future',
				'publish' => 'publish',
				default => 'publish',
			};

		if ( $is_already_created->post_count ) {
			$this->post = array_shift( $is_already_created->posts );
			$this->id   = $this->post->ID;

			$updated = wp_update_post(
				[
					'ID'          => $this->id,
					'post_status' => $status,
				],
				true,
				false
			);

			if ( is_wp_error( $updated ) ) {
				throw new Exception( _x( 'Update episode failed.', 'rest api return', 'kiranime' ) );
			}
		} else {
			$created = wp_insert_post(
				[
					'post_type'   => 'episode',
					'post_status' => $status,
					'post_author' => $updates['author'] ?? get_current_user_id(),
					'post_title'  => $title,
					'post_name'   => $slug,
				]
			);

			if ( is_wp_error( $created ) ) {
				throw new Exception( 'Update failed 1' );
			}

			$this->post = get_post( $created );
			$this->id   = $created;
		}

		$this->sets( KiraType::episode, $updates );

		if ( class_exists( 'Kiranime_plugin' ) ) {
			$this->set( 'kira_need_grab', time() );
		}

		$thumbnail = $updates['thumbnail'] ?? null;
		$this->set_featured( KiraType::episode, $thumbnail );
		Anime::set_updated( $this->meta['parent_id'] );
		Kiranime_Cache::clear_single_post( $this->id, 'episode' );

		return $this->fetch_vid();
	}

	/**
	 * Fetches video data for the episode.
	 *
	 * This function checks if the Kiranime plugin is active and if the episode has not been fetched yet.
	 * If the conditions are met, it retrieves the episode's metadata and streams.
	 * It then attempts to grab additional player data using the Kiranime plugin.
	 * If successful, it processes the player data and updates the episode's streams.
	 * If the grabbing process fails, it sets a meta key to indicate that the episode needs to be grabbed.
	 * Finally, it updates the episode's streams and returns the current instance of the Episode class.
	 *
	 * @return Episode The current instance of the Episode class.
	 */
	public function fetch_vid(): self {
		if ( ! class_exists( 'Kiranime_plugin' ) || boolval( get_post_meta( $this->id, 'kiranime_episode_fetch_status' ) ) ) {
			return $this;
		}

		if ( empty( $this->meta ) || empty( $this->streams ) ) {
			$this->gets( MetaPrefix::episode )->get_streams( KiraType::episode, true );
		}

		$grabbed     = new Kiranime_plugin( $this );
		$players     = $grabbed->grab();
		$before_save = [];
		if ( ! empty( $players ) && is_array( $players ) ) {
			$proc_players = $this->process_player( $players, true );
			foreach ( $proc_players as $player ) {
				$before_save[] = $player;
			}
			update_post_meta( $this->id, 'kiranime_episode_fetch_status', 1 );
		} else {
			update_post_meta( $this->id, 'kira_need_grab', time() );
		}

		$strms = [];
		foreach ( array_merge( $this->streams, $before_save ) as $strm ) {
			if ( empty( array_filter( $strms, fn( $v )=> $v['host'] === $strm['host'] && $v['type'] === $strm['type'] ) ) ) {
				$strms[] = $strm;
			}
		}

		return $this->set_streams( KiraType::episode, $this->streams );
	}

	/**
	 * Randomizes the slug for the episode based on the parent name and episode number.
	 *
	 * @param bool $get If true, returns the slug only. If false, updates the post slug.
	 * @return string|Episode The generated slug or the current instance of Episode.
	 */
	private function randomize_slug( bool $get = false ): string|self {
		if ( ! get_option( '__q_use_rand_prefix', false ) ) {
			return $get ? '' : $this;
		}

		$parent_name = $this->meta['parent_name'] ?? get_post_meta( $this->id, 'kiranime_episode_parent_name', true );
		if ( ! $parent_name ) {
			return $get ? '' : $this;
		}

		$slug_prefix  = Kira_Utility::random_str( 7 );
		$episode_data = explode( '-', $parent_name );
		$slugs        = implode( ' ', array_splice( $episode_data, 0, 4 ) );
		$number       = $this->meta['number'];
		$e_tran       = __( 'Episode', 'kiranime' );

		$str_1 = "$slug_prefix-$slugs";
		$str_2 = strlen( $str_1 ) <= 50 ? "$str_1 $e_tran $number" : "$str_1 $number";
		$slug  = sanitize_title( $str_2 );

		if ( $get ) {
			return $slug;
		}

		wp_update_post(
			[
				'ID'        => $this->id,
				'post_name' => $slug,
			],
			false,
			false
		);

		return $this;
	}

	/**
	 * Handles the importing of episodes.
	 *
	 * @param array $episodes An associative array containing episode data.
	 *
	 * @return array An associative array containing the status, error message, episode data, and related anime data.
	 */
	public function import_episode( array $episodes = [] ): array {
		if ( empty( $episodes ) || ! isset( $episodes['number'], $episodes['anime'] ) ) {
			return [
				'status' => 0,
				'error'  => _x( 'Some fields cannot be empty!', 'rest api return', 'kiranime' ),
				'fields' => $episodes,
			];
		}

		$anime = new WP_Query(
			[
				'post_type'           => 'anime',
				'post_status'         => 'any',
				'posts_per_page'      => 1,
				'name'                => sanitize_title( $episodes['anime'] ),
				'ignore_sticky_posts' => true,
				'no_found_rows'       => true,
			]
		);

		if ( ! $anime->post_count || empty( $anime->posts ) ) {
			return [
				'status' => 0,
				'error'  => _x( 'Anime is not created or the title is not found.', 'rest api return', 'kiranime' ),
				'fields' => $episodes,
			];
		}

		$anime        = array_shift( $anime->posts );
		$episode_slug = get_option( '__q_use_rand_prefix', false ) ? $this->randomize_slug( true ) : sanitize_title( $anime->post_title . ' ' . __( 'Episode', 'kiranime' ) . ' ' . $episodes['number'] );

		$is_exist = new WP_Query(
			[
				'post_type'           => 'episode',
				'post_status'         => [ 'draft', 'publish', 'pending', 'future' ],
				'meta_query'          => [
					'relation' => 'AND',
					[
						'key'     => 'kiranime_episode_parent_id',
						'value'   => $anime->ID,
						'compare' => '=',
					],
					[
						'key'     => 'kiranime_episode_number',
						'value'   => $episodes['number'],
						'compare' => '=',
					],
				],
				'no_found_rows'       => true,
				'ignore_sticky_posts' => true,
			]
		);

		$post_date = empty( $episodes['released'] ) ? time() : strtotime( str_ireplace( '/', '-', $episodes['released'] ) );
		$post_date = gmdate( 'Y-m-d H:i:s', $post_date );
		if ( $is_exist->post_count ) {
			$eid = $is_exist->posts[0]->ID;
		} else {
			$eid = wp_insert_post(
				[
					'post_type'   => 'episode',
					'post_status' => $episodes['status'] ?? 'draft',
					'post_author' => get_current_user_id(),
					'post_title'  => "{$anime->post_title} " . __( 'Episode', 'kiranime' ) . " {$episodes['number']}",
					'post_date'   => $post_date,
					'post_name'   => $episode_slug,
				]
			);
		}

		$this->id   = $eid;
		$this->post = get_post( $this->id );

		wp_update_post(
			[
				'ID'           => $this->id,
				'post_date'    => $post_date,
				'post_content' => "{$anime->post_title} " . __( 'Episode', 'kiranime' ) . " {$episodes['number']}",
				'post_status'  => $episodes['status'] ?? 'draft',
			],
			false,
			false
		);

		$kiranime_episode_players = $episodes['players'] ?? [];
		if ( isset( $episodes['downloads'] ) && $episodes['downloads'] ) {
			$downloads = is_array( $episodes['downloads'] ) ? $episodes['downloads'] : json_decode( stripslashes( $episodes['downloads'] ), true );
			update_post_meta( $this->id, 'kiranime_download_data', json_encode( $downloads ) );
		}

		$this->update = array_merge(
			$episodes,
			[
				'episode_type' => 'series',
				'parent_id'    => $anime->ID,
				'number'       => $episodes['number'],
				'parent_name'  => $anime->post_title,
				'parent_slug'  => $anime->post_name,
			]
		);

		$this->sets( KiraType::episode, $this->update )
			->set_streams( KiraType::episode, $kiranime_episode_players )
			->update_taxonomies();

		if ( isset( $episodes['thumbnail'] ) ) {
			$this->set_featured( KiraType::episode, $episodes['thumbnail'] );
		}

		Anime::set_updated( $this->update['parent_id'] );
		Kiranime_Cache::clear_single_post( $this->id, 'episode' );
		return [
			'status'                       => 1,
			'error'                        => null,
			'data'                         => $this,
			'fields'                       => $episodes,
			'u'                            => $this->update['parent_id'],
			'kiranime_episode_parent_id'   => $anime->ID,
			'kiranime_episode_number'      => $episodes['number'],
			'kiranime_episode_parent_name' => $anime->post_title,
			'kiranime_episode_parent_slug' => $anime->post_name,
			'anime'                        => $anime,
		];
	}

	/**
	 * Handles the retrieval of video metadata for episodes.
	 *
	 * @return Episode The current instance of the Episode class.
	 */
	public function get_video_meta(): self {

		$cache  = new Kiranime_Cache( 'video_meta_cache' );
		$cached = $cache->get( $this->id );

		if ( $cached ) {
			$this->video_meta = $cached;
			return $this;
		}

		if ( ! $this->streams ) {
			return $this;
		}

		$duration = isset( $this->meta['duration'] ) ? preg_replace( '/[^\d+]/', '', $this->meta['duration'] ) . 'M' : '24M';
		$released = gmdate( 'D, d M Y H:i:s', strtotime( str_ireplace( '/', '-', $this->meta['released'] ?? '' ) ) );
		$url      = is_array( $this->streams[0] ) ? $this->streams[0]['url'] : $this->streams[0]->url;

		if ( stripos( $url, '<' ) !== false ) {
			preg_match( "/src\=(?:\"|\\')(.+?)(?:\"|\\')/", $url, $output_array );
			$url = $output_array[1] ?? '';
		}

		if ( ! $url ) {
			return $this;
		}

		$title = $this->meta['title'] ?? $this->post->post_title;

		$datetime  = new DateTime( $released );
		$date      = $datetime->format( DateTime::ATOM );
		$thumbnail = is_numeric( $this->meta['thumbnail'] ?? null ) ? wp_get_attachment_url( $this->meta['thumbnail'] ) : get_the_post_thumbnail_url( $this->meta['parent_id'] );

		$meta             = json_encode(
			[
				'@context'     => 'http://schema.org',
				'@type'        => 'VideoObject',
				'name'         => $this->post->post_title,
				'description'  => $title,
				'thumbnailUrl' => $thumbnail,
				'uploadDate'   => $date,
				'duration'     => "PT{$duration}",
				'embedUrl'     => $url,
			],
			JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE
		);
		$this->video_meta = "<script type='application/ld+json'>$meta</script>";
		$cache->set( $this->id, $this->video_meta, DAY_IN_SECONDS );
		return $this;
	}

	/**
	 * Handles the saving of episodes.
	 *
	 * @param WP_Post $post The post object.
	 * @param bool    $update Whether the post is being updated.
	 *
	 * @return int The post ID.
	 */
	public function save_post_episode( WP_Post $post, bool $update = false ): int {
		if ( empty( $_POST['kiranime_episode_editor_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['kiranime_episode_editor_nonce'] ) ), 'kiranime_episode_editor_nonce' ) || ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) || ! current_user_can( 'edit_posts' ) || 'trash' === $post->post_status ) {
			return $this->id;
		}

		$data      = $_POST;
		$players   = [];
		$downloads = [];

		if ( ! empty( $data['save_episode_player'] ) ) {
			$players = Kira_Utility::safe_decode( $data['save_episode_player'], true );
		}

		if ( ! empty( $data['save_download_data'] ) ) {
			$downloads = Kira_Utility::safe_decode( value: $data['save_download_data'], convert: true );
		}

		if ( empty( $players ) && class_exists( 'Kiranime_plugin' ) ) {
			$this->set( 'kira_need_grab', time() );
		}
		$this->sets( KiraType::episode, $data )
			->set_download( $downloads )
			->set_streams( KiraType::episode, $players )
			->set_featured( KiraType::episode, $data['kiranime_episode_thumbnail'] ?? $data['kiranime_external_thumbnail'] ?? '' )
			->fetch_vid();

		if ( ! $update ) {
			$this->randomize_slug();
		}

		if ( $this->meta['parent_id'] ) {
			Anime::set_updated( $this->meta['parent_id'] );

			if ( empty( $this->get( 'notification_sent' ) ) ) {
				Kiranime_Notification::notify( $this->id, $this->meta['parent_id'], $this->meta['number'] );
				$this->set( 'notification_sent', '1' );
			}
		}

		Kiranime_Cache::clear_single_post( $this->id, 'episode' );

		return $this->id;
	}

	/**
	 * Handles the publishing of episodes.
	 *
	 * Fetches additional episode data from The Movie Database (TMDb) if available,
	 * updates the episode's featured image, and deletes the cache for the episode and its parent anime.
	 *
	 * @param string  $old The old post status.
	 * @param string  $new The new post status.
	 * @param WP_Post $post The post object.
	 *
	 * @return int The post ID.
	 */
	public function publish_scheduled( string $old, string $new, WP_Post $post ): int {
		if ( 'publish' !== $new || 'trash' === $new || 'future' !== $old ) {
			return $post->ID;
		}

		$this->gets( MetaPrefix::episode );

		$tmdb_id = $this->meta['anime_id'];
		$season  = $this->meta['anime_season'];
		$number  = $this->meta['number'];
		$api     = get_option( '__a_tmdb' );

		if ( $tmdb_id && $season && $number && $api ) {
			$request = wp_remote_request( "https://api.themoviedb.org/3/tv/{$tmdb_id}/season/{$season}/episode/{$number}?api_key={$api}" );

			if ( ! is_wp_error( $request ) ) {
				$response = json_decode( wp_remote_retrieve_body( $request ) );
				$fields   = [
					'thumbnail' => $response->still_path,
					'title'     => $response->name,
					'duration'  => $response->runtime,
					'released'  => gmdate( 'Y-m-d H:i:s', strtotime( $response->air_date ?? '' ) ?: time() ),
				];

				$this->sets( KiraType::episode, $fields );
			}
		}

		$parent_id = $this->meta['parent_id'];
		$thumb_url = sanitize_text_field( wp_unslash( $_POST['kiranime_episode_thumbnail'] ?? ( $fields['thumbnail'] ?? '' ) ) );
		if ( ! empty( $thumb_url ) ) {
			$this->set_featured( KiraType::episode, $thumb_url );
		}

		$this->fetch_vid();

		if ( ! empty( $parent_id ) ) {
			Anime::set_updated( $parent_id );

			if ( ! $this->get( 'notification_sent' ) ) {
				Kiranime_Notification::notify( $post->ID, $parent_id, $this->get( 'kiranime_episode_number' ) );
				update_post_meta( $post->ID, 'notification_sent', '1' );
			}
		}

		return $post->ID;
	}
}
