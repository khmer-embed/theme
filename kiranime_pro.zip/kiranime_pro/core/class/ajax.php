<?php

/**
 * Class Kiranime_Ajax
 *
 * Handles AJAX requests for the Kiranime Theme.
 *
 * @package Kiranime
 * @since 3.5.0
 */
class Kiranime_Ajax {
	/**
	 * Constructor for Kiranime_Ajax class.
	 */
	public function __construct() {
		add_action( 'wp_ajax_get_nonce', [ $this, 'kiranime_ajax_get_nonce' ] );
		add_action( 'wp_ajax_nopriv_get_nonce', [ $this, 'kiranime_ajax_get_nonce' ] );
		add_action( 'wp_ajax_kiranime_dismiss_update_notification', [ $this, 'kiranime_ajax_kiranime_dismiss_update_notification' ] );
	}

	/**
	 * Retrieves a nonce for AJAX requests.
	 *
	 * This function is used to create a nonce for AJAX requests to prevent unauthorized access.
	 * It creates a nonce using the 'wp_rest' action and sends it back as a JSON response.
	 *
	 * @return mixed Returns a JSON response with the nonce.
	 */
	public function kiranime_ajax_get_nonce() {
		$nonce = wp_create_nonce( 'wp_rest' );
		return wp_send_json_success( [ 'nonce' => $nonce ] );
	}
	/**
	 * Dismisses the update notification for the Kiranime theme.
	 *
	 * This function deletes the 'kiranime_update_available' option, effectively dismissing the update notification.
	 * It then sends a JSON response indicating the success of the operation.
	 *
	 * @return mixed Returns a JSON response with the status of the operation.
	 *               - 'status': The result of the delete_option() function.
	 *                           If the option was successfully deleted, this will be true.
	 *                           If the option did not exist, this will be false.
	 */
	public function kiranime_ajax_kiranime_dismiss_update_notification() {
		$options = delete_option( 'kiranime_update_available' );
		return wp_send_json_success( [ 'status' => $options ] );
	}
}
