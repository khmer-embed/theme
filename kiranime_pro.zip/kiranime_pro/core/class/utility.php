<?php

class Kira_Utility {


	/**
	 * Escapes single and double quotes in a string.
	 *
	 * This function replaces single and double quotes with their escaped versions.
	 *
	 * @param mixed $value The string to escape.
	 *
	 * @return string The escaped string.
	 */
	public static function escape_quotes( mixed $value ) {
		if ( 'string' !== gettype( $value ) ) {
			return $value;
		}
		return str_ireplace( [ "'", '"' ], [ "\'", '\"' ], self::unescape_quotes( $value ) );
	}

	/**
	 * Unescape single and double quotes in a string.
	 *
	 * This function replaces escaped single and double quotes with their unescaped counterparts.
	 *
	 * @param mixed $value The string to unescape.
	 *
	 * @return string The unescaped string.
	 */
	public static function unescape_quotes( mixed $value ) {
		if ( 'string' !== gettype( $value ) ) {
			return $value;
		}
		return str_ireplace( [ "\'", '\"' ], [ "'", '\"', '"' ], $value );
	}

	/**
	 * Converts double quotes to single quotes.
	 *
	 * This function is used to replace all double quotes in a given string with single quotes.
	 *
	 * @param string $value The string to convert.
	 *
	 * @return string The string with all double quotes replaced by single quotes.
	 */
	public static function convert_to_single_quotes( $value ) {
		if ( 'string' !== gettype( $value ) ) {
			return $value;
		}
		return str_replace( '"', "'", $value );
	}

	/**
	 * Decodes a JSON string safely.
	 *
	 * This function decodes a JSON string and handles potential errors.
	 * If the input is an array or object, it is returned as is.
	 * If the input is empty, null is returned.
	 * If the JSON decoding fails, the function tries to decode the string again after unslashing it.
	 * If the unslashed decoding also fails, null is returned.
	 *
	 * @param mixed $value The JSON string to decode.
	 * @param bool  $assoc Whether to return the object as an associative array. Default is false.
	 * @param bool  $unslash Whether to unslash the string before decoding. Default is false.
	 * @param bool  $convert Whether to convert the array to an associative array or Object to an associative array. Default is false.
	 *
	 * @return mixed|null The decoded JSON data or null if decoding fails.
	 */
	public static function safe_decode( mixed $value, bool $assoc = false, bool $unslash = false, bool $convert = false ) {
		try {
			if ( empty( $value ) ) {
				return null;
			}

			if ( is_array( $value ) || is_object( $value ) ) {
				if ( $convert ) {
					return $unslash ? json_decode( wp_unslash( json_encode( $value ) ), true ) : json_decode( json_encode( $value ), associative: $assoc );
				}
				return $value;
			}
			if ( $unslash ) {
				$file = json_decode( json: wp_unslash( $value ), associative: $assoc, flags: JSON_THROW_ON_ERROR );
			} else {
				$file = json_decode( json: $value, associative: $assoc, flags: JSON_THROW_ON_ERROR );
			}

			return $file;
		} catch ( \Throwable $e ) {

			if ( ! $unslash ) {
				return self::safe_decode( value: $value, assoc: $assoc, unslash: true, convert: $convert );
			}

			return null;
		}
	}
	/**
	 * Checks if a given URL points to an image.
	 *
	 * @param string|null $url The URL to check.
	 *
	 * @return bool True if the URL points to an image, false otherwise.
	 */
	public static function is_image( ?string $url = null ) {
		if ( empty( $url ) ) {
			return false;
		}

		$ext  = [ 'jpeg', 'jpg', 'gif', 'png', 'webp', 'avif' ];
		$info = pathinfo( parse_url( $url, PHP_URL_PATH ) );

		if ( empty( $info['extension'] ) ) {
			return false;
		}

		return in_array( $info['extension'], $ext, true );
	}

	/**
	 * Saves a report as a custom post type.
	 *
	 * @param array $data The report data.
	 * @return int|null The ID of the saved post, or null if the data is invalid or the post could not be saved.
	 */
	public static function save_report( $data ) {
		if ( ! $data || empty( $data ) ) {
			return null;
		}

		$post = wp_insert_post(
			[
				'post_type'   => 'reported',
				'post_status' => 'publish',
				'post_title'  => $data['title'],
			]
		);

		if ( ! $post ) {
			return null;
		}

		update_post_meta( $post, 'reported_value', $data['value'] );
		update_post_meta( $post, 'reported_episode', get_bloginfo( 'wpurl' ) . '/wp-admin/post.php?post=' . $data['id'] . '&action=edit' );

		return true;
	}

	/**
	 * Get the page link.
	 *
	 * @param string $template The template to retrieve the link.
	 *
	 * @return string
	 */
	public static function page_link( $template = '' ) {
		if ( ! $template ) {
			return '';
		}

		$cache  = new Kiranime_Cache( 'page_link_' );
		$key    = md5( $template );
		$cached = $cache->get( $key );
		if ( ! empty( $cached ) ) {
			return $cached;
		}

		$pages = get_pages(
			array(
				'meta_key'   => '_wp_page_template',
				'meta_value' => $template,
			)
		);
		if ( empty( $pages ) || ! isset( $pages[0] ) ) {
			return '';
		}
		$result = get_page_link( $pages[0]->ID );
		$cache->set( $key, $result, get_option( '__kira_cache_time', 3600 ) );
		return $result;
	}

	/**
	 * Get the template page slug.
	 *
	 * @param string $template The template to get the slug for.
	 *
	 * @return string The template page slug.
	 */
	public static function page_slug( $template ) {

		$cache  = new Kiranime_Cache( 'page_slug_' );
		$key    = md5( $template );
		$cached = $cache->get( $key );

		if ( ! empty( $cached ) ) {
			return $cached;
		}

		$pages = get_pages(
			[
				'meta_key'   => '_wp_page_template',
				'meta_value' => $template,
			]
		);

		if ( ! empty( $pages[0] ) ) {
			$cache->set( $key, $pages[0]->post_name, get_option( '__kira_cache_time', 3600 ) );
			return $pages[0]->post_name;
		}

		return null;
	}

	/**
	 * Get social media icons and links.
	 */
	public static function social() {
		$socials = [
			'telegram'  => [
				'link'  => get_theme_mod( '__social_telegram' ),
				'color' => '#0088cc',
				'vbox'  => '0 0 496 512',
				'icon'  => 'M446.7 98.6l-67.6 318.8c-5.1 22.5-18.4 28.1-37.3 17.5l-103-75.9-49.7 47.8c-5.5 5.5-10.1 10.1-20.7 10.1l7.4-104.9 190.9-172.5c8.3-7.4-1.8-11.5-12.9-4.1L117.8 284 16.2 252.2c-22.1-6.9-22.5-22.1 4.6-32.7L418.2 66.4c18.4-6.9 34.5 4.1 28.5 32.2z',
			],
			'discord'   => [
				'link'  => get_theme_mod( '__social_discord' ),
				'color' => '#7289da',
				'vbox'  => '0 0 640 512',
				'icon'  => 'M297.216 243.2c0 15.616-11.52 28.416-26.112 28.416-14.336 0-26.112-12.8-26.112-28.416s11.52-28.416 26.112-28.416c14.592 0 26.112 12.8 26.112 28.416zm-119.552-28.416c-14.592 0-26.112 12.8-26.112 28.416s11.776 28.416 26.112 28.416c14.592 0 26.112-12.8 26.112-28.416.256-15.616-11.52-28.416-26.112-28.416zM448 52.736V512c-64.494-56.994-43.868-38.128-118.784-107.776l13.568 47.36H52.48C23.552 451.584 0 428.032 0 398.848V52.736C0 23.552 23.552 0 52.48 0h343.04C424.448 0 448 23.552 448 52.736zm-72.96 242.688c0-82.432-36.864-149.248-36.864-149.248-36.864-27.648-71.936-26.88-71.936-26.88l-3.584 4.096c43.52 13.312 63.744 32.512 63.744 32.512-60.811-33.329-132.244-33.335-191.232-7.424-9.472 4.352-15.104 7.424-15.104 7.424s21.248-20.224 67.328-33.536l-2.56-3.072s-35.072-.768-71.936 26.88c0 0-36.864 66.816-36.864 149.248 0 0 21.504 37.12 78.08 38.912 0 0 9.472-11.52 17.152-21.248-32.512-9.728-44.8-30.208-44.8-30.208 3.766 2.636 9.976 6.053 10.496 6.4 43.21 24.198 104.588 32.126 159.744 8.96 8.96-3.328 18.944-8.192 29.44-15.104 0 0-12.8 20.992-46.336 30.464 7.68 9.728 16.896 20.736 16.896 20.736 56.576-1.792 78.336-38.912 78.336-38.912z',
			],
			'reddit'    => [
				'link'  => get_theme_mod( '__social_reddit' ),
				'color' => '#ff4500',
				'vbox'  => '0 0 512 512',
				'icon'  => 'M201.5 305.5c-13.8 0-24.9-11.1-24.9-24.6 0-13.8 11.1-24.9 24.9-24.9 13.6 0 24.6 11.1 24.6 24.9 0 13.6-11.1 24.6-24.6 24.6zM504 256c0 137-111 248-248 248S8 393 8 256 119 8 256 8s248 111 248 248zm-132.3-41.2c-9.4 0-17.7 3.9-23.8 10-22.4-15.5-52.6-25.5-86.1-26.6l17.4-78.3 55.4 12.5c0 13.6 11.1 24.6 24.6 24.6 13.8 0 24.9-11.3 24.9-24.9s-11.1-24.9-24.9-24.9c-9.7 0-18 5.8-22.1 13.8l-61.2-13.6c-3-.8-6.1 1.4-6.9 4.4l-19.1 86.4c-33.2 1.4-63.1 11.3-85.5 26.8-6.1-6.4-14.7-10.2-24.1-10.2-34.9 0-46.3 46.9-14.4 62.8-1.1 5-1.7 10.2-1.7 15.5 0 52.6 59.2 95.2 132 95.2 73.1 0 132.3-42.6 132.3-95.2 0-5.3-.6-10.8-1.9-15.8 31.3-16 19.8-62.5-14.9-62.5zM302.8 331c-18.2 18.2-76.1 17.9-93.6 0-2.2-2.2-6.1-2.2-8.3 0-2.5 2.5-2.5 6.4 0 8.6 22.8 22.8 87.3 22.8 110.2 0 2.5-2.2 2.5-6.1 0-8.6-2.2-2.2-6.1-2.2-8.3 0zm7.7-75c-13.6 0-24.6 11.1-24.6 24.9 0 13.6 11.1 24.6 24.6 24.6 13.8 0 24.9-11.1 24.9-24.6 0-13.8-11-24.9-24.9-24.9z',
			],
			'facebook'  => [
				'link'  => get_theme_mod( '__social_facebook' ),
				'color' => '#1877f2',
				'vbox'  => '0 0 512 512',
				'icon'  => 'M504 256C504 119 393 8 256 8S8 119 8 256c0 123.78 90.69 226.38 209.25 245V327.69h-63V256h63v-54.64c0-62.15 37-96.48 93.67-96.48 27.14 0 55.52 4.84 55.52 4.84v61h-31.28c-30.8 0-40.41 19.12-40.41 38.73V256h68.78l-11 71.69h-57.78V501C413.31 482.38 504 379.78 504 256z',
			],
			'twitter'   => [
				'link'  => get_theme_mod( '__social_twitter' ),
				'color' => '#1da1f2',
				'vbox'  => '0 0 512 512',
				'icon'  => 'M459.37 151.716c.325 4.548.325 9.097.325 13.645 0 138.72-105.583 298.558-298.558 298.558-59.452 0-114.68-17.219-161.137-47.106 8.447.974 16.568 1.299 25.34 1.299 49.055 0 94.213-16.568 130.274-44.832-46.132-.975-84.792-31.188-98.112-72.772 6.498.974 12.995 1.624 19.818 1.624 9.421 0 18.843-1.3 27.614-3.573-48.081-9.747-84.143-51.98-84.143-102.985v-1.299c13.969 7.797 30.214 12.67 47.431 13.319-28.264-18.843-46.781-51.005-46.781-87.391 0-19.492 5.197-37.36 14.294-52.954 51.655 63.675 129.3 105.258 216.365 109.807-1.624-7.797-2.599-15.918-2.599-24.04 0-57.828 46.782-104.934 104.934-104.934 30.213 0 57.502 12.67 76.67 33.137 23.715-4.548 46.456-13.32 66.599-25.34-7.798 24.366-24.366 44.833-46.132 57.827 21.117-2.273 41.584-8.122 60.426-16.243-14.292 20.791-32.161 39.308-52.628 54.253z',
			],
			'youtube'   => [
				'link'  => get_theme_mod( '__social_youtube' ),
				'color' => '#ff0000',
				'vbox'  => '0 0 576 512',
				'icon'  => 'M549.655 124.083c-6.281-23.65-24.787-42.276-48.284-48.597C458.781 64 288 64 288 64S117.22 64 74.629 75.486c-23.497 6.322-42.003 24.947-48.284 48.597-11.412 42.867-11.412 132.305-11.412 132.305s0 89.438 11.412 132.305c6.281 23.65 24.787 41.5 48.284 47.821C117.22 448 288 448 288 448s170.78 0 213.371-11.486c23.497-6.321 42.003-24.171 48.284-47.821 11.412-42.867 11.412-132.305 11.412-132.305s0-89.438-11.412-132.305zm-317.51 213.508V175.185l142.739 81.205-142.739 81.201z',
			],
			'tumblr'    => [
				'link'  => get_theme_mod( '__social_tumblr' ),
				'color' => '#35465c',
				'vbox'  => '0 0 320 512',
				'icon'  => 'M309.8 480.3c-13.6 14.5-50 31.7-97.4 31.7-120.8 0-147-88.8-147-140.6v-144H17.9c-5.5 0-10-4.5-10-10v-68c0-7.2 4.5-13.6 11.3-16 62-21.8 81.5-76 84.3-117.1.8-11 6.5-16.3 16.1-16.3h70.9c5.5 0 10 4.5 10 10v115.2h83c5.5 0 10 4.4 10 9.9v81.7c0 5.5-4.5 10-10 10h-83.4V360c0 34.2 23.7 53.6 68 35.8 4.8-1.9 9-3.2 12.7-2.2 3.5.9 5.8 3.4 7.4 7.9l22 64.3c1.8 5 3.3 10.6-.4 14.5z',
			],
			'instagram' => [
				'link' => get_theme_mod( '__social_instagram' ),
			],
		];

		return $socials;
	}

	/**
	 * Get social media sharing buttons
	 *
	 * @param string $page_title The page title to share.
	 * @param string $page_url The page URL to share.
	 * @param int    $max The maximum number of social media buttons to return.
	 *
	 * @return array An array of social media icons and links.
	 */
	public static function share_button( string $page_title, string $page_url, int $max = 6 ) {
		$cache  = new Kiranime_Cache( 'kira_share_button' );
		$md5    = md5( "$page_title-$page_url-$max" );
		$cached = $cache->get( $md5 );
		if ( ! empty( $cached ) ) {
			return self::safe_decode( value: $cached, assoc: true, convert: true );
		}

		$buttons = [
			'telegram' => [
				'link'  => 'https://t.me/share/url?url=' . $page_url . '&text=' . $page_title,
				'color' => '#0088cc',
				'vbox'  => '0 0 496 512',
				'icon'  => 'M446.7 98.6l-67.6 318.8c-5.1 22.5-18.4 28.1-37.3 17.5l-103-75.9-49.7 47.8c-5.5 5.5-10.1 10.1-20.7 10.1l7.4-104.9 190.9-172.5c8.3-7.4-1.8-11.5-12.9-4.1L117.8 284 16.2 252.2c-22.1-6.9-22.5-22.1 4.6-32.7L418.2 66.4c18.4-6.9 34.5 4.1 28.5 32.2z',
			],
			'reddit'   => [
				'link'  => 'https://reddit.com/submit?url=' . $page_url . '&title=' . $page_title,
				'color' => '#ff4500',
				'vbox'  => '0 0 512 512',
				'icon'  => 'M201.5 305.5c-13.8 0-24.9-11.1-24.9-24.6 0-13.8 11.1-24.9 24.9-24.9 13.6 0 24.6 11.1 24.6 24.9 0 13.6-11.1 24.6-24.6 24.6zM504 256c0 137-111 248-248 248S8 393 8 256 119 8 256 8s248 111 248 248zm-132.3-41.2c-9.4 0-17.7 3.9-23.8 10-22.4-15.5-52.6-25.5-86.1-26.6l17.4-78.3 55.4 12.5c0 13.6 11.1 24.6 24.6 24.6 13.8 0 24.9-11.3 24.9-24.9s-11.1-24.9-24.9-24.9c-9.7 0-18 5.8-22.1 13.8l-61.2-13.6c-3-.8-6.1 1.4-6.9 4.4l-19.1 86.4c-33.2 1.4-63.1 11.3-85.5 26.8-6.1-6.4-14.7-10.2-24.1-10.2-34.9 0-46.3 46.9-14.4 62.8-1.1 5-1.7 10.2-1.7 15.5 0 52.6 59.2 95.2 132 95.2 73.1 0 132.3-42.6 132.3-95.2 0-5.3-.6-10.8-1.9-15.8 31.3-16 19.8-62.5-14.9-62.5zM302.8 331c-18.2 18.2-76.1 17.9-93.6 0-2.2-2.2-6.1-2.2-8.3 0-2.5 2.5-2.5 6.4 0 8.6 22.8 22.8 87.3 22.8 110.2 0 2.5-2.2 2.5-6.1 0-8.6-2.2-2.2-6.1-2.2-8.3 0zm7.7-75c-13.6 0-24.6 11.1-24.6 24.9 0 13.6 11.1 24.6 24.6 24.6 13.8 0 24.9-11.1 24.9-24.6 0-13.8-11-24.9-24.9-24.9z',
			],
			'facebook' => [
				'link'  => 'https://www.facebook.com/sharer.php?u=' . $page_url,
				'color' => '#1877f2',
				'vbox'  => '0 0 512 512',
				'icon'  => 'M504 256C504 119 393 8 256 8S8 119 8 256c0 123.78 90.69 226.38 209.25 245V327.69h-63V256h63v-54.64c0-62.15 37-96.48 93.67-96.48 27.14 0 55.52 4.84 55.52 4.84v61h-31.28c-30.8 0-40.41 19.12-40.41 38.73V256h68.78l-11 71.69h-57.78V501C413.31 482.38 504 379.78 504 256z',
			],
			'whatsapp' => [
				'link'  => 'whatsapp://send/?text=' . $page_title . '%20' . $page_url,
				'color' => '#25D366',
				'vbox'  => '0 0 448 512',
				'icon'  => 'M380.9 97.1C339 55.1 283.2 32 223.9 32c-122.4 0-222 99.6-222 222 0 39.1 10.2 77.3 29.6 111L0 480l117.7-30.9c32.4 17.7 68.9 27 106.1 27h.1c122.3 0 224.1-99.6 224.1-222 0-59.3-25.2-115-67.1-157zm-157 341.6c-33.2 0-65.7-8.9-94-25.7l-6.7-4-69.8 18.3L72 359.2l-4.4-7c-18.5-29.4-28.2-63.3-28.2-98.2 0-101.7 82.8-184.5 184.6-184.5 49.3 0 95.6 19.2 130.4 54.1 34.8 34.9 56.2 81.2 56.1 130.5 0 101.8-84.9 184.6-186.6 184.6zm101.2-138.2c-5.5-2.8-32.8-16.2-37.9-18-5.1-1.9-8.8-2.8-12.5 2.8-3.7 5.6-14.3 18-17.6 21.8-3.2 3.7-6.5 4.2-12 1.4-32.6-16.3-54-29.1-75.5-66-5.7-9.8 5.7-9.1 16.3-30.3 1.8-3.7.9-6.9-.5-9.7-1.4-2.8-12.5-30.1-17.1-41.2-4.5-10.8-9.1-9.3-12.5-9.5-3.2-.2-6.9-.2-10.6-.2-3.7 0-9.7 1.4-14.8 6.9-5.1 5.6-19.4 19-19.4 46.3 0 27.3 19.9 53.7 22.6 57.4 2.8 3.7 39.1 59.7 94.8 83.8 35.2 15.2 49 16.5 66.6 13.9 10.7-1.6 32.8-13.4 37.4-26.4 4.6-13 4.6-24.1 3.2-26.4-1.3-2.5-5-3.9-10.5-6.6z',
			],
			'twitter'  => [
				'link'  => 'https://twitter.com/intent/tweet?url=' . $page_url . '&text=' . $page_title,
				'color' => '#1da1f2',
				'vbox'  => '0 0 512 512',
				'icon'  => 'M459.37 151.716c.325 4.548.325 9.097.325 13.645 0 138.72-105.583 298.558-298.558 298.558-59.452 0-114.68-17.219-161.137-47.106 8.447.974 16.568 1.299 25.34 1.299 49.055 0 94.213-16.568 130.274-44.832-46.132-.975-84.792-31.188-98.112-72.772 6.498.974 12.995 1.624 19.818 1.624 9.421 0 18.843-1.3 27.614-3.573-48.081-9.747-84.143-51.98-84.143-102.985v-1.299c13.969 7.797 30.214 12.67 47.431 13.319-28.264-18.843-46.781-51.005-46.781-87.391 0-19.492 5.197-37.36 14.294-52.954 51.655 63.675 129.3 105.258 216.365 109.807-1.624-7.797-2.599-15.918-2.599-24.04 0-57.828 46.782-104.934 104.934-104.934 30.213 0 57.502 12.67 76.67 33.137 23.715-4.548 46.456-13.32 66.599-25.34-7.798 24.366-24.366 44.833-46.132 57.827 21.117-2.273 41.584-8.122 60.426-16.243-14.292 20.791-32.161 39.308-52.628 54.253z',
			],
			'tumblr'   => [
				'link'  => 'https://www.tumblr.com/widgets/share/tool?canonicalUrl=' . $page_url . '&title=' . $page_title,
				'color' => '#35465c',
				'vbox'  => '0 0 320 512',
				'icon'  => 'M309.8 480.3c-13.6 14.5-50 31.7-97.4 31.7-120.8 0-147-88.8-147-140.6v-144H17.9c-5.5 0-10-4.5-10-10v-68c0-7.2 4.5-13.6 11.3-16 62-21.8 81.5-76 84.3-117.1.8-11 6.5-16.3 16.1-16.3h70.9c5.5 0 10 4.5 10 10v115.2h83c5.5 0 10 4.4 10 9.9v81.7c0 5.5-4.5 10-10 10h-83.4V360c0 34.2 23.7 53.6 68 35.8 4.8-1.9 9-3.2 12.7-2.2 3.5.9 5.8 3.4 7.4 7.9l22 64.3c1.8 5 3.3 10.6-.4 14.5z',
			],
		];

		$result = array_splice( $buttons, 0, $max );
		$cache->set( $md5, $result );
		return $result;
	}

	private static function convertToRGB( $hex ) {
		if ( '#ffffff' === $hex || '#fff' === $hex ) {
			return '255,255,255';
		}
		$rgb = sscanf( $hex, '#%02x%02x%02x' );
		return implode( ',', $rgb );
	}

	/**
	 * Convert colors values to RGB values.
	 *
	 * @param bool $return deprecated.
	 *
	 * @return string
	 */
	public static function get_color_variables( $return = false ) {
		$cache  = new Kiranime_Cache( 'color_variables' );
		$cached = $cache->get( 'color_variables' );
		if ( ! empty( $cached ) ) {
			return $cached;
		}

		$primary         = self::convertToRGB( get_theme_mod( 'primary-color', '#202125' ) );
		$secondary       = self::convertToRGB( get_theme_mod( 'secondary-color', '#4a4b51' ) );
		$tertiary        = self::convertToRGB( get_theme_mod( 'tertiary-color', '#414248' ) );
		$overlay         = self::convertToRGB( get_theme_mod( 'overlay-color', '#2a2c31' ) );
		$accent          = self::convertToRGB( get_theme_mod( 'accent-color', '#38bdf8' ) );
		$accent_2        = self::convertToRGB( get_theme_mod( 'accent-2-color', '#0ea5e9' ) );
		$accent_3        = self::convertToRGB( get_theme_mod( 'accent-3-color', '#0284c7' ) );
		$accent_4        = self::convertToRGB( get_theme_mod( 'accent-4-color', '#0369a1' ) );
		$primary_darker  = self::convertToRGB( get_theme_mod( 'primary-darker-color', '#14151a' ) );
		$primary_darkest = self::convertToRGB( get_theme_mod( 'primary-darkest-color', '#121315' ) );
		$text            = self::convertToRGB( get_theme_mod( 'text-color', '#fffff1' ) );
		$text_accent     = self::convertToRGB( get_theme_mod( 'text-accent-color', '#f4f4f5' ) );
		$text_accent_2   = self::convertToRGB( get_theme_mod( 'text-accent-2-color', '#71717a' ) );
		$error           = self::convertToRGB( get_theme_mod( 'error-color', '#f43f5e' ) );
		$error_accent    = self::convertToRGB( get_theme_mod( 'error-accent-color', '#e11d48' ) );
		$error_accent_2  = self::convertToRGB( get_theme_mod( 'error-accent-2-color', '#be123c' ) );
		$error_accent_3  = self::convertToRGB( get_theme_mod( 'error-accent-3-color', '#fb7185' ) );

		$result = 'html {
            --primary-color:' . $primary . ';
            --secondary-color:' . $secondary . ';
            --tertiary-color:' . $tertiary . ';
            --accent-color:' . $accent . ';
            --accent-2-color:' . $accent_2 . ';
            --accent-3-color:' . $accent_3 . ';
            --accent-4-color:' . $accent_4 . ';
            --primary-darker-color:' . $primary_darker . ';
            --primary-darkest-color:' . $primary_darkest . ';
            --overlay-color:' . $overlay . ';
            --text-color:' . $text . ';
            --text-accent-color:' . $text_accent . ';
            --text-accent-2-color:' . $text_accent_2 . ';
            --error-color:' . $error . ';
            --error-accent-color:' . $error_accent . ';
            --error-accent-2-color:' . $error_accent_2 . ';
            --error-accent-3-color:' . $error_accent_3 . ';
        }';

		$cache->set( 'color_variables', $result );
		return $result;
	}

	/**
	 * User page menu configuration.
	 *
	 * @param bool $is_public Whether the menu is for public or private.
	 *
	 * @return array
	 */
	public static function get_user_menu( bool $is_public = false ) {

		if ( $is_public ) {
			return [
				[
					'name' => __( 'Watch List', 'kiranime' ),
					'icon' => 'favorite',
					'link' => self::page_link( 'pages/watchlist.php' ),
				],
			];
		}

		return [
			[
				'name' => __( 'Profile', 'kiranime' ),
				'icon' => 'account_box',
				'link' => self::page_link( 'pages/profile.php' ),
			],
			[
				'name' => __( 'Continue Watching', 'kiranime' ),
				'icon' => 'restore',
				'link' => self::page_link( 'pages/continue-watching.php' ),
			],
			[
				'name' => __( 'Watch List', 'kiranime' ),
				'icon' => 'favorite',
				'link' => self::page_link( 'pages/watchlist.php' ),
			],
			[
				'name' => __( 'Notification', 'kiranime' ),
				'icon' => 'notifications',
				'link' => self::page_link( 'pages/notification.php' ),
			],
		];
	}

	/**
	 * Save settings to database.
	 *
	 * @param array $param The parameters.
	 *
	 * @return array The saved settings
	 *
	 * @deprecated
	 */
	public static function save_setting( array $param = [] ) {
		if ( ! $param ) {
			return [
				'data'   => [
					'saved' => false,
					'error' => 'no options',
				],
				'status' => 400,
			];
		}

		$options_key = [
			'jikan_url'      => '__a_jikan',
			'tmdb_key'       => '__a_tmdb',
			'auto_dl_image'  => '__a_auto_dl',
			'episode_by'     => '__q_episode_by',
			'usepostdate'    => '__q_use_post_date',
			'defaultlang'    => '__u_def_language',
			'usestatus'      => '__u_status_i_du',
			'status_bg'      => '__u_status_bg',
			'urk'            => '__use_recaptcha',
			'title_switcher' => '__q_title_switcher',
			'krstk'          => 'kiranime_recaptcha_sitekey',
			'krsck'          => 'kiranime_recaptcha_secretkey',
			'use_cache'      => '__kira_use_cache',
			'disable_login'  => 'kira_disable_login_page',
			'lazy_load'      => 'kira_use_lazy_load',
			'full_width'     => 'kira_use_full_width',
			'video_meta'     => '__a_show_video_meta',
			'rand_prefix'    => '__q_use_rand_prefix',
			'en_title_label' => '__q_en_title_label',
			'jp_title_label' => '__q_jp_title_label',
			'cache_driver'   => '__kira_cache_driver',
			'redis_host'     => '__kira_redis_host',
			'redis_port'     => '__kira_redis_port',
			'redis_db'       => '__kira_redis_db',
			'memcached_host' => '__kira_memcached_host',
			'memcached_port' => '__kira_memcached_port',
			'redis_password' => '__kira_redis_password',
			'redis_username' => '__kira_redis_username',
		];

		$watchlist_settings = [];
		$results            = [];
		foreach ( $param as $key => $value ) {
			$key_pair = $options_key[ $key ] ?? '';

			if ( gettype( $value ) === 'object' ) {
				continue;
			}

			if ( stripos( $key, 'watchlist' ) !== false ) {
				$watchlist_settings[] = [
					'key'   => $key,
					'value' => $value,
				];
				continue;
			}

			if ( ! isset( $value ) ) {
				continue;
			}

			update_option( $key_pair, $value );
			$results[ $options_key[ $key ] ] = [
				'key' => $options_key[ $key ],
				'val' => $value,
				'opt' => get_option( $options_key[ $key ] ),
			];
		}

		$wl = self::set_watchlist_settings( $watchlist_settings );

		return [
			'data'   => [
				'saved'   => true,
				'results' => $results,
			],
			'status' => 200,
		];
	}

	/**
	 * Retrieves a remote image and attaches it to a WordPress post.
	 *
	 * @param string   $image_url The URL of the remote image.
	 * @param int|null $post_id The ID of the WordPress post to attach the image to. If null, the image will not be attached to a post.
	 *
	 * @return array An associative array containing the status and details of the image retrieval and attachment process.
	 *              - 'status': 1 if the image was successfully retrieved and attached, 0 otherwise.
	 *              - 'thumbnail_id': The ID of the attached image in WordPress.
	 *              - 'thumbnail_url': The URL of the attached image in WordPress.
	 *
	 * @since 1.0.0
	 */
	public static function get_remote_image( $image_url, $post_id = null ) {
		if ( ! $image_url || empty( $image_url ) || is_numeric( $image_url ) ) {
			return [ 'status' => 0 ];
		}

		include_once ABSPATH . 'wp-admin/includes/media.php';
		include_once ABSPATH . 'wp-admin/includes/file.php';
		include_once ABSPATH . 'wp-admin/includes/image.php';

		$supported_image = array(
			'gif',
			'jpg',
			'jpeg',
			'png',
		);
		$ext             = strtolower( pathinfo( $image_url, PATHINFO_EXTENSION ) );

		if ( in_array( $ext, $supported_image ) ) {
			$attach_id = media_sideload_image( $image_url, null, null, 'id' );

			if ( is_wp_error( $attach_id ) ) {
				return [ 'status' => 0 ];
			}

			return [
				'status'        => 1,
				'thumbnail_id'  => $attach_id,
				'thumbnail_url' => wp_get_attachment_image_url( $attach_id, 'full' ),
			];
		}

		$imagetype = end( explode( '/', getimagesize( $image_url )['mime'] ) );
		$uniq_name = gmdate( 'dmY' ) . '' . (int) microtime( true );
		$filename  = $uniq_name . '.' . $imagetype;

		$uploaddir  = wp_upload_dir();
		$uploadfile = $uploaddir['path'] . '/' . $filename;
		$contents   = file_get_contents( $image_url );
		$savefile   = fopen( $uploadfile, 'w' );
		fwrite( $savefile, $contents );
		fclose( $savefile );

		$wp_filetype = wp_check_filetype( basename( $filename ), null );
		$attachment  = array(
			'post_mime_type' => $wp_filetype['type'],
			'post_title'     => $filename,
			'post_content'   => '',
			'post_status'    => 'inherit',
		);

		$attach_id = $post_id ? wp_insert_attachment( $attachment, $uploadfile, $post_id, true ) : wp_insert_attachment( args: $attachment, file: $uploadfile, wp_error: true );

		if ( is_wp_error( $attach_id ) ) {
			return [ 'status' => 0 ];
		}

		$imagenew     = get_post( $attach_id );
		$fullsizepath = get_attached_file( $imagenew->ID );
		$attach_data  = wp_generate_attachment_metadata( $attach_id, $fullsizepath );
		wp_update_attachment_metadata( $attach_id, $attach_data );
		return [
			'status'        => 1,
			'thumbnail_id'  => $attach_id,
			'thumbnail_url' => wp_get_attachment_image_url( $attach_id ),
		];
	}

	public static function non_fetchable_js_translations() {
		return [
			__( 'year', 'kiranime' ),
			__( 'season', 'kiranime' ),
			_x( 'E', 'episode symbol for grid/slider', 'kiranime' ),

		];
	}

	/**
	 * Converts an image URL to its corresponding WordPress attachment ID.
	 *
	 * @param string|null $attachment_url The URL of the image to convert.
	 * @return int The ID of the corresponding WordPress attachment. If the URL is not found or failed to download, returns 0.
	 *
	 * @since 1.0.0
	 */
	public static function image_to_id( string|null $attachment_url = null ) {
		if ( empty( $attachment_url ) ) {
			return 0;
		}
		global $wpdb;

		$url     = str_ireplace( [ get_bloginfo( 'url' ), '-scaled.' ], [ '', '' ], $attachment_url );
		$results = $wpdb->get_col( $wpdb->prepare( "SELECT $wpdb->posts.ID FROM $wpdb->posts WHERE $wpdb->posts.guid LIKE %s", $url ) );

		if ( ! empty( $results ) ) {
			return $results[0];
		}

		$uploaded = self::get_remote_image( $attachment_url );
		if ( $uploaded['status'] ) {
			return $uploaded['thumbnail_id'];
		}

		return 0;
	}

	public static function get_no_image() {
		return KIRA_URI . '/avatar/no_image.png';
	}

	public static function get_season_system() {
		return [
			[
				'name' => __( 'Winter', 'kiranime' ),
				'slug' => 'winter',
				'id'   => 1,
			],
			[
				'name' => __( 'Spring', 'kiranime' ),
				'slug' => 'spring',
				'id'   => 2,
			],
			[
				'name' => __( 'Summer', 'kiranime' ),
				'slug' => 'summer',
				'id'   => 3,
			],
			[
				'name' => __( 'Fall', 'kiranime' ),
				'slug' => 'fall',
				'id'   => 4,
			],
		];
	}

	public static function get_advanced_orders() {

		$orderby = [];
		$orders  = [
			[
				'name' => __( 'Popular', 'kiranime' ),
				'key'  => 'popular',
			],
			[
				'name' => __( 'Favorite', 'kiranime' ),
				'key'  => 'favorite',
			],
			[
				'name' => __( 'Title', 'kiranime' ),
				'key'  => 'title',
			],
			[
				'name' => __( 'Date', 'kiranime' ),
				'key'  => 'date',
			],
			[
				'name' => __( 'Updated', 'kiranime' ),
				'key'  => 'updated',
			],
		];
		foreach ( $orders as $index => $v ) {
			$orderby[] = [
				'name' => $v['name'],
				'id'   => $index + 1,
				'slug' => $v['key'],
			];
		}

		$order = [
			[
				'name' => __( 'Ascending', 'kiranime' ),
				'id'   => 1,
				'slug' => 'asc',
			],
			[
				'name' => __( 'Descending', 'kiranime' ),
				'id'   => 2,
				'slug' => 'desc',
			],
		];

		return [
			'order'   => json_decode( json_encode( $order ), true ),
			'orderby' => $orderby,
		];
	}

	public static function get_advanced_search_queries( array|null $get = [] ) {
		$results = [];
		// get terms
		$terms_results = [
			'genre'    => get_terms( [ 'taxonomy' => 'genre' ] ),
			'status'   => get_terms( [ 'taxonomy' => 'status' ] ),
			'studio'   => get_terms( [ 'taxonomy' => 'studio' ] ),
			'producer' => get_terms( [ 'taxonomy' => 'producer' ] ),
			'licensor' => get_terms( [ 'taxonomy' => 'licensor' ] ),
			'type'     => get_terms( [ 'taxonomy' => 'type' ] ),
		];
		$selected      = [];
		$terms_data    = [];
		foreach ( $terms_results as $tax_name => $terms ) {
			if ( is_wp_error( $terms ) ) {
				continue;
			}

			foreach ( $terms as $term ) {
				$is_selected               = is_array( $get[ $tax_name ] ) ? in_array( $term->slug, $get[ $tax_name ] ) : false;
				$res                       = [
					'name'        => $term->name,
					'slug'        => $term->slug,
					'id'          => $term->term_id,
					'is_selected' => $is_selected,
				];
				$terms_data[ $tax_name ][] = $res;
				if ( $is_selected ) {
					$selected[ $tax_name ][] = $res;
				}
			}
		}

		$results['configs'] = [
			'usestatus'  => get_option( '__u_status_i_du' ),
			'useTooltip' => get_theme_mod( '__show_tooltip', 'show' ) === 'show',
			'watchlist'  => Kiranime_Watchlist::get_static_types(),
		];

		// season
		$season = self::get_season_system();

		if ( $get['season'] ) {
			$sl                 = array_filter( $season, fn ( $v ) => $v['slug'] === $get['season'] );
			$selected['season'] = array_shift( $sl );
		}

		// order & orderby
		$orders     = self::get_advanced_orders();
		$terms_data = array_merge( $terms_data, $orders, [ 'season' => $season ] );
		if ( $get['orderby'] ) {
			$order = $get['orderby'];
			if ( 'random' === $order ) {
				$order = 'popular';
			}
			$is_s                = array_filter( $orders['orderby'], fn ( $val ) => $val['slug'] === $order );
			$selected['orderby'] = array_shift( $is_s );
		}

		if ( $get['order'] ) {
			$sl                = array_filter( $orders['order'], fn ( $val ) => $val['slug'] === $get['order'] );
			$selected['order'] = array_shift( $sl );
		}

		// years
		foreach ( range( gmdate( 'Y' ) + 1, 1970 ) as $year ) {
			$terms_data['year'][] = [
				'name' => "$year",
				'slug' => "$year",
				'id'   => $year,
			];

			if ( $get['year'] && (int) $get['year'] === $year ) {
				$selected['year'] = [
					'name' => "$year",
					'slug' => "$year",
					'id'   => $year,
				];
			}
		}

		$results['terms']    = $terms_data;
		$results['selected'] = $selected;
		$results['orders']   = $orders;
		$results             = array_merge( $get, $results );

		return $results;
	}

	public static function BreadCrumb( array $links, bool $is_rank_math ) {
		if ( $is_rank_math && function_exists( 'rank_math_the_breadcrumbs' ) ) {
			rank_math_the_breadcrumbs();
		} else {
			$br = "<nav aria-label='breadcrumbs' class='mbe-5 text-xs font-medium'><ol class='flex gap-2 items-center flex-wrap'>";
			foreach ( $links as $key => $link ) {
				$url  = $link['url'];
				$name = $link['name'];
				$lk   = '<li>';
				$lk  .= "<a href='$url' title='$name'>$name</a>";
				$lk  .= '</li>';
				if ( $key !== ( count( $links ) - 1 ) ) :
					$lk .= '<span class="material-icons-round text-lg rtl:rotate-180">
                arrow_right
            </span>';
				endif;
				$br .= $lk;
			}

			$br .= '</ol></nav>';
			echo $br;
		}
	}

	public static function get_paginate_ajax_links( int $total = 1 ) {
		$range = range( 1, $total );
		return $range;
	}

	public static function get_watchlist_settings() {

		return [
			[
				'name'    => __( 'Watchlist Page Title', 'kiranime' ),
				'default' => '{{username}} Watchlist',
				'value'   => get_option( '__watchlist_title', '{{username}} Watchlist' ),
				'key'     => '__watchlist_title',
			],
			[
				'name'    => __( 'Watchlist Description', 'kiranime' ),
				'default' => '{{display_name}} public watchlist.',
				'value'   => get_option( '__watchlist_description', '{{display_name}} public watchlist.' ),
				'key'     => '__watchlist_description',
			],
		];
	}

	public static function set_watchlist_settings( array $settings = [] ) {
		foreach ( $settings as $setting ) {
			if ( empty( $setting['value'] ) ) {
				continue;
			}
			update_option( $setting['key'], $setting['value'] );
		}
	}

	public static function use_h1() {
		return is_single() || is_page() || is_archive();
	}

	public static function show( string $page, string|null $name = null, array $args = [] ) {
		return get_template_part( $page, $name, $args );
	}

	public static function random_str(
		int $length = 32,
		string $keyspace = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'
	): string {
		$keyspace = str_shuffle( $keyspace );

		if ( $length < 1 ) {
			throw new \RangeException( 'Length must be a positive integer' );
		}
		$pieces = [];
		$max    = mb_strlen( $keyspace, '8bit' ) - 1;
		for ( $i = 0; $i < $length; ++$i ) {
			$pieces[] = $keyspace[ random_int( 0, $max ) ];
		}
		return implode( '', $pieces );
	}

	/**
	 * Retrieves the view count in a human-readable format.
	 *
	 * This function takes a view count as a parameter and returns the count in a more readable format.
	 * If the count is greater than or equal to 1 billion, it is formatted as 'X.X B'.
	 * If the count is greater than or equal to 1 million, it is formatted as 'X.X M'.
	 * If the count is greater than or equal to 1 thousand, it is formatted as 'X.X K'.
	 * Otherwise, the count is returned as a string.
	 *
	 * @param int|string $count The view count to be formatted.
	 *
	 * @return string The formatted view count.
	 */
	public static function get_view_count( int|string $count = 0 ) {
		$views = (int) $count;

		if ( $views >= 1000000000 ) {
			return number_format( $views / 1000000000, 1 ) . 'B';
		} elseif ( $views >= 1000000 ) {
			return number_format( $views / 1000000, 1 ) . 'M';
		} elseif ( $views >= 1000 ) {
			return number_format( $views / 1000, 1 ) . 'K';
		} else {
			return (string) $views;
		}
	}

	public static function sanitize_text_array( array|null $array = [] ) {
		if ( empty( $array ) ) {
			return [];
		}
		return array_map( fn( $v )=> sanitize_text_field( $v ), $array );
	}

		/**
		 * Retrieves the widget options based on the provided key.
		 *
		 * @param string $key The unique key for the widget options.
		 *
		 * @return array The widget options associated with the provided key.
		 *               If the key is not found or the widget options are empty, an empty array is returned.
		 */
	public static function get_widget_options( string $key ) {
		global $wp_registered_widgets;

		if ( empty( $wp_registered_widgets[ $key ]['callback'] ) ) {
			return array();
		}

		/**
		 * WP_Widget instance if available.
		 *
		 * @var WP_Widget $widget */
		$widget = $wp_registered_widgets[ $key ]['callback'][0];

		$settings = $widget->get_settings();

		return $settings[ $widget->number ] ?: [];
	}

	public static function migrate_anime_data( array $animes = [] ) {
		$result = [];
		foreach ( $animes as $anime ) {
			$id   = $anime['ID'];
			$type = $anime['post_type'];

			if ( empty( $id ) ) {
				return false;
			}

			if ( empty( $type ) ) {
				$type = get_post_type( $id );
			}

			$prefix = MetaPrefix::fromName( $type );
			$anime  = 'anime' === $type ? new Anime( $id ) : new Episode( $id );

			$migrated = $anime->get( $prefix->value . 'metadata', true );
			if ( ! empty( $migrated ) ) {
				$anime->sets( KiraType::fromName( $type ), json_decode( $migrated, true ) ?: [] );
				$result[] = [
					'updated'         => false,
					'deleted'         => 0,
					'meta'            => [],
					'id'              => $id,
					'type'            => $prefix,
					'keys'            => [],
					'saved'           => [],
					'already_updated' => true,
				];

				continue;
			}

			$keys      = $anime->meta_keys[ $type ];
			$save_meta = [];
			$deleted   = 0;
			foreach ( $keys as $key ) {
				$value = $anime->get( $prefix->value . $key );

				if ( 'characters' === $key ) {
					$value = is_string( $value ) ? json_decode( $value, true ) : $value;
				}

				$save_meta[ $key ] = $value;
				$dell              = delete_post_meta( $id, $prefix->value . $key );
				if ( $dell ) {
					++$deleted;
				}
			}

			$updated = false;
			if ( $deleted > 0 ) {
				$anime->sets( KiraType::fromName( $type ), $save_meta );
				$updated = true;
			}
			$result[] = [
				'updated'         => $updated,
				'deleted'         => $deleted,
				'meta'            => json_decode( $anime->get( $prefix->value . 'metadata', true ) ),
				'id'              => $id,
				'type'            => $prefix,
				'keys'            => $keys,
				'saved'           => $save_meta,
				'already_updated' => false,
			];
		}

		return $result;
	}

	public static function debug( mixed $value ) {
		echo '<pre>';
		print_r( $value );
		echo '</pre>';
	}

	/**
	 * Retrieves a human-readable relative time difference between the current time and a given date.
	 *
	 * This function calculates the difference between the current time and the provided date,
	 * and returns a human-readable string representing the time difference.
	 *
	 * @param int $date The timestamp of the date to compare with the current time. Default is 0 (current time).
	 *
	 * @return string The human-readable relative time difference.
	 *
	 * @since 1.0.0
	 */
	public static function get_relative_time( int $date = 0 ) {
		$diff = time() - $date;
		/* translators: Show relative time in seconds. */
		$periods[] = array( 60, 1, __( '%s seconds', 'kiranime' ), __( 'a second', 'kiranime' ) );
		/* translators: Show relative time in minues. */
		$periods[] = array( 60 * 100, 60, __( '%s minutes', 'kiranime' ), __( 'one minute', 'kiranime' ) );
		/* translators: Show relative time in hours. */
		$periods[] = array( 3600 * 70, 3600, __( '%s hours', 'kiranime' ), __( 'an hour', 'kiranime' ) );
		/* translators: Show relative time in days. */
		$periods[] = array( 3600 * 24 * 10, 3600 * 24, __( '%s days', 'kiranime' ), __( 'yesterday', 'kiranime' ) );
		/* translators: Show relative time in weeks. */
		$periods[] = array( 3600 * 24 * 30, 3600 * 24 * 7, __( '%s weeks', 'kiranime' ), __( 'one week', 'kiranime' ) );
		/* translators: Show relative time in months. */
		$periods[] = array( 3600 * 24 * 30 * 30, 3600 * 24 * 30, __( '%s months', 'kiranime' ), __( 'last month', 'kiranime' ) );
		/* translators: Show relative time in years. */
		$periods[] = array( INF, 3600 * 24 * 265, __( '%s years', 'kiranime' ), __( 'last year', 'kiranime' ) );
		foreach ( $periods as $period ) {
			if ( $diff > $period[0] ) {
				continue;
			}
			$diff = floor( $diff / $period[1] );
			return sprintf( $diff > 1 ? $period[2] : $period[3], $diff );
		}

		return human_time_diff( $date );
	}
}
