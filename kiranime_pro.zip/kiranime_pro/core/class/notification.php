<?php

/**
 * This is class for user notification
 *
 * @package   Kiranime
 * @since   1.0.0
 * @link      https://kiranime.moe
 * @author    Dzul Qurnain
 * @license   GPL-2.0+
 */
class Kiranime_Notification {

	/**
	 * This function sends notifications to subscribers about new episodes.
	 *
	 * @param int $episode_id The ID of the episode to notify about.
	 * @param int $anime_id The ID of the anime the episode belongs to. If not provided, it will be fetched from the episode's meta.
	 * @param int $episode_number The episode number. If not provided, it will be fetched from the episode's meta.
	 *
	 * @return void
	 */
	public static function notify( $episode_id = 0, $anime_id = 0, $episode_number = 0 ) {

		$anime_id = isset( $anime_id ) ? $anime_id : get_post_meta( $episode_id, 'kiranime_episode_parent_id', true );
		$number   = $episode_number ? $episode_number : get_post_meta( $episode_id, 'kiranime_episode_number', true );

		$subscribers = Kiranime_Watchlist::get_users( $anime_id );

		foreach ( $subscribers as $subscriber ) {
			$get = new WP_Query(
				[
					'post_type'           => 'notification',
					'author'              => $subscriber,
					'ignore_sticky_posts' => true,
					'no_found_rows'       => true,
					'fields'              => 'ids',
				]
			);

			if ( ! $get->post_count ) {
				$id = wp_insert_post(
					[
						'post_type'   => 'notification',
						'post_title'  => 'notification_for_' . $subscriber,
						'post_status' => 'publish',
						'post_author' => $subscriber,
					],
					true,
					false
				);

				if ( $id && ! is_wp_error( $id ) ) {
					update_post_meta(
						$id,
						'notification_update',
						json_encode(
							[
								[
									'episode_id'      => $episode_id,
									'status'          => false,
									'anime_id'        => $anime_id,
									'notification_id' => $episode_id . $anime_id,
									'number'          => $number,
								],
							]
						)
					);
				}
			} else {
				$id   = array_shift( $get->posts );
				$meta = get_post_meta( $id, 'notification_update', true );
				$meta = $meta ? json_decode( $meta, true ) : [];

				if ( ! is_array( $meta ) ) {
					$meta = [];
				}

				$in_array = array_filter( $meta, fn ( $val ) => $val['episode_id'] === $episode_id );

				if ( empty( $in_array ) ) {
					array_push(
						$meta,
						[
							'episode_id'      => $episode_id,
							'status'          => false,
							'anime_id'        => $anime_id,
							'notification_id' => 'es' . $episode_id . 'nea' . $anime_id,
							'number'          => $number,
						]
					);
					update_post_meta( $id, 'notification_update', json_encode( $meta ) );
				}
			}
		}
	}

	/**
	 * This function checks and updates the status of notifications for a user.
	 *
	 * @param array $notification_id An array of notification IDs to check.
	 * @param int   $user_id          The ID of the user whose notifications to check.
	 *
	 * @return array An array containing the updated notifications.
	 *               If no notifications are provided, an empty array is returned.
	 */
	public static function checked( $notification_id, $user_id ) {
		if ( ! is_array( $notification_id ) || count( $notification_id ) === 0 ) {
			return [ 'results' => [] ];
		}

		$get = new WP_Query(
			[
				'post_type'           => 'notification',
				'author'              => $user_id,
				'ignore_sticky_posts' => true,
				'no_found_rows'       => true,
			]
		);

		$meta = $get->post_count ? get_post_meta( $get->posts[0]->ID, 'notification_update', true ) : '[]';
		$meta = $meta ? (array) json_decode( $meta, true ) : [];

		$new_notif = [];
		foreach ( $meta as $n ) {
			if ( ! in_array( $n['notification_id'], $notification_id ) ) {
				$new_notif[] = $n;
			}
		}

		update_post_meta( $get->posts[0]->ID, 'notification_update', json_encode( $new_notif ) );

		return [ 'results' => $new_notif ];
	}

	/**
	 * This function retrieves an array of anime data from given notifications.
	 *
	 * @param array $notifications An array of notification objects containing episode_id and anime_id.
	 *
	 * @return array|bool An array of anime data if notifications are provided, false otherwise.
	 *                    Each anime data contains title, anime_id, url, published time, and episode number.
	 */
	public static function get_anime( $notifications ) {
		if ( ! is_array( $notifications ) || count( $notifications ) === 0 ) {
			return false;
		}

		$result = [];
		foreach ( $notifications as $notif ) {
			$episode = get_post( $notif->episode_id );
			$anime   = get_post( $notif->anime_id );

			$result[] = [
				'title'     => $anime->post_title,
				'anime_id'  => $notif->anime_id,
				'url'       => get_post_permalink( $episode->ID ),
				'published' => human_time_diff( get_the_time( 'G', $episode ) ),
				'number'    => get_post_meta( $episode->ID, 'kiranime_episode_number', true ),
			];
		}

		return $result;
	}

	/**
	 * Retrieves an array of notifications for the current user.
	 *
	 * @param bool $is_header Whether to return notifications for the header.
	 *                        If true, the function will return notifications with smaller featured images.
	 *
	 * @return array An array of notifications. Each notification contains the following keys:
	 *               - title: The title of the anime.
	 *               - anime_id: The ID of the anime.
	 *               - url: The URL of the episode.
	 *               - published: The time difference between the current time and the episode's publication time.
	 *               - number: The episode number.
	 *               - status: The status of the notification.
	 *               - featured: The HTML for the featured image of the anime.
	 *               - notif_id: The ID of the notification.
	 */
	public static function get( bool $is_header = false ) {
		$uid = get_current_user_id();

		$get = new WP_Query(
			[
				'post_type'           => 'notification',
				'author'              => $uid,
				'ignore_sticky_posts' => true,
				'no_found_rows'       => true,
			]
		);

		$meta = $get->post_count ? get_post_meta( $get->posts[0]->ID, 'notification_update', true ) : false;
		$meta = $meta ? (array) json_decode( $meta ) : [];

		$results = [];
		foreach ( $meta as $notif ) {

			if ( ! isset( $notif->episode_id ) || empty( $notif->episode_id ) ) {
				if ( isset( $notif->notification_id ) ) {
					self::delete( $notif->notification_id, get_current_user_id() );
				}
				continue;
			}

			$episode = new Episode( $notif->episode_id );

			if ( ! isset( $episode->empty ) || $episode->empty ) {
				if ( isset( $notif->notification_id ) ) {
					self::delete( $notif->notification_id, get_current_user_id() );
				}
				continue;
			}
			$episode->gets( MetaPrefix::episode );
			if ( $notif->anime_id ) {
				$anime = new Anime( $notif->anime_id );
			} elseif ( $episode->meta['parent_id'] ) {
				$anime = new Anime( $episode->meta['parent_id'] );
			} else {
				self::delete( $notif->notification_id, get_current_user_id() );
				continue;
			}

			$results[] = [
				'title'     => $anime->post->post_title,
				'anime_id'  => $anime->id,
				'url'       => $episode->url,
				'published' => human_time_diff( get_the_time( 'G', $episode->post ) ),
				'number'    => $episode->meta['number'],
				'status'    => $notif->status,
				'featured'  => $anime->get_featured(
					type: KiraType::episode,
					size: $is_header ? 'smallthumb' : 'kirathumb',
					attributes: [
						'class' => $is_header ? 'w-full h-full object-cover absolute inset-0' : 'absolute inset-0',
						'alt'   => $anime->post->post_title,
					]
				)->images['featured_html'],
				'notif_id'  => $notif->notification_id,
			];
		}

		return $results;
	}

	/**
	 * Deletes a notification for a user based on the given notification ID.
	 *
	 * @param string $notification_id The ID of the notification to delete.
	 * @param int    $user_id          The ID of the user whose notification to delete.
	 *
	 * @return array An array containing the status of the deletion operation.
	 *               If the notification ID is not provided, the function returns an array with 'data' set to 'no notification to delete.' and 'status' set to 200.
	 *               If the user has no notifications, the function returns an array with 'data' set to 'no notification to delete.' and 'status' set to 200.
	 *               If the deletion is successful, the function returns an array with 'data' set to true and 'status' set to 204.
	 */
	public static function delete( $notification_id, $user_id ) {
		if ( ! isset( $notification_id ) ) {
			return [
				'data'   => 'no notification to delete.',
				'status' => 200,
			];
		}

		$get = new WP_Query(
			[
				'post_type'           => 'notification',
				'author'              => $user_id,
				'ignore_sticky_posts' => true,
				'no_found_rows'       => true,
			]
		);

		if ( ! $get->post_count ) {
			return [
				'data'   => 'no notification to delete.',
				'status' => 200,
			];
		}

		$meta = get_post_meta( $get->posts[0]->ID, 'notification_update', true );
		$meta = $meta ? (array) json_decode( $meta, true ) : [];

		$meta = array_filter(
			$meta,
			function ( $val ) use ( $notification_id ) {
				return $notification_id !== $val['notification_id'];
			}
		);

		update_post_meta( $get->posts[0]->ID, 'notification_update', json_encode( $meta ) );
		return [
			'data'   => true,
			'status' => 204,
		];
	}
}
