<?php
/**
 * Class for kiranime rendering
 *
 * @package   Kiranime
 * @since   2.0.0
 * @link      https://kiranime.moe
 * @author    Dzul Qurnain
 * @license   GPL-2.0+
 */
class Render {

	/**
	 * Displays the options page for Kiranime settings.
	 *
	 * @param array $options An array of options to be displayed on the settings page.
	 *
	 * @return void
	 */
	public static function options( array $options = [] ) {
		$tabs = array_keys( $options );
		?>
	<div class="w-full lg:w-[95%]">
		<h1 class="mb-5 font-medium leading-loose text-xl">
			Kiranime Settings
		</h1>
		<div class="tabcontent flex items-center justify-start my-5 flex-wrap">
			<?php foreach ( $tabs as $index => $tab ) : ?>
				<div class="px-6 py-2 text-sm font-semibold cursor-pointer border-ie border-accent-2 last:border-none <?php echo 0 === $index ? 'bg-accent-2 text-text-color' : 'bg-white'; ?>" data-tab-for="<?php echo $tab; ?>"><?php echo $tab; ?></div>
			<?php endforeach; ?>
		</div>
		<form method="post" action="options.php" novalidate="novalidate">
			<?php
			settings_fields( 'kiranime_settings' );
			?>
			<?php foreach ( $options as $name => $data_options ) : ?>
				<table data-content-for="<?php echo $name; ?>" class="form-table <?php echo $name !== $tabs[0] ? 'hidden' : ''; ?>">
					<?php if ( 'Cache' === $name ) : ?>
						<tr>
							<th scope="row">
								<label for="clear_all_cache"><?php esc_attr_e( 'Clear Cache', 'kiranime' ); ?></label>
							</th>
							<td>
							<p class="submit">
								<button type="button" class="button button-primary" id="clear-cache-data"><?php esc_attr_e( 'Clear', 'kiranime' ); ?></button>					<span class="spinner"></span>
							</p>
							</td>
						</tr>
					<?php endif; ?>
					<?php foreach ( $data_options as $option ) : ?>
						<tr>
							<th scope="row">
								<label for="<?php echo $option['key']; ?>"><?php echo $option['name']; ?></label>
							</th>
							<td>
								<?php if ( 'input' === $option['type'] ) : ?>
									<?php if ( 'checkbox' === $option['input_type'] ) : ?>
										<input class="w-full text-sm" type="checkbox" name="<?php echo $option['key']; ?>" id="<?php echo $option['key']; ?>" <?php checked( ! empty( $option['value'] ) ); ?>>
									<?php else : ?>
										<input class="w-full text-sm" type="<?php echo $option['input_type']; ?>" name="<?php echo $option['key']; ?>" id="<?php echo $option['key']; ?>" value="<?php echo $option['value']; ?>" >
									<?php endif; ?>
								<?php elseif ( 'select' === $option['type'] ) : ?>
									<select name="<?php echo $option['key']; ?>" id="<?php echo $option['key']; ?>">
										<?php
										foreach ( $option['options'] as $value => $data ) :
											$enabled = is_array( $data ) ? $data['enabled'] : true;
											$val     = is_array( $data ) ? $data['name'] : $data;
											?>
											<option value="<?php echo $value; ?>" <?php selected( $option['value'], $value ); ?> <?php disabled( true, ! $enabled ); ?>><?php echo $val; ?></option>
										<?php endforeach; ?>
									</select>
								<?php elseif ( 'textarea' === $option['type'] ) : ?>
									<textarea name="<?php echo $option['key']; ?>" id="<?php echo $option['key']; ?>" rows="6" class="w-full text-sm"><?php echo $option['value']; ?></textarea>
								<?php endif; ?>
								<?php if ( ! empty( $option['info'] ) ) : ?>
								<p class="description" id="tagline-description"><?php echo $option['info']; ?></p>
								<?php endif; ?>
							</td>
						</tr>
					<?php endforeach; ?>
				</table>
			<?php endforeach; ?>
			<?php submit_button( 'Save Settings' ); ?>
		</form>
	</div>
	<script>
		let tabs = document.querySelectorAll('[data-tab-for]');
		let contents = document.querySelectorAll('[data-content-for]');
		tabs.forEach(e=>{
			e.addEventListener('click', ()=>{
				tabs.forEach(tab=>{
					tab.classList.remove('bg-accent-2', 'text-text-color')
					tab.classList.add('bg-white');
				});
				e.classList.remove('bg-white');
				e.classList.add('bg-accent-2', 'text-text-color');
				contents.forEach(content=>content.classList.add('hidden'));
				document.querySelector(`[data-content-for="${e.dataset.tabFor}"]`).classList.remove('hidden');
			})
		})
	</script>
			<?php
	}

	/**
	 * Renders and displays the grabber tabs.
	 *
	 * @param array $options An associative array containing the tab names as keys and their corresponding functions as values.
	 */
	public static function render_grabber( array $options = [] ) {
		$tabs = array_keys( $options );
		?>
	<div>
	<div class="w-full lg:w-[95%]">
		<h1 class="mb-5 font-medium leading-loose text-xl">
			Kiranime Grabbers
		</h1>
		<div class="tabcontent flex items-center justify-start my-5">
			<?php foreach ( $tabs as $index => $tab ) : ?>
				<div class="px-6 py-2 text-sm font-semibold cursor-pointer border-ie border-accent-2 last:border-none <?php echo 0 === $index ? 'bg-accent-2 text-text-color' : 'bg-white'; ?>" data-tab-for="<?php echo $tab; ?>"><?php echo $tab; ?></div>
			<?php endforeach; ?>
		</div>
		<?php foreach ( $options as $name => $func ) : ?>
			<div data-content-for="<?php echo $name; ?>" class="<?php echo $name !== $tabs[0] ? 'hidden' : ''; ?>">
			<?php
			echo match ( $name ) {
				'Anime Info' => kiranime_anime_grabber(),
				'Episode Info'=> kiranime_episode_grabber(),
				'Episode Importer'=> kiranime_episode_importer()
			}
	?>
			</div>
				<?php endforeach; ?>
	<script>
		let tabs = document.querySelectorAll('[data-tab-for]');
		let contents = document.querySelectorAll('[data-content-for]');
		tabs.forEach(e=>{
			e.addEventListener('click', ()=>{
				tabs.forEach(tab=>{
					tab.classList.remove('bg-accent-2', 'text-text-color')
					tab.classList.add('bg-white');
				});
				e.classList.remove('bg-white');
				e.classList.add('bg-accent-2', 'text-text-color');
				contents.forEach(content=>content.classList.add('hidden'));
				document.querySelector(`[data-content-for="${e.dataset.tabFor}"]`).classList.remove('hidden');
			})
		})
	</script>
	</div>
	</div>
		<?php
	}

	/**
	 * Retrieves and prepares the data for the active featured sections on the home page.
	 *
	 * This function fetches the maximum count of featured items from the theme mod, retrieves the status terms,
	 * and then constructs the default configurations for each featured section. It then iterates over the
	 * default configurations, populates the data array, and returns it.
	 *
	 * @return array An associative array containing the data for the active featured sections.
	 */
	private function get_active_featured() {
		$max_count    = get_theme_mod( '__featured_count', 7 );
		$statuses     = get_terms(
			[
				'taxonomy'   => 'status',
				'hide_empty' => true,
				'fields'     => 'id=>slug',
			]
		);
		$completed_id = 0;
		$others       = [];
		$airing       = 0;
		foreach ( $statuses as $id => $status ) {
			$others[] = $id;
			if ( 'completed' === $status ) {
				$completed_id = $id;
				continue;
			}
			if ( 'airing' === $status ) {
				$airing = $id;
			}
		}
		$data = [];

		$default = [
			'popular'   => [
				'archive' => '?s_orderby=popular',
				'title'   => __( 'Most Popular', 'kiranime' ),
				'show'    => get_theme_mod( 'show_most_popular', 'show' ) === 'show',
				'query'   => new WP_Query(
					[
						'post_type'           => 'anime',
						'post_status'         => 'publish',
						'tax_query'           => [
							[
								'taxonomy' => 'status',
								'field'    => 'term_id',
								'terms'    => $others,
							],
						],
						'posts_per_page'      => $max_count,
						'no_found_rows'       => 1,
						'ignore_sticky_posts' => 1,
						'meta_key'            => 'total_kiranime_views',
						'meta_value'          => 0,
						'meta_compare'        => '>=',
						'meta_type'           => 'NUMERIC',
						'orderby'             => 'meta_value_num',
						'order'               => 'DESC',
					]
				),
			],
			'completed' => [
				'archive' => '?s_orderby=popular&s_status[]=completed',
				'title'   => __( 'Completed Series', 'kiranime' ),
				'show'    => get_theme_mod( 'show_completed_series', 'show' ) === 'show',
				'query'   => new WP_Query(
					[
						'post_type'           => 'anime',
						'post_status'         => 'publish',
						'tax_query'           => [
							[
								'taxonomy' => 'status',
								'field'    => 'term_id',
								'terms'    => $completed_id,
							],
						],
						'posts_per_page'      => $max_count,
						'no_found_rows'       => 1,
						'ignore_sticky_posts' => 1,
						'meta_key'            => 'total_kiranime_views',
						'meta_value'          => 0,
						'meta_compare'        => '>=',
						'meta_type'           => 'NUMERIC',
						'orderby'             => 'meta_value_num',
						'order'               => 'DESC',
					]
				),

			],
			'favorite'  => [
				'archive' => '?s_orderby=favorite&asp=1',
				'title'   => __( 'Most Favorite', 'kiranime' ),
				'show'    => get_theme_mod( 'show_most_favorite', 'show' ) === 'show',
				'query'   => new WP_Query(
					[
						'post_type'           => 'anime',
						'post_status'         => 'publish',
						'meta_key'            => 'bookmark_count',
						'meta_value'          => 0,
						'meta_compare'        => '>',
						'meta_type'           => 'NUMERIC',
						'posts_per_page'      => $max_count,
						'no_found_rows'       => true,
						'ignore_sticky_posts' => true,
						'orderby'             => 'meta_value_num',
						'order'               => 'DESC',
					]
				),
			],
			'airing'    => [
				'archive' => '?s_orderby=popular&s_status[]=airing',
				'title'   => __( 'Top Airing!', 'kiranime' ),
				'show'    => get_theme_mod( 'show_top_airing', 'show' ) === 'show',
				'query'   => new WP_Query(
					[
						'post_type'           => 'anime',
						'post_status'         => 'publish',
						'posts_per_page'      => $max_count,
						'no_found_rows'       => true,
						'ignore_sticky_posts' => true,
						'orderby'             => 'date',
						'order'               => 'DESC',
						'tax_query'           => [
							[
								'taxonomy' => 'status',
								'field'    => 'term_id',
								'terms'    => $airing,
							],
						],
					]
				),
			],
		];
		foreach ( [ 'airing', 'popular', 'favorite', 'completed' ] as $name ) {
			$data[ $name ] = [
				'title'   => $default[ $name ]['title'],
				'query'   => $default[ $name ]['query'],
				'active'  => $default[ $name ]['show'],
				'archive' => Kira_Utility::page_link( 'pages/search.php' ) . $default[ $name ]['archive'],
			];
		}

		return $data;
	}

	/**
	 * Counts and echoes the number of active featured sections.
	 *
	 * @since 1.0.0
	 */
	public static function active_featured() {
		$instances = [
			get_theme_mod( 'show_most_popular', 'show' ) === 'show',
			get_theme_mod( 'show_completed_series', 'show' ) === 'show',
			get_theme_mod( 'show_most_favorite', 'show' ) === 'show',
			get_theme_mod( 'show_top_airing', 'show' ) === 'show',
		];

		echo count( array_filter( $instances, fn ( $v ) => (bool) $v ) );
	}

	/**
	 * Renders and displays the featured sections on the home page.
	 *
	 * This function retrieves the active featured sections' configurations, checks if they are cached,
	 * and renders them accordingly. If the sections are not cached, it fetches the data, generates the
	 * HTML, and caches it for future use.
	 *
	 * @since 1.0.0
	 */
	public static function featured() {
		$cache  = new Kiranime_Cache( 'widget_block' );
		$cached = $cache->get( 'current_featured_cache' );

		if ( empty( $cached ) ) {
			$r       = new self();
			$configs = $r->get_active_featured();
			ob_start();
			foreach ( $configs as $part => $opts ) :
				if ( $opts['active'] ) {
					get_template_part( 'template-parts/sections/home', 'featured', $opts );
				}
			endforeach;

			$cached = ob_get_clean();
			$cache->set( 'current_featured_cache', $cached, get_option( '__kira_cache_time', 3600 ) );
		}

		echo $cached;
	}

	public static function popular_list( array $instance ) {
		$d_title = $instance['title'] ?? 'Popular';
		$status  = $instance['status'] ?? null;
		$title   = apply_filters( 'widget_title', $d_title );
		$suffix  = '_kiranime_views';
		$queries = [
			'day'   => gmdate( 'dmY' ) . $suffix,
			'week'  => gmdate( 'WY' ) . $suffix,
			'month' => gmdate( 'FY' ) . $suffix,
		];

		$res           = [];
		$default_query = [
			'orderby'        => 'meta_value_num',
			'meta_value'     => 0,
			'meta_compare'   => '>',
			'posts_per_page' => 10,
		];
		if ( ! empty( $status ) && 'all' !== $status ) {
			$default_query['tax_query'] = [
				'RELATION' => 'AND',
				[
					'taxonomy' => 'status',
					'field'    => 'term_id',
					'terms'    => $status,
				],
			];
		}
		foreach ( $queries as $key => $query ) {
			$default_query['meta_key'] = $query;
			$q                         = new Kira_Query( $default_query );
			$res[ $key ]               = ! $q->empty ? $q->animes : [];
		}

		?>
		<div class="w-full">
			<div class="mie-4 md:pli-5 lg:pli-0 plb-2 sm:mbe-4">
				<h2 class="text-lg lg:text-xl xl:text-2xl leading-10 font-semibold p-0 m-0 text-accent"><?php echo $title; ?></h2>
			</div>
			<div class="grid grid-cols-3 bg-darker rounded-t-md">
				<div data-tab-id="day" class="w-full p-2 plb-3 text-sm font-medium cursor-pointer rounded-tl-md bg-secondary text-center" onclick="selectPopularTab(0)">
					<?php esc_html_e( 'Today', 'kiranime' ); ?>
				</div>
				<div data-tab-id="week" class="w-full p-2 plb-3 text-sm font-medium cursor-pointer text-center" onclick="selectPopularTab(1);">
					<?php esc_html_e( 'Week', 'kiranime' ); ?>
				</div>
				<div data-tab-id="month" class="w-full p-2 plb-3 text-sm font-medium cursor-pointer text-center rounded-tr-md" onclick="selectPopularTab(2);">
					<?php esc_html_e( 'Month', 'kiranime' ); ?>
				</div>
			</div>

			<?php
			foreach ( $res as $index => $animes ) :
				?>
				<div data-tab-content="<?php echo $index; ?>" class="p-4 bg-overlay w-full <?php echo $index === 'day' ? '' : 'hidden'; ?>">
					<ul class="grid grid-cols-1 gap-5">
						<?php
						foreach ( $animes as $key => $anime ) :
							$anime
								->gets( MetaPrefix::anime )
								->get_featured( type: KiraType::anime, size: 'smallthumb', attributes: [ 'class' => 'popular-list-image' ] )
								->get_statistic();

							$en_title = $anime->meta['english'] ?? '';
							$title    = $anime->post->post_title;

							?>
							<li class=" flex items-center gap-5">
								<div data-popular-add-to-list="<?php echo esc_attr( $anime->id ); ?>" class=" w-10 transform -translate-y-1 text-center flex-shrink-0 flex-grow-0 group">
									<span class="text-xl font-semibold pbe-2 border-b-2 border-accent-3 group-hover:hidden"><?php echo $key < 9 ? '0' . ( $key + 1 ) : ( $key + 1 ); ?></span>
									<svg xmlns="http://www.w3.org/2000/svg" class="w-5 h-5 mli-auto hidden group-hover:block cursor-pointer" viewBox="0 0 448 512">
										<path fill="currentColor" d="M416 208H272V64c0-17.67-14.33-32-32-32h-32c-17.67 0-32 14.33-32 32v144H32c-17.67 0-32 14.33-32 32v32c0 17.67 14.33 32 32 32h144v144c0 17.67 14.33 32 32 32h32c17.67 0 32-14.33 32-32V304h144c17.67 0 32-14.33 32-32v-32c0-17.67-14.33-32-32-32z" />
									</svg>
								</div>

								<div class="flex-auto flex gap-2 overflow-hidden">
									<?php echo $anime->images['featured_html']; ?>
									<div>
										<h3 class="line-clamp-2 text-sm leading-6">
											<a href="<?php echo esc_url( $anime->url ); ?>" title="<?php echo esc_html( $title ); ?>">
												<?php if ( ! empty( $en_title ) ) : ?>
													<span data-en-title><?php echo esc_html( $en_title ); ?></span>
													<span data-nt-title class="show"><?php echo esc_html( $title ); ?></span>
												<?php else : ?>
													<?php echo esc_html( $title ); ?>
												<?php endif; ?>
											</a>
										</h3>
										<div class="text-xs">
											<span class="flex items-center gap-1">
												<svg xmlns="http://www.w3.org/2000/svg" class="w-[1.125rem] h-[1.125rem]" viewBox="0 0 24 24"><path fill="currentColor" d="M17.66 11.2c-.23-.3-.51-.56-.77-.82c-.67-.6-1.43-1.03-2.07-1.66C13.33 7.26 13 4.85 13.95 3c-.95.23-1.78.75-2.49 1.32c-2.59 2.08-3.61 5.75-2.39 8.9c.04.1.08.2.08.33c0 .22-.15.42-.35.5c-.23.1-.47.04-.66-.12a.6.6 0 0 1-.14-.17c-1.13-1.43-1.31-3.48-.55-5.12C5.78 10 4.87 12.3 5 14.47c.06.5.12 1 .29 1.5c.14.6.41 1.2.71 1.73c1.08 1.73 2.95 2.97 4.96 3.22c2.14.27 4.43-.12 6.07-1.6c1.83-1.66 2.47-4.32 1.53-6.6l-.13-.26c-.21-.46-.77-1.26-.77-1.26m-3.16 6.3c-.28.24-.74.5-1.1.6c-1.12.4-2.24-.16-2.9-.82c1.19-.28 1.9-1.16 2.11-2.05c.17-.8-.15-1.46-.28-2.23c-.12-.74-.1-1.37.17-2.06c.19.38.39.76.63 1.06c.77 1 1.98 1.44 2.24 2.8c.04.14.06.28.06.43c.03.82-.33 1.72-.93 2.27"/></svg>	
												<?php echo Kira_Utility::get_view_count( $anime->statistic[ $index ] ); ?> <?php esc_html_e( 'views', 'kiranime' ); ?>
											</span>
										</div>
									</div>
								</div>
							</li>
						<?php endforeach; ?>

					</ul>
				</div>
			<?php endforeach; ?>
		</div>
		<?php
	}
}
