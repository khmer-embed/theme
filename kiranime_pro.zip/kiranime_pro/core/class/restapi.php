<?php

/**
 * Kiranime rest api endpoint
 *
 * @package   Kiranime
 * @since     1.0.0
 * @link      https://kiranime.moe
 * @author    Dzul Qurnain
 */
class Kiranime_Endpoint extends WP_REST_Controller {


	/**
	 * Register the routes for the objects of the controller.
	 */
	public function register_routes() {
		$version   = '1';
		$namespace = 'kiranime/v' . $version;
		register_rest_route(
			$namespace,
			'/kiranime',
			[
				[
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => [ $this, 'get_act_status' ],
					'permission_callback' => '__return_true',
					'args'                => [],
				],
			]
		);
		register_rest_route(
			$namespace,
			'/migrate/anime',
			[
				[
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => [ $this,'get_migrate_anime_data' ],
					'permission_callback' => '__return_true',
					'args'                => [],
				],
				[
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => [ $this, 'migrate_anime_data' ],
					'permission_callback' => [ $this, 'is_allowed_to_edit' ],
					'args'                => [],
				],
				[
					'methods'             => WP_REST_Server::DELETABLE,
					'callback'            => [ $this, 'migrate_anime_data_delete' ],
					'permission_callback' => [ $this, 'is_allowed_to_edit' ],
					'args'                => [],
				],
			]
		);
		register_rest_route(
			$namespace,
			'/global_nonce',
			[
				[
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => [ $this, 'get_global_nonce' ],
					'permission_callback' => '__return_true',
					'args'                => [],
				],
			]
		);
		register_rest_route(
			$namespace,
			'/admin/post/anime',
			[
				[
					'method'              => WP_REST_Server::READABLE,
					'callback'            => [ $this, 'get_season_anime_search' ],
					'permission_callback' => '__return_true',
					'args'                => [],
				],
			]
		);
		register_rest_route(
			$namespace,
			'/taxonomy',
			[
				[
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => [ $this, 'create_taxonomy' ],
					'permission_callback' => function () {
						return current_user_can( 'edit_posts' );
					},
					'args'                => [
						'name'     => [
							'type'              => 'string',
							'required'          => true,
							'validate_callback' => function ( $val ) {
								return is_string( $val );
							},
						],
						'taxonomy' => [
							'type'              => 'string',
							'required'          => true,
							'validate_callback' => function ( $val ) {
								return is_string( $val );
							},
						],
						'slug'     => [
							'type' => 'string',
						],
					],
				],
				[
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => [ $this, 'get_taxonomies' ],
					'permission_callback' => '__return_true',
					'args'                => [
						'name' => [
							'type'     => 'string',
							'required' => true,
						],
					],
				],
			]
		);
		register_rest_route(
			$namespace,
			'/kira-cache',
			[
				[

					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => [ $this, 'remove_kira_cache' ],
					'permission_callback' => [ $this, 'is_allowed' ],
					'args'                => [],
				],
			]
		);
		register_rest_route(
			$namespace,
			'/savethemekey',
			[
				[
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => [ $this, 'save_theme_key' ],
					'permission_callback' => function () {
						return current_user_can( 'manage_options' );
					},
					'args'                => [],
				],
			]
		);
		register_rest_route(
			$namespace,
			'/remove_active',
			[
				[
					'methods'             => WP_REST_Server::DELETABLE,
					'callback'            => [ $this, 'remove_theme_key' ],
					'permission_callback' => function () {
						return current_user_can( 'manage_options' );
					},
					'args'                => [],
				],
			]
		);
		register_rest_route(
			$namespace,
			'/watchlist_get',
			[
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => [ $this, 'get_watchlist' ],
				'permission_callback' => '__return_true',
				'args'                => [
					'type'     => [
						'type'    => 'string',
						'default' => 'all',
					],
					'per_page' => [
						'type'    => 'integer',
						'default' => 20,
					],
					'page'     => [
						'type'    => 'integer',
						'default' => 1,
					],
				],
			],
		);
		register_rest_route(
			$namespace,
			'/watchlist',
			[

				[
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => [ $this, 'add_watchlist' ],
					'permission_callback' => [ $this, 'is_allowed' ],
					'args'                => [
						'user_id'  => [
							'type'              => 'integer',
							'required'          => true,
							'validate_callback' => function ( $val ) {
								return is_numeric( $val );
							},
						],
						'type'     => [
							'type'    => 'string',
							'default' => 'all',
						],
						'anime_id' => [
							'type'              => 'integer',
							'required'          => true,
							'validate_callback' => function ( $val ) {
								return is_numeric( $val );
							},
						],
					],
				],
				[
					'methods'             => WP_REST_Server::DELETABLE,
					'callback'            => [ $this, 'delete_watchlist' ],
					'permission_callback' => [ $this, 'is_allowed' ],
					'args'                => [
						'user_id'  => [
							'type'              => 'integer',
							'required'          => true,
							'validate_callback' => function ( $val ) {
								return is_numeric( $val );
							},
						],
						'anime_id' => [
							'type'              => 'integer',
							'required'          => true,
							'validate_callback' => function ( $val ) {
								return is_numeric( $val );
							},
						],
					],
				],
			]
		);
		register_rest_route(
			$namespace,
			'/watchlist/public',
			[
				[
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => [ $this, 'get_public_watchlist' ],
					'permission_callback' => '__return_true',
					'args'                => [
						'user_id' => [
							'type'              => 'integer',
							'required'          => true,
							'validate_callback' => function ( $val ) {
								return is_numeric( $val );
							},
						],
					],
				],
			]
		);
		register_rest_route(
			$namespace,
			'/watchlist/migrate',
			[
				[
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => [ $this, 'migrate_watchlist_data' ],
					'permission_callback' => '__return_true',
					'args'                => [],
				],
			]
		);
		register_rest_route(
			$namespace,
			'/auth/login',
			[
				[
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => [ $this, 'try_login' ],
					'permission_callback' => '__return_true',
					'args'                => [
						'username'   => [
							'type'              => 'string',
							'required'          => true,
							'validate_callback' => function ( $val ) {
								return is_string( $val );
							},
							'sanitize_callback' => function ( $value, $request, $param ) {
								return sanitize_text_field( $value );
							},
						],
						'password'   => [
							'type'              => 'string',
							'required'          => true,
							'validate_callback' => function ( $val ) {
								return is_string( $val );
							},
							'sanitize_callback' => function ( $value, $request, $param ) {
								return sanitize_text_field( $value );
							},
						],
						'rememberMe' => [
							'type'              => 'boolean',
							'required'          => false,
							'default'           => true,
							'validate_callback' => function ( $val ) {
								return is_bool( $val );
							},
						],
						'token'      => [
							'type'     => 'string',
							'required' => false,
						],
					],
				],
			]
		);
		register_rest_route(
			$namespace,
			'/auth/register',
			[
				[
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => [ $this, 'try_register' ],
					'permission_callback' => '__return_true',
					'args'                => [
						'username' => [
							'type'              => 'string',
							'required'          => true,
							'validate_callback' => function ( $val ) {
								return is_string( $val );
							},
							'sanitize_callback' => function ( $value, $request, $param ) {
								return sanitize_text_field( $value );
							},
						],
						'password' => [
							'type'              => 'string',
							'required'          => true,
							'validate_callback' => function ( $val ) {
								return is_string( $val );
							},
							'sanitize_callback' => function ( $value, $request, $param ) {
								return sanitize_text_field( $value );
							},
						],
						'email'    => [
							'type'              => 'string',
							'required'          => true,
							'validate_callback' => function ( $val ) {
								return is_email( $val );
							},
							'sanitize_callback' => function ( $value, $request, $param ) {
								return sanitize_email( $value );
							},
						],
						'token'    => [
							'type'     => 'string',
							'required' => false,
						],
					],
				],
			]
		);
		register_rest_route(
			$namespace,
			'/auth/logout',
			[
				[
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => [ $this, 'logout' ],
					'permission_callback' => [ $this, 'is_allowed' ],
					'args'                => [],
				],
			]
		);
		register_rest_route(
			$namespace,
			'/auth/recovery',
			[
				[
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => [ $this, 'get_verification_code' ],
					'permission_callback' => '__return_true',
					'args'                => [
						'userlogin' => [
							'required'          => true,
							'validate_callback' => function ( $val ) {
								return is_string( $val );
							},
							'type'              => 'string',
						],
						'token'     => [
							'type'     => 'string',
							'required' => false,
						],
					],
				],

			]
		);
		register_rest_route(
			$namespace,
			'/auth/reset',
			[
				[
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => [ $this, 'reset_user_password' ],
					'permission_callback' => '__return_true',
					'args'                => [
						'userlogin'          => [
							'required'          => true,
							'validate_callback' => function ( $val ) {
								return is_string( $val );
							},
							'type'              => 'string',
						],
						'verification_token' => [
							'required'          => true,
							'validate_callback' => function ( $val ) {
								return is_string( $val );
							},
							'type'              => 'string',
						],
						'new_password'       => [
							'required'          => true,
							'validate_callback' => function ( $val ) {
								return is_string( $val );
							},
							'type'              => 'string',
						],
						'repeat_password'    => [
							'required'          => true,
							'validate_callback' => function ( $val ) {
								return is_string( $val );
							},
							'type'              => 'string',
						],
						'token'              => [
							'type'     => 'string',
							'required' => false,
						],
					],
				],

			]
		);
		register_rest_route(
			$namespace,
			'/profile',
			[
				[
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => [ $this, 'upload_avatar' ],
					'permission_callback' => [ $this, 'is_allowed' ],
					'args'                => [
						'user_id' => [
							'type'              => 'integer',
							'required'          => true,
							'validate_callback' => function ( $val ) {
								return is_numeric( $val );
							},
						],
					],
				],
				[
					'methods'             => WP_REST_Server::EDITABLE,
					'callback'            => [ $this, 'change_avatar' ],
					'permission_callback' => [ $this, 'is_allowed' ],
					'args'                => [
						'user_id' => [
							'type'              => 'integer',
							'required'          => true,
							'validate_callback' => function ( $val ) {
								return is_numeric( $val );
							},
						],
						'avatar'  => [
							'type'              => 'string',
							'required'          => true,
							'validate_callback' => function ( $val ) {
								return is_string( $val );
							},
						],
					],
				],
			]
		);
		register_rest_route(
			$namespace,
			'/profile_update',
			[
				[
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => [ $this, 'profile_change' ],
					'permission_callback' => function () {
						return is_user_logged_in();
					},
					'args'                => [
						'password'         => [
							'type'              => 'string',
							'required'          => true,
							'validate_callback' => function ( $val ) {
								return is_string( $val );
							},
						],
						'email'            => [
							'type'              => 'string',
							'required'          => true,
							'validate_callback' => function ( $val ) {
								return is_email( $val );
							},
						],
						'username'         => [
							'type'              => 'string',
							'required'          => true,
							'validate_callback' => function ( $val ) {
								return is_string( $val );
							},
						],
						'confirm'          => [
							'type'              => 'string',
							'required'          => true,
							'validate_callback' => function ( $val ) {
								return is_string( $val );
							},
						],
						'u_nonce'          => [
							'type'              => 'string',
							'required'          => true,
							'validate_callback' => function ( $val ) {
								return is_string( $val );
							},
						],
						'current_password' => [
							'type'              => 'string',
							'required'          => true,
							'validate_callback' => function ( $val ) {
								return is_string( $val );
							},
						],
						'change_pass'      => [
							'type'              => 'integer',
							'required'          => true,
							'validate_callback' => function ( $val ) {
								return is_numeric( $val );
							},
						],
					],
				],
			]
		);
		register_rest_route(
			$namespace,
			'/anime',
			[
				[
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => [ $this, 'create_anime' ],
					'permission_callback' => function () {
						return current_user_can( 'edit_published_posts' );
					},
					'args'                => [
						'data' => [
							'type'              => 'object',
							'required'          => true,
							'validate_callback' => function ( $val ) {
								return is_array( $val ) || is_object( $val );
							},
						],
					],
				],
			]
		);
		register_rest_route(
			$namespace,
			'/anime/view',
			[
				[
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => [ $this, 'add_view' ],
					'permission_callback' => '__return_true',
					'args'                => [],
				],
			]
		);
		register_rest_route(
			$namespace,
			'/anime/title',
			[
				[
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => [ $this, 'get_anime_title' ],
					'permission_callback' => '__return_true',
					'args'                => [
						'query' => [
							'type'              => 'string',
							'required'          => true,
							'validate_callback' => function ( $val ) {
								return is_string( $val );
							},
						],
						'type'  => [
							'type'     => 'string',
							'required' => false,
						],
					],
				],
			]
		);
		register_rest_route(
			$namespace,
			'/anime/search',
			[
				[
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => [ $this, 'search_anime' ],
					'permission_callback' => '__return_true',
					'args'                => [
						'query' => [
							'type'              => 'string',
							'required'          => true,
							'validate_callback' => function ( $val ) {
								return is_string( $val );
							},
							'sanitize_callback' => function ( $value, $request, $param ) {
								return sanitize_text_field( $value );
							},
						],
					],
				],
			]
		);
		register_rest_route(
			$namespace,
			'/anime/advancedsearch',
			[
				[
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => [ $this, 'advancedsearch_anime' ],
					'permission_callback' => '__return_true',
					'args'                => [
						'query' => [
							'type'              => 'string',
							'required'          => true,
							'validate_callback' => function ( $val ) {
								return is_string( $val );
							},
							'sanitize_callback' => function ( $value, $request, $param ) {
								return sanitize_text_field( $value );
							},
						],
					],
				],
			]
		);
		register_rest_route(
			$namespace,
			'/anime/tooltip/(?P<id>\d+)',
			[
				[
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => [ $this, 'show_tooltip' ],
					'permission_callback' => '__return_true',
					'args'                => [],
				],
			]
		);
		register_rest_route(
			$namespace,
			'/anime/vote',
			[
				[
					'methods'             => WP_REST_Server::EDITABLE,
					'callback'            => [ $this, 'add_vote' ],
					'permission_callback' => [ $this, 'is_allowed' ],
					'args'                => [
						'anime_id' => [
							'type'              => 'integer',
							'required'          => true,
							'validate_callback' => function ( $val ) {
								return is_numeric( $val );
							},
						],
						'value'    => [
							'type'              => 'integer',
							'required'          => true,
							'validate_callback' => function ( $val ) {
								return is_numeric( $val );
							},
						],
					],
				],
			]
		);

		register_rest_route(
			$namespace,
			'/anime/random',
			[
				[
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => [ $this, 'get_random_anime' ],
					'permission_callback' => '__return_true',
					'args'                => [],
				],
			]
		);
		register_rest_route(
			$namespace,
			'/episode/autoimport',
			[
				[
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => [ $this, 'auto_import_episode' ],
					'permission_callback' => '__return_true',
					'args'                => [],
				],
			]
		);
		register_rest_route(
			$namespace,
			'/episode',
			[
				[
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => [ $this, 'create_episode' ],
					'permission_callback' => function () {
						return current_user_can( 'edit_published_posts' );
					},
					'args'                => [
						'data' => [
							'type'              => 'object',
							'required'          => true,
							'validate_callback' => function ( $val ) {
								return is_array( $val ) || is_object( $val );
							},
						],
					],
				],
			]
		);
		register_rest_route(
			$namespace,
			'/episode/scheduled',
			[
				[
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => [ $this, 'get_scheduled_episode' ],
					'permission_callback' => '__return_true',
					'args'                => [
						'day'   => [
							'type'              => 'integer',
							'required'          => true,
							'validate_callback' => function ( $val ) {
								return is_numeric( $val );
							},
						],
						'month' => [
							'type'              => 'integer',
							'required'          => true,
							'validate_callback' => function ( $val ) {
								return is_numeric( $val );
							},
						],
						'year'  => [
							'type'              => 'integer',
							'required'          => true,
							'validate_callback' => function ( $val ) {
								return is_numeric( $val );
							},
						],
					],
				],
			]
		);
		register_rest_route(
			$namespace,
			'/episode/import',
			[
				[
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => [ $this, 'import_episode' ],
					'permission_callback' => function () {
						return current_user_can( 'edit_published_posts' );
					},
					'args'                => [
						'data' => [
							'type'              => 'object',
							'required'          => true,
							'validate_callback' => function ( $val ) {
								return is_object( $val ) || is_array( $val );
							},
						],
					],
				],
			]
		);
		register_rest_route(
			$namespace,
			'/episode/report',
			[
				[
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => [ $this, 'report_problem' ],
					'permission_callback' => '__return_true',
					'args'                => [
						'data' => [
							'type'              => 'object',
							'required'          => true,
							'validate_callback' => function ( $val ) {
								return is_object( $val ) || is_array( $val );
							},
						],
					],
				],
				[
					'methods'             => WP_REST_Server::DELETABLE,
					'callback'            => [ $this, 'delete_report' ],
					'permission_callback' => [ $this, 'is_allowed' ],
					'args'                => [
						'report_id' => [
							'type'              => 'number',
							'required'          => true,
							'validate_callback' => function ( $val ) {
								return is_numeric( $val );
							},
						],
					],
				],
			]
		);
		register_rest_route(
			$namespace,
			'/notification',
			[
				[
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => [ $this, 'get_notification' ],
					'permission_callback' => [ $this, 'is_allowed' ],
					'args'                => [
						'user_id' => [
							'type'              => 'integer',
							'required'          => true,
							'validate_callback' => function ( $val ) {
								return is_numeric( $val );
							},
						],
					],
				],

				[
					'methods'             => WP_REST_Server::DELETABLE,
					'callback'            => [ $this, 'delete_notification' ],
					'permission_callback' => [ $this, 'is_allowed' ],
					'args'                => [
						'user_id'         => [
							'type'              => 'integer',
							'required'          => true,
							'validate_callback' => function ( $val ) {
								return is_numeric( $val );
							},
						],
						'notification_id' => [
							'type'              => 'integer',
							'required'          => true,
							'validate_callback' => function ( $val ) {
								return is_numeric( $val );
							},
						],
					],
				],
			]
		);
		register_rest_route(
			$namespace,
			'/check_notification',
			[
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => [ $this, 'check_notification' ],
				'permission_callback' => [ $this, 'is_allowed' ],
				'args'                => [],
			],
		);

		register_rest_route(
			$namespace,
			'/setting',
			[
				[
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => [ $this, 'save_setting' ],
					'permission_callback' => function () {
						return current_user_can( 'manage_options' );
					},
					'args'                => [],
				],
			]
		);
		register_rest_route(
			$namespace,
			'/getremoteimage',
			[
				[
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => [ $this, 'get_remote_image' ],
					'permission_callback' => function () {
						return current_user_can( 'manage_options' );
					},
					'args'                => [],
				],
			]
		);
		register_rest_route(
			$namespace,
			'/get_posts',
			[
				[
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => [ $this, 'get_all_posts' ],
					'permission_callback' => function () {
						return current_user_can( 'manage_options' );
					},
					'args'                => [],
				],
			]
		);
		register_rest_route(
			$namespace,
			'/migrate_thumbnail',
			[
				[
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => [ $this, 'migrate_thumbnail' ],
					'permission_callback' => function () {
						return current_user_can( 'manage_options' );
					},
					'args'                => [],
				],
			]
		);
		register_rest_route(
			$namespace,
			'/migrate_remove_tools',
			[
				[
					'methods'             => WP_REST_Server::DELETABLE,
					'callback'            => [ $this, 'migrate_remove_tools' ],
					'permission_callback' => function () {
						return current_user_can( 'manage_options' );
					},
					'args'                => [],
				],
			]
		);
		register_rest_route(
			$namespace,
			'/search_index',
			[
				[
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => [ $this, 'get_search_index_ids' ],
					'permission_callback' => '__return_true',
					'args'                => [],
				],
			]
		);
		register_rest_route(
			$namespace,
			'/search_index/(?P<id>\d+)',
			[
				[
					'methods'             => WP_REST_Server::EDITABLE,
					'callback'            => [ $this, 'build_search_index' ],
					'permission_callback' => function () {
						return current_user_can( 'manage_options' );
					},
					'args'                => [
						'id' => [
							'validate_callback' => function ( $val ) {
								return is_numeric( $val );
							},
						],
					],
				],
			]
		);
		register_rest_route(
			$namespace,
			'/recaptcha',
			[
				[
					'methods'             => WP_REST_Server::EDITABLE,
					'callback'            => [ $this, 'verify_recaptcha_response' ],
					'permission_callback' => '__return_true',
					'args'                => [
						'session' => [
							'validate_callback' => function ( $val ) {
								return is_string( $val );
							},
						],
					],
				],
			]
		);
	}


	/**
	 * Retrieves parameters from a REST request.
	 *
	 * This function checks for JSON parameters first, then query parameters, and finally body parameters.
	 *
	 * @param WP_REST_Request $request The REST request object.
	 *
	 * @return array An associative array of parameters.
	 */
	public function get_params( WP_REST_Request $request ) {
		return ! empty( $request->get_json_params() ) ? $request->get_json_params() : ( ! empty( $request->get_query_params() ) ? $request->get_query_params() : $request->get_body_params() );
	}

	/**
	 * Retrieves anime and episode data for migration.
	 *
	 * @param WP_REST_Request $request The request object.
	 *
	 * @return WP_REST_Response The response object containing anime and episode data.
	 *
	 * @throws WP_REST_Response_Exception If the page parameter is not provided.
	 */
	public function get_migrate_anime_data( WP_REST_Request $request ) {
		$params = $this->get_params( $request );
		if ( empty( $params['page'] ) ) {
			return new WP_REST_Response( 'No page specified', 400 );
		}
		$page  = absint( $params['page'] );
		$posts = new WP_Query(
			[
				'post_type'      => [ 'anime', 'episode' ],
				'post_status'    => 'all',
				'posts_per_page' => 100,
				'paged'          => $page,
				'orderby'        => 'date',
				'order'          => 'ASC',
			]
		);

		$res = [
			'posts'       => array_map(
				function ( $p ) {
					return [
						'ID'         => $p->ID,
						'post_type'  => $p->post_type,
						'post_title' => $p->post_title,
					];
				},
				$posts->posts
			),
			'total_posts' => $posts->found_posts,
			'total_pages' => $posts->max_num_pages,
		];

		return new WP_REST_Response( $res );
	}
	/**
	 * Migrate anime data from the request.
	 *
	 * @param WP_REST_Request $request The request object.
	 *
	 * @return WP_REST_Response The response object with the result of the migration.
	 *
	 * @throws Throwable If an error occurs during the migration.
	 */
	public function migrate_anime_data( WP_REST_Request $request ) {
		try {
			$params = $this->get_params( $request );
			$animes = $params['animes'];

			$result = Kira_Utility::migrate_anime_data( $animes );

			return new WP_REST_Response( $result );
		} catch ( \Throwable $e ) {
			return new WP_REST_Response( $e->getMessage(), 500 );
		}
	}

	/**
	 * Deletes the migration status for anime data.
	 *
	 * This function updates the 'kiranime_anime_migrated' option to '1', indicating that the anime data migration has been completed.
	 *
	 * @return WP_REST_Response The response object with the result of the update operation.
	 */
	public function migrate_anime_data_delete() {
		return new WP_REST_Response( update_option( 'kiranime_anime_migrated', '1' ) );
	}

	/**
	 * Verifies the reCAPTCHA response.
	 *
	 * @param WP_REST_Request $request The request object.
	 *
	 * @return WP_REST_Response The response object with the verification status, message, and Google response.
	 */
	public function verify_recaptcha_response( WP_REST_Request $request ) {
		$params = $this->get_params( $request );

		$session  = $params['session'];
		$chaptcha = new Kiranime_Recaptcha( $session, sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ?? '' ) ) );
		$chaptcha->validate_session();

		return new WP_REST_Response(
			[
				'status'   => $chaptcha->is_valid,
				'message'  => $chaptcha->message,
				'response' => $chaptcha->google_response,
			]
		);
	}

	/**
	 * Creates a new taxonomy term.
	 *
	 * @param WP_REST_Request $request The request object containing the taxonomy data.
	 * @return WP_REST_Response The response object with the result of the taxonomy creation.
	 *
	 * @throws WP_Error If the taxonomy does not exist.
	 */
	public function create_taxonomy( WP_REST_Request $request ) {
		$params = $this->get_params( $request );

		if ( taxonomy_exists( $params['taxonomy'] ) ) {
			$sslug = sanitize_title( $params['slug'] );
			$slug  = isset( $params['slug'] ) ? [ 'slug' => $sslug ] : null;
			if ( $slug && ! term_exists( $sslug, $params['taxonomy'] ) ) {
				$name = 'type' === $params['taxonomy'] ? strtoupper( $params['name'] ) : $params['name'];
				wp_insert_term( $name, $params['taxonomy'], $slug );
			}

			$taxonomies = get_terms(
				[
					'taxonomy'   => $params['taxonomy'],
					'hide_empty' => false,
				]
			);
			return new WP_REST_Response( [ 'taxonomies' => $taxonomies ] );
		}

		return new WP_REST_Response( [ 'error' => 'Invalid taxonomy' ], 400 );
	}

	/**
	 * Retrieves a list of taxonomies based on the provided name.
	 *
	 * @param WP_REST_Request $request The request object containing the name of the taxonomy.
	 *
	 * @return WP_REST_Response A response object containing an array of taxonomies.
	 *
	 * @since 1.0.0
	 */
	public function get_taxonomies( WP_REST_Request $request ) {
		$params = $this->get_params( $request );

		$taxonomies = get_terms(
			[
				'taxonomy'   => $params['name'],
				'hide_empty' => false,
			]
		);
		return new WP_REST_Response( [ 'taxonomies' => $taxonomies ] );
	}

	/**
	 * Saves the theme activation key and other related information.
	 *
	 * @param WP_REST_Request $request The request object containing the parameters.
	 *
	 * @return WP_REST_Response The response object with status and message.
	 *
	 * @throws Exception If an error occurs while updating the options.
	 */
	public function save_theme_key( WP_REST_Request $request ) {
		try {
			$param   = $this->get_params( $request );
			$key     = $param['key'];
			$actkey  = $param['activationKey'];
			$actmail = $param['activationMail'];

			update_option( gtAcCLK( 2 ), $key );
			update_option( gtAcCLK( 3 ), $actkey );
			update_option( gtAcCLK( 4 ), $actmail );
			update_option( gtAcCLK( 1 ), 1 );
			return new WP_REST_Response( [ 'status' => true ] );
		} catch ( Exception $e ) {
			return new WP_REST_Response(
				[
					'status'  => false,
					'message' => $e->getMessage(),
				]
			);
		}
	}

	/**
	 * Removes theme activation key and related options.
	 *
	 * @param WP_REST_Request $request The request object containing the 'remove' parameter.
	 *
	 * @return WP_REST_Response The response object with a 'status' key indicating success or failure.
	 */
	public function remove_theme_key( WP_REST_Request $request ) {
		$param  = $this->get_params( $request );
		$remove = $param['remove'];

		if ( $remove ) {
			delete_option( gtAcCLK( 2 ) );
			delete_option( gtAcCLK( 3 ) );
			delete_option( gtAcCLK( 4 ) );
			delete_option( gtAcCLK( 1 ) );
			return new WP_REST_Response( [ 'status' => true ] );
		}

		return new WP_REST_Response( [ 'status' => false ] );
	}

	/**
	 * Removes image migration tools page.
	 *
	 * This function updates the 'kiranime_image_migrated' option to 1.
	 *
	 * @return WP_REST_Response The response object with the status of the update operation.
	 */
	public function migrate_remove_tools() {
		return new WP_REST_Response( update_option( 'kiranime_image_migrated', 1 ) );
	}

	/**
	 * Migrate post thumbnail for anime and episode posts.
	 *
	 * @param WP_REST_Request $request The request object.
	 *
	 * @return WP_REST_Response The response object.
	 */
	public function migrate_thumbnail( WP_REST_Request $request ) {
		$param = $this->get_params( $request );

		$post     = get_post( $param['postId'] );
		$prefix   = MetaPrefix::fromName( $post->post_type );
		$meta_key = 'anime' === $post->post_type ? [ $prefix->value . 'background', $prefix->value . 'featured' ] : $prefix->value . 'thumbnail';
		$results  = [
			'status' => 0,
			'postId' => $param['postId'],
		];

		if ( is_array( $meta_key ) ) {
			$featured   = get_post_meta( $post->ID, $prefix->value . 'featured', true );
			$background = get_post_meta( $post->ID, $prefix->value . 'background', true );

			$results['meta'] = $featured;
			if ( ! empty( $featured ) ) {
				$thumb             = Kira_Utility::get_remote_image( $featured );
				$results['thumbs'] = $thumb;
				if ( isset( $thumb['status'] ) && ! empty( $thumb['status'] ) ) {
					set_post_thumbnail( $post, $thumb['thumbnail_id'] );
					update_post_meta( $post->ID, $prefix->value . 'featured', $thumb['thumbnail_url'] );
					$results['thumbnail_id'] = $thumb['thumbnail_id'];
					$results['status']       = 1;
				}
			}
			if ( ! empty( $background ) ) {
				$thumb             = Kira_Utility::get_remote_image( $background );
				$results['thumbs'] = $thumb;
				if ( isset( $thumb['status'] ) && ! empty( $thumb['status'] ) ) {
					update_post_meta( $post->ID, $prefix->value . 'background', $thumb['thumbnail_url'] );
				}
			}
		} else {
			$value           = get_post_meta( $post->ID, $meta_key, true );
			$results['meta'] = $value;
			if ( ! empty( $value ) ) {
				$thumb             = Kira_Utility::get_remote_image( $value );
				$results['thumbs'] = $thumb;
				if ( isset( $thumb['status'] ) && ! empty( $thumb['status'] ) ) {
					set_post_thumbnail( $post, $thumb['thumbnail_id'] );
					update_post_meta( $post->ID, $prefix->value . 'thumbnail', $thumb['thumbnail_url'] );
					$results['status']       = 1;
					$results['thumbnail_id'] = $thumb['thumbnail_id'];
				}
			}
		}

		return new WP_REST_Response( $results );
	}

	/**
	 * Retrieves the activation status from the database.
	 *
	 * @return WP_REST_Response The response containing the activation status.
	 *
	 * @since 1.0.0
	 *
	 * @type bool $status The activation status.
	 */
	public function get_act_status() {
		$s = get_option( 'kr_anime_status', false );
		return new WP_REST_Response( [ 'status' => $s ] );
	}

	/**
	 * Retrieves all posts of 'anime' and 'episode' post types.
	 *
	 * @param WP_REST_Request $request The request object.
	 *
	 * @return WP_REST_Response The response object containing the retrieved posts.
	 *
	 * @since 1.0.0
	 */
	public function get_all_posts( WP_REST_Request $request ) {
		$param = $this->get_params( $request );

		$posts = new WP_Query(
			[
				'post_type'      => [ 'anime', 'episode' ],
				'posts_per_page' => 100,
				'post_status'    => 'publish',
				'paged'          => $param['page'],
			]
		);

		$results = [
			'status'    => 1,
			'data'      => [],
			'page'      => $param['page'],
			'max_pages' => $posts->max_num_pages,
		];
		foreach ( $posts->posts as $post ) {
			if ( ! get_post_thumbnail_id( $post->ID ) ) {
				$featured = 'anime' === $post->post_type ? get_post_meta( $post->ID, 'kiranime_anime_featured', true ) : get_post_meta( $post->ID, 'kiranime_episode_thumbnail', true );

				if ( ! $featured ) {
					continue;
				}

				$results['data'][] = [
					'id'        => $post->ID,
					'thumbnail' => 0,
				];
			}
		}

		return new WP_REST_Response( $results );
	}

	/**
	 * Retrieves a remote image from the provided URL.
	 *
	 * @param WP_REST_Request $request The request object.
	 *
	 * @return WP_REST_Response The response object containing the retrieved image data.
	 *
	 * @throws WP_REST_ResponseException If the image URL is not provided.
	 */
	public function get_remote_image( WP_REST_Request $request ) {
		$param = $this->get_params( $request );

		if ( ! $param['image_url'] ) {
			return new WP_REST_Response( [ 'message' => 'Image url required!' ] );
		}

		$data = Kira_Utility::get_remote_image( $param['image_url'] );

		return new WP_REST_Response( $data );
	}

	/**
	 * Adds or removes anime from the user's watchlist.
	 *
	 * @param WP_REST_Request $request The request object.
	 *
	 * @return WP_REST_Response The response object with a status and message.
	 *
	 * @throws WP_REST_ResponseException If the user ID, anime ID, or type are not provided.
	 */
	public function add_watchlist( WP_REST_Request $request ) {
		['user_id' => $user_id, 'anime_id' => $anime_id, 'type' => $type] = $this->get_params( $request );

		$watchlist = new Kiranime_Watchlist( $user_id ? $user_id : get_current_user_id() );
		if ( 'remove' === $type ) {
			$result = $watchlist->remove( $anime_id, false );
		} else {
			$result = $watchlist->set( $anime_id, WatchlistType::fromName( $type ) );
		}

		return new WP_REST_Response(
			[
				'message' => $result,
				'status'  => true,
			]
		);
	}

	/**
	 * Retrieves the user's watchlist based on the provided type, page, and per page parameters.
	 *
	 * @param WP_REST_Request $request The request object containing the parameters.
	 *
	 * @return WP_REST_Response The response object containing the watchlist data.
	 *
	 * @throws WP_REST_ResponseException If the user ID, anime ID, or type are not provided.
	 */
	public function get_watchlist( WP_REST_Request $request ) {
		$params = $this->get_params( $request );

		// Redirect to home if the user is not logged in and public_value is not provided.
		if ( ! $params['public_value'] && ! is_user_logged_in() ) {
			wp_redirect( home_url( '/' ) );
			exit;
		}

		// Determine the user ID based on the provided public_value or the current user ID.
		$user_id = $params['public_value'] ? $params['public_value'] : get_current_user_id();

		// Create a new Kiranime_Watchlist object for the user.
		$watchlist = new Kiranime_Watchlist( $user_id );

		// Retrieve the anime from the watchlist based on the provided type, page, and per page parameters.
		$result = $watchlist->get_anime( WatchlistType::fromName( $params['type'] ), $params['page'], $params['per_page'] );

		// Return the response object containing the watchlist data.
		return new WP_REST_Response( $result );
	}

	/**
	 * Performs the migration of watchlist data for a given page.
	 *
	 * @param WP_REST_Request $req The request object containing the parameters.
	 * @return WP_REST_Response The response object containing the result of the migration.
	 *
	 * @throws WP_REST_Exception If the page parameter is not provided.
	 *
	 * @since 3.0.0
	 */
	public function migrate_watchlist_data( WP_REST_Request $req ) {
		$param = $this->get_params( $req );

		$page = $param['page'];

		$migrated = Kiranime_Watchlist::migrate_watchlist( intval( $page ) );
		return new WP_REST_Response( $migrated );
	}
	/**
	 * Handles the tooltip display for an anime.
	 *
	 * @param WP_REST_Request $request The request object containing the anime ID.
	 *
	 * @return WP_REST_Response The response containing the HTML for the tooltip.
	 */
	public function show_tooltip( WP_REST_Request $request ) {
		$id     = $request['id'];
		$cache  = new Kiranime_Cache( 'tooltip_' );
		$cached = $cache->get( $id );
		if ( ! empty( $cached ) ) {
			return new WP_REST_Response(
				[
					'status' => true,
					'data'   => $cached,
				]
			);
		}

		$anime = new Anime( $id );

		if ( is_wp_error( $anime ) ) {
			return new WP_REST_Response( [ 'status' => false ] );
		}
		$anime
			->gets( MetaPrefix::anime )
			->get_taxonomies( 'type' )
			->get_episodes( true );

		$meta          = $anime->meta;
		$latest        = ! empty( $anime->episodes ) ? $anime->episodes[0] : null;
		$current_type  = isset( $anime->taxonomies['type'] ) ? $anime->taxonomies['type'] : [];
		$current_title = $anime->post->post_title;
		$meta          = array_filter( $meta, fn ( $val ) => ! in_array( $val, [ 'spotlight', 'updated', 'voted', 'voted_by', 'vote_score', 'featured', 'characters', 'title', 'background', 'name', 'service_name', 'id', 'trailer', 'season' ] ), ARRAY_FILTER_USE_KEY );

		ob_start(); ?>
		<div class="relative p-4 max-w-xs w-80 min-w-[17rem] text-sm bg-secondary rounded-md">
			<div class="font-medium line-clamp-2 mbe-3">
				<?php echo esc_html( $current_title ); ?> </div>
			<div class="flex items-center justify-between mbe-3 text-xs">
				<div class="flex items-center gap-4">
					<span class="flex items-center justify-center gap-1">
						<span class="material-icons-round text-lg text-yellow-500">
							star_rate
						</span>
						<?php echo esc_html( number_format_i18n( floatval( $meta['score'] ?? 0 ), 1 ) ); ?>
					</span>
					<?php if ( ! empty( $current_type[0]->slug ) && in_array( $current_type[0]->slug, [ 'tv', 'series', 'ona', 'ova' ] ) && ! empty( $latest->meta['number'] ) ) : ?>
						<span class="whitespace-nowrap">
							<?php esc_html_e( 'E', 'kiranime' ); ?>
							<?php echo esc_html( number_format_i18n( absint( $latest->meta['number'] ), 1 ) ); ?>/<?php echo esc_html( number_format_i18n( absint( $meta['episodes'] ?? 12 ) ) ); ?>
						</span>
					<?php endif; ?>
				</div>
				<span class="pli-2 plb-1 text-xs rounded bg-accent-3 uppercase">
					<?php echo esc_html( ! empty( $current_type[0]->name ) ? $current_type[0]->name : 'TV' ); ?>
				</span>
			</div>
			<span class="w-full text-xs font-montserrat font-light line-clamp-4 mbs-5">
				<?php echo wp_kses( $anime->post->post_content, '' ); ?>
			</span>
			<div class="text-xs space-y-1 mbs-5">
				<?php
				foreach ( $meta as $k => $v ) {
					if ( empty( $v ) ) {
						continue;
					}
					$value = is_array( $v ) ? implode( ', ', array_map( fn( $vd )=>$vd->name, $v ) ) : $v;
					?>
						<span class="block">
							<span class="font-medium"><?php echo ucfirst( __( $k, 'kiranime' ) ); ?>:</span>
							<?php echo esc_html( $value ); ?>
						</span>
						<?php
				}
				?>
			</div>
			<div class="mbe-2 mbs-4 flex items-center gap-2">
				<a href="<?php echo esc_url( $latest->url ?? $anime->url ); ?>" class="flex items-center bg-accent-3 text-xs font-semibold pli-3 plb-2 gap-1 rounded-full w-max shadow drop-shadow justify-center">
					<span class="material-icons-round text-xl">
						play_arrow
					</span>
					<?php esc_html( 'Watch Now', 'kiranime' ); ?>
				</a>
				<span data-tippy-sub-trigger="<?php echo $anime->id; ?>" class="flex items-center text-xs font-semibold pli-3 plb-2 gap-1 rounded-full w-max shadow drop-shadow justify-center cursor-pointer hover:bg-accent-4 hover:bg-opacity-60 bg-primary/50">
					<span class="material-icons-round text-xl">
						playlist_add
					</span>
					<?php esc_html( 'Watchlist', 'kiranime' ); ?>
				</span>
			</div>
		</div>
		<?php

		$result = ob_get_clean();
		$cache->set( $id, $result, get_option( '__kira_cache_time', 7200 ) );
		return new WP_REST_Response(
			[
				'status' => true,
				'data'   => $result,
			]
		);
	}

	/**
	 * Retrieves the public watchlist type from the request.
	 *
	 * @param WP_REST_Request $request The request object.
	 *
	 * @return WP_REST_Response The response containing the public watchlist type.
	 *
	 * @since 1.0.0
	 */
	public function get_public_watchlist( WP_REST_Request $request ) {
		['type' => $type] = $this->get_params( $request );

		return new WP_REST_Response( $type );
	}

	/**
	 * Deletes a watchlist entry for the current user.
	 *
	 * @param WP_REST_Request $request The request object.
	 * @return WP_REST_Response The response object with the deletion result.
	 *
	 * @since 1.0.0
	 *
	 * @type int             $anime_id The ID of the anime to delete from the watchlist.
	 * @type bool True if the deletion was successful, false otherwise.
	 */
	public function delete_watchlist( WP_REST_Request $request ) {
		['anime_id' => $anime_id] = $this->get_params( $request );

		$watchlist = new Kiranime_Watchlist( get_current_user_id() );
		$result    = $watchlist->remove( $anime_id, false );

		return new WP_REST_Response( $result, 200 );
	}

	/**
	 * Attempts to log in a user.
	 *
	 * @param WP_REST_Request $request The request object.
	 *
	 * @return WP_REST_Response The response object containing the login result.
	 *
	 * @type string $username The username provided for login.
	 * @type string $password The password provided for login.
	 * @type bool   $rememberMe Whether to remember the user's login.
	 *
	 * @type WP_REST_Response The response object with the following structure:
	 * - 'status': The status of the login attempt. True if successful, false otherwise.
	 * - 'data': The data related to the login attempt. If successful, it contains the user's data.
	 * - 'message': The message related to the login attempt. If successful, it contains a success message.
	 */
	public function try_login( WP_REST_Request $request ) {
		$params = $this->get_params( $request );
		if ( get_option( '__use_recaptcha', false ) ) {
			$c = new Kiranime_Recaptcha( $params['token'] );
			$c->validate_session();
			if ( ! $c->is_valid ) {
				return new WP_REST_Response(
					[
						'status'  => false,
						'message' => __( 'Invalid captcha token.', 'kiranime' ),
					],
					400
				);
			}
		}
		$login = Kira_User::login( $params['username'], $params['password'], $params['rememberMe'] );

		return new WP_REST_Response( $login['data'], $login['status'] );
	}

	/**
	 * Attempts to register a new user.
	 *
	 * @param WP_REST_Request $request The request object.
	 *
	 * @return WP_REST_Response The response object containing the registration result.
	 *
	 * @type string $username The username provided for registration.
	 * @type string $email The email provided for registration.
	 * @type string $password The password provided for registration.
	 * @type string $token The reCAPTCHA token provided for registration.
	 *
	 * @type WP_REST_Response The response object with the following structure:
	 * - 'status': The status of the registration attempt. True if successful, false otherwise.
	 * - 'data': The data related to the registration attempt. If successful, it contains the user's data.
	 * - 'message': The message related to the registration attempt. If successful, it contains a success message.
	 */
	public function try_register( WP_REST_Request $request ) {
		['username' => $username, 'email' => $email, 'password' => $password, 'token' => $token] = $this->get_params( $request );
		if ( get_option( '__use_recaptcha', false ) ) {
			$c = new Kiranime_Recaptcha( $token );
			$c->validate_session();
			if ( ! $c->is_valid ) {
				return new WP_REST_Response(
					[
						'status'  => false,
						'message' => __( 'Invalid captcha token.', 'kiranime' ),
					],
					400
				);
			}
		}
		$register = Kira_User::register( $email, $username, $password );

		return new WP_REST_Response( $register['data'], $register['status'] );
	}

	/**
	 * Performs a logout for the current user.
	 *
	 * @return WP_REST_Response The response object with the logout result.
	 *
	 * @since 1.0.0
	 */
	public function logout() {
		$l = Kira_User::logout();

		return new WP_REST_Response( $l );
	}

	/**
	 * Retrieves a verification code for user recovery.
	 *
	 * @param WP_REST_Request $request The request object.
	 *
	 * @return WP_REST_Response The response object containing the verification code and its status.
	 *
	 * @since 3.0.0
	 */
	public function get_verification_code( WP_REST_Request $request ) {
		$param = $this->get_params( $request );

		if ( get_option( '__use_recaptcha', false ) ) {
			$c = new Kiranime_Recaptcha( $param['token'] );
			$c->validate_session();
			if ( ! $c->is_valid ) {
				return new WP_REST_Response(
					[
						'status'  => false,
						'message' => __( 'Invalid captcha token.', 'kiranime' ),
					],
					400
				);
			}
		}

		$user = new Kira_User();
		$code = $user->get_recovery_verification_code( $param['userlogin'] );

		return new WP_REST_Response( $code['data'], $code['status'] );
	}

	/**
	 * Performs a password reset for the current user.
	 *
	 * @param WP_REST_Request $request The request object containing the user's data.
	 *
	 * @return WP_REST_Response The response object containing the status and data of the password reset.
	 *
	 * @since 3.0.0
	 */
	public function reset_user_password( WP_REST_Request $request ) {
		$params        = $this->get_params( $request );
		$use_recaptcha = get_option( '__use_recaptcha', false );
		if ( ! empty( $use_recaptcha ) ) {
			$c = new Kiranime_Recaptcha( $params['token'] );
			$c->validate_session();
			if ( ! $c->is_valid ) {
				return new WP_REST_Response(
					[
						'status'  => false,
						'message' => __( 'Invalid captcha token.', 'kiranime' ),
					],
					400
				);
			}
		}

		$userkira = new Kira_User();
		$user     = $userkira->reset_my_password( $params );
		return new WP_REST_Response( $user['data'], $user['status'] );
	}

	/**
	 * Handles the user avatar upload request.
	 *
	 * @param WP_REST_Request $request The request object containing the user's avatar data.
	 *
	 * @return WP_REST_Response The response object containing the status and data of the avatar upload.
	 *
	 * @since 1.0.0
	 */
	public function upload_avatar( WP_REST_Request $request ) {
		$upload_handler = Kira_User::upload_avatar( get_current_user_id() );

		return new WP_REST_Response( $upload_handler['data'], $upload_handler['status'] );
	}

	/**
	 * Handles the user avatar change request.
	 *
	 * @param WP_REST_Request $request The request object containing the user's avatar data.
	 *
	 * @return WP_REST_Response The response object containing the status and data of the avatar change.
	 *
	 * @since 1.0.0
	 */
	public function change_avatar( WP_REST_Request $request ) {
		['avatar' => $avatar, 'user_id' => $user_id] = $this->get_params( $request );

		$change = Kira_User::set_avatar( $avatar, $user_id );

		return new WP_REST_Response( [ 'success' => $change['data'] ], $change['status'] );
	}
	/**
	 * Handles the user profile change request.
	 *
	 * @param WP_REST_Request $request The request object containing the user's profile data.
	 *
	 * @return WP_REST_Response The response object containing the status and data of the profile change.
	 *
	 * @since 1.0.0
	 */
	public function profile_change( WP_REST_Request $request ) {
		$param = $this->get_params( $request );

		$result = Kira_User::save_profile_data( $param );

		return new WP_REST_Response( $result );
	}

	/**
	 * Handles the user's vote for an anime.
	 *
	 * @param WP_REST_Request $request The request object containing the anime's ID and the vote's value.
	 *
	 * @return WP_REST_Response The response object containing the updated Anime object.
	 *
	 * @since 1.0.0
	 */
	public function add_vote( WP_REST_Request $request ) {
		$params = $this->get_params( $request );
		$set    = new Anime( absint( $params['anime_id'] ) );
		$set->get_votes()->add_vote( absint( $params['value'] ) );

		return new WP_REST_Response( [ 'vote' => $set->vote ], 200 );
	}
	/**
	 * Retrieves anime titles based on a search query.
	 *
	 * @param WP_REST_Request $request The request object containing the search query.
	 *
	 * @return WP_REST_Response The response object containing the anime titles.
	 *
	 * @since 1.0.0
	 */
	public function get_anime_title( WP_REST_Request $request ) {
		['query' => $query] = $this->get_params( $request );

		$results = new Kira_Query();
		$r       = $results->admin_search( $query );

		return new WP_REST_Response( $r['data'] );
	}
	/**
	 * Performs a search for anime based on a given query.
	 *
	 * @param WP_REST_Request $request The request object containing the search query.
	 *
	 * @return WP_REST_Response The response object containing the search results.
	 *
	 * @since 1.0.0
	 */
	public function search_anime( WP_REST_Request $request ) {
		['query' => $query] = $this->get_params( $request );
		$cache              = new Kiranime_Cache( 'search_anime_cache' );
		$cached             = $cache->get( $query );
		if ( $cached ) {
			return new WP_REST_Response( $cached, 200 );
		}

		$q = new Kira_Query();
		$r = $q->search_query( $query );
		$cache->set( $query, $r );
		return new WP_REST_Response( $r, 200 );
	}
	/**
	 * Performs a search for anime based on a given query.
	 *
	 * @param WP_REST_Request $request The request object containing the search query.
	 *
	 * @return WP_REST_Response The response object containing the search results.
	 *
	 * @since 1.0.0
	 */
	public function get_season_anime_search( WP_REST_Request $request ) {
		['query' => $query] = $this->get_params( $request );
		$q                  = new Kira_Query();
		$r                  = $q->get_season_anime_search( $query );
		return new WP_REST_Response( $r, 200 );
	}

	/**
	 * Performs a search for anime based on a given query.
	 *
	 * @param WP_REST_Request $request The request object containing the search query.
	 *
	 * @return WP_REST_Response The response object containing the search results.
	 *
	 * @since 1.0.0
	 */
	public function advancedsearch_anime( WP_REST_Request $request ) {
		$query = $this->get_params( $request );
		$cache = new Kiranime_Cache( 'Advanced_search' );
		if ( $cache->enabled ) {
			$key  = md5( json_encode( $query ) );
			$html = $cache->get( $key );
			$data = $cache->get( $key . '_data' );
			if ( $html && $data ) {
				$dec = Kira_Utility::safe_decode( $data, true ) ?? [];
				if ( ! empty( $dec ) ) {
					return new WP_REST_Response(
						[
							'data' => $html,
							...$dec,
						],
						200
					);
				}
			}
		}

		$q = new Kira_Query( [], 'anime', false, true );
		$r = $q->advanced_search( $query );
		if ( $cache->enabled ) {
			$expires = get_option( '__kira_cache_time', 300 );
			$cache->set( $key, $r['data'], $expires );
			$cache->set(
				$key . '_data',
				[
					'pages' => $r['pages'],
					'total' => $r['total'],
				],
				$expires
			);
		}
		return new WP_REST_Response( $r, 200 );
	}

	/**
	 * Handles the creation of a new anime post.
	 *
	 * @param WP_REST_Request $request The request object containing the anime's data.
	 *
	 * @return WP_REST_Response The response object indicating the success of the anime creation.
	 *
	 * @since 1.0.0
	 */
	public function create_anime( WP_REST_Request $request ) {
		['data' => $anime] = $this->get_params( $request );

		$imported = new Anime();
		$result   = $imported->create_anime( $anime );

		return new WP_REST_Response( $result );
	}

	/**
	 * Handles the addition of a view to an anime.
	 *
	 * @param WP_REST_Request $request The request object containing the anime's ID.
	 *
	 * @return WP_REST_Response The response object indicating the success of the view addition and the updated view count.
	 *
	 * @since 1.0.0
	 */
	public function add_view( WP_REST_Request $request ) {
		$params = $this->get_params( $request );
		$id     = $params['id'];
		if ( ! $id ) {
			return new WP_REST_Response(
				[
					'status' => false,
					'err'    => 'Id not defined',
				]
			);
		}

		$anime = new Anime( $id );
		$anime->add_view();
		return new WP_REST_Response(
			[
				'status' => true,
				'views'  => $anime->statistic,
			]
		);
	}
	/**
	 * Retrieves a random anime's permalink.
	 *
	 * This function queries the database for a random published anime post,
	 * then retrieves and returns the permalink of the selected post.
	 *
	 * @return WP_REST_Response The response containing the permalink of the random anime.
	 * @since 1.0.0
	 */
	public function get_random_anime() {
		$anime_link = new WP_Query(
			[
				'post_type'      => 'anime',
				'post_status'    => 'publish',
				'order'          => 'desc',
				'orderby'        => 'rand',
				'posts_per_page' => 1,
				'no_found_rows'  => 1,
				'fields'         => 'ids',
			]
		);
		$data       = '';
		if ( $anime_link->post_count ) {
			$data = get_the_permalink( array_pop( $anime_link->posts ) );
		}

		return new WP_REST_Response( $data, 200 );
	}

	/**
	 * Retrieves a list of scheduled episodes for a specific date.
	 *
	 * @param WP_REST_Request $request The request object containing the date parameters.
	 *
	 * @return WP_REST_Response The response object containing the list of scheduled episodes.
	 *
	 * @since 1.0.0
	 */
	public function get_scheduled_episode( WP_REST_Request $request ) {
		['day' => $day, 'month' => $month, 'year' => $year] = $this->get_params( $request );

		$hash   = md5( json_encode( [ $day, $month, $year ] ) );
		$cache  = new Kiranime_Cache( $hash );
		$cached = $cache->get( '' );
		if ( ! empty( $cached ) ) {
			return new WP_REST_Response( $cached, 200 );
		}

		$scheduled = new WP_Query(
			[
				'post_type'      => 'episode',
				'post_status'    => 'future',
				'order'          => 'ASC',
				'orderby'        => 'date',
				'posts_per_page' => -1,
				'date_query'     => [
					[
						'year'    => $year,
						'month'   => $month,
						'day'     => $day,
						'compare' => '=',
					],
				],
				'fields'         => 'ids',
			]
		);
		$results   = [];
		$posts     = array_unique( $scheduled->posts, SORT_NUMERIC );
		foreach ( $posts as $post ) {
			$episode = new Episode( $post );
			$episode->gets( MetaPrefix::episode );
			$episode->parent_url = ! empty( $episode->meta['parent_id'] ) ? get_post_permalink( $episode->meta['parent_id'] ) : '';
			$results[]           = $episode;
		}

		$cache->set( '', $results );
		return new WP_REST_Response( $results, 200 );
	}

	/**
	 * Handles the creation of a new episode post.
	 *
	 * @param WP_REST_Request $request The request object containing the episode's data.
	 *
	 * @return WP_REST_Response The response object indicating the success of the episode creation.
	 *
	 * @since 1.0.0
	 */
	public function create_episode( WP_REST_Request $request ) {
		['data' => $episode] = $this->get_params( $request );

		$created = new Episode( 0 );
		$created->create_episode( $episode );

		return new WP_REST_Response( $created );
	}
	/**
	 * Handles the import of episode data from an external source.
	 *
	 * This function accepts a REST request containing episode data. It then creates a new Episode object,
	 * imports the episode data, and returns a REST response containing the result of the import operation.
	 *
	 * @param WP_REST_Request $request The REST request containing episode data.
	 * @return WP_REST_Response The REST response containing the result of the import operation.
	 *
	 * @since 1.0.0
	 */
	public function import_episode( WP_REST_Request $request ) {
		['data' => $data] = $this->get_params( $request );

		$imported = new Episode();
		$result   = $imported->import_episode( $data );

		return new WP_REST_Response( $result );
	}

	/**
	 * Handles the import of episode data from an external source.
	 *
	 * @param WP_REST_Request $request The request object containing the episode's data.
	 *
	 * @return WP_REST_Response The response object indicating the success of the episode import.
	 *
	 * @since 1.0.0
	 */
	public function report_problem( WP_REST_Request $request ) {
		['data' => $data] = $this->get_params( $request );

		$res = Kira_Utility::save_report( $data );

		return new WP_REST_Response( $res );
	}

	/**
	 * Handles the deletion of a report post.
	 *
	 * @param WP_REST_Request $request The request object containing the report's ID.
	 *
	 * @return WP_REST_Response The response object indicating the success of the deletion.
	 *
	 * @since 1.0.0
	 */
	public function delete_report( WP_REST_Request $request ) {
		$param = $this->get_params( $request );

		$deleted = wp_delete_post( $param['report_id'], true );

		return new WP_REST_Response( $deleted );
	}

	/**
	 * Retrieves notifications for a specific user.
	 *
	 * @param WP_REST_Request $request The request object containing the user's ID.
	 *
	 * @return WP_REST_Response The response object containing the notifications for the user.
	 *
	 * @since 1.0.0
	 */
	public function get_notification( WP_REST_Request $request ) {
		['user_id' => $user_id] = $this->get_params( $request );

		$nt = Kiranime_Notification::get( true, $user_id );

		return new WP_REST_Response( $nt, 200 );
	}

	/**
	 * Handles the checking of a notification.
	 *
	 * @param WP_REST_Request $request The request object containing the user's ID and the notification's ID.
	 *
	 * @return WP_REST_Response The response object indicating the success of the check and the updated notification status.
	 *
	 * @since 1.0.0
	 */
	public function check_notification( WP_REST_Request $request ) {
		['user_id' => $user_id, 'notification_id' => $notification_id] = $this->get_params( $request );

		$nt = Kiranime_Notification::checked( $notification_id, $user_id );

		return new WP_REST_Response( $nt, 200 );
	}

	/**
	 * Handles the deletion of a report post.
	 *
	 * @param WP_REST_Request $request The request object containing the user's ID and the notification's ID.
	 *
	 * @return WP_REST_Response The response object indicating the success of the deletion.
	 *
	 * @since 1.0.0
	 */
	public function delete_notification( WP_REST_Request $request ) {
		['user_id' => $user_id, 'notification_id' => $notification_id] = $this->get_params( $request );

		$delete = Kiranime_Notification::delete( $notification_id, $user_id );

		return new WP_REST_Response( $delete['data'], $delete['status'] );
	}

	/**
	 * Handles the saving of user settings.
	 *
	 * @param WP_REST_Request $request The request object containing the user's settings.
	 *
	 * @return WP_REST_Response The response object indicating the success of the setting save.
	 * The response will contain the data and status of the save operation.
	 */
	public function save_setting( WP_REST_Request $request ) {
		$params = $this->get_params( $request );

		$result = Kira_Utility::save_setting( $params );

		return new WP_REST_Response( $result['data'], $result['status'] );
	}
	/**
	 * Retrieves the IDs of posts to be indexed for the search functionality.
	 *
	 * This function creates a new instance of the Kiranime_Search_Index class,
	 * starts the indexing process, and returns a REST response containing the
	 * indexed post IDs and a status indicating success.
	 *
	 * @return WP_REST_Response The response containing the indexed post IDs and a status.
	 */
	public function get_search_index_ids() {
		$res = new Kiranime_Search_Index();
		$res = $res->start_indexing();

		return new WP_REST_Response(
			[
				'data'   => $res,
				'status' => true,
			]
		);
	}
	/**
	 * Builds the search index for a specific post.
	 *
	 * This function creates a new instance of the Kiranime_Search_Index class,
	 * then calls the build_search_index method with the provided post ID.
	 * The method returns the result of the indexing process.
	 *
	 * @param WP_REST_Request $request The request object containing the post ID.
	 * @return WP_REST_Response The response object containing the status and data of the indexing process.
	 * @since 1.0.0
	 */
	public function build_search_index( WP_REST_Request $request ) {
		$res   = new Kiranime_Search_Index();
		$build = $res->build_search_index( intval( $request['id'] ) );

		return new WP_REST_Response(
			[
				'status' => true,
				'data'   => $build,
			]
		);
	}
	/**
	 * Retrieves a global nonce for REST API authentication.
	 *
	 * This function creates a new REST response containing a global nonce,
	 * which is used for authentication in the WordPress REST API.
	 *
	 * @return WP_REST_Response The response object containing the global nonce.
	 * @since 1.0.0
	 */
	public function get_global_nonce() {
		return new WP_REST_Response(
			[
				'nonce' => wp_create_nonce( 'wp_rest' ),
			],
			200
		);
	}
	/**
	 * Removes all Kira-related cache data.
	 *
	 * This function clears all cache data related to the Kira plugin.
	 * It uses the Kiranime_Cache::clear_all() method to achieve this.
	 *
	 * @return WP_REST_Response The response object containing the result of the cache clear operation.
	 * The response will contain a boolean value indicating success (true) or failure (false).
	 */
	public function remove_kira_cache() {
		$cache = Kiranime_Cache::clear_all();
		return new WP_REST_Response( [ 'status' => $cache ], 200 );
	}
	/**
	 * Checks if the current user has the capability to read content.
	 *
	 * This function uses the WordPress function `current_user_can()` to check if the current user
	 * has the capability to read content. The capability 'read' is a built-in capability in WordPress.
	 *
	 * @return bool True if the user has the capability to read content, false otherwise.
	 */
	public function is_allowed() {
		return current_user_can( 'read' );
	}
	/**
	 * Checks if the current user has the capability to edit posts.
	 *
	 * This function uses the WordPress function `current_user_can()` to check if the current user
	 * has the capability to edit posts. The capability 'edit_posts' is a built-in capability in WordPress.
	 *
	 * @return bool True if the user has the capability to edit posts, false otherwise.
	 */
	public function is_allowed_to_edit() {
		$user = get_current_user_id();
		return current_user_can( 'edit_posts' );
	}
}
