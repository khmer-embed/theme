<?php

/**
 * This is class for user related function
 *
 * @package   Kiranime
 * @since   1.0.0
 * @link      https://kiranime.moe
 * @author    Dzul Qurnain
 * @license   GPL-2.0+
 */
class Kira_User {

	/**
	 * Constructor.
	 */
	public function __construct() {
	}

	/**
	 * Logs in a user with the provided username and password.
	 *
	 * @param string $username The username of the user.
	 * @param string $password The password of the user.
	 * @param bool   $remember_me Whether to remember the user's login. Default is true.
	 *
	 * @return array An associative array containing the status and message.
	 */
	public static function login( string $username, string $password, $remember_me = true ) {
		$info                  = [];
		$info['user_login']    = sanitize_text_field( $username );
		$info['user_password'] = $password;

		$user = wp_signon( $info, '' );
		if ( is_wp_error( $user ) ) {
			return [
				'data'   => [
					'status'  => false,
					'message' => __( 'Wrong username or password.', 'kiranime' ),
				],
				'status' => 403,
			];
		}

		wp_set_auth_cookie( $user->ID, $remember_me, is_ssl() );
		wp_set_current_user( $user->ID );
		return [
			'data'   => [
				'status'  => true,
				'message' => __( 'Login successful, redirecting...', 'kiranime' ),
			],
			'status' => 200,
		];
	}
	/**
	 * Registers a new user.
	 *
	 * @param string $email The user's email.
	 * @param string $username The user's username.
	 * @param string $password The user's password.
	 *
	 * @return array An array containing the success status and message.
	 */
	public static function register( string $email, string $username, string $password ) {
		$username       = sanitize_text_field( $username );
		$email          = sanitize_email( $email );
		$username_check = username_exists( $username );
		$email_check    = email_exists( $email );

		$banned_username = [ 'admin', 'administrator' ];

		if ( in_array( $username, $banned_username ) ) {
			return [
				'data'   => [
					'success' => false,
					'message' => __( 'Username not allowed!', 'kiranime' ),
				],
				'status' => 400,
			];
		}

		if ( $username_check || $email_check ) {
			return [
				'data'   => [
					'success' => false,
					'message' => __( 'Username or Email already exist!', 'kiranime' ),
				],
				'status' => 400,
			];
		}

		$created = wp_create_user( $username, $password, $email );

		if ( is_wp_error( $created ) ) {
			return [
				'data'   => [
					'success' => false,
					'message' => $created->errors,
				],
				'status' => 500,
			];
		}

		add_user_meta( $created, 'Kira_User_avatar', KIRA_URI . '/avatar/dragonball/av-db-1.jpeg' );

		return [
			'data'   => [
				'success' => true,
				'message' => __( 'Register successful.', 'kiranime' ),
			],
			'status' => 201,
		];
	}
	/**
	 * Logs out the current user.
	 *
	 * This function clears the user's session and cookies, and then redirects to the home page.
	 *
	 * @return array An associative array containing the status and HTTP status code.
	 */
	public static function logout() {
		wp_logout();
		ob_clean();

		return [
			'status' => true,
			200,
		];
	}
	/**
	 * Saves user data from a POST request.
	 *
	 * @return mixed
	 */
	public static function save() {
		$params = $_POST;
		$params = isset( $params['data'] ) ? json_decode( $params['data'] ) : [];
		$uid    = get_current_user_id();

		if ( ! $params || ! $uid ) {
			return wp_send_json_error(
				[
					'message' => 'no data!',
					'param'   => $params,
				]
			);
			wp_die();
		}

		foreach ( $params as $data ) {
			update_user_meta( $uid, $data->name, $data->value );
		}

		return wp_send_json_success( [ 'success' => true ] );
	}

	/**
	 * Retrieves the user's avatar image.
	 *
	 * @param int    $uid      The user ID. Default is 0.
	 * @param array  $attr     The HTML attributes for the image. Default is an empty array.
	 * @param string $size     The image size. Default is 'featuredthumb'.
	 *
	 * @return string The HTML image tag for the user's avatar.
	 */
	public static function get_avatar( int $uid = 0, array $attr = [], string $size = 'featuredthumb' ) {

		if ( get_option( 'kira_use_lazy_load', false ) ) {
			$attr['class'] = isset( $attr['class'] ) ? $attr['class'] . ' lazyload max-w-none' : 'lazyload max-w-none';
		} else {
			$attr['class'] = isset( $attr['class'] ) ? $attr['class'] . '  max-w-none' : ' max-w-none';
		}

		$default = "<img src='" . KIRA_URI . "/avatar/dragonball/av-db-1.jpeg' class='" . $attr['class'] . "'>";

		if ( ! $uid ) {
			return $default;
		}

		$avatar = get_user_meta( $uid, 'Kira_User_avatar', true );

		if ( ! $avatar ) {
			return $default;
		}

		if ( stripos( $avatar, '/avatar/' ) !== false ) {
			return "<img src='" . $avatar . "' class='" . $attr['class'] . "'>";
		}

		if ( ! is_numeric( $avatar ) ) {
			$id = Kira_Utility::image_to_id( $avatar );
			self::set_avatar( $id, get_current_user_id() );
			$avatar = $id;
		}

		$avatar = wp_get_attachment_image( $avatar, $size, false, $attr );

		return $avatar;
	}
	/**
	 * Sets the user's avatar image.
	 *
	 * @param string $avatar    The avatar image URL or attachment ID.
	 * @param int    $user_id   The user ID.
	 *
	 * @return array An array containing the status and message.
	 *               - 'data' is true if the avatar is successfully set, false otherwise.
	 *               - 'status' is 200 if the avatar is successfully set, 500 otherwise.
	 */
	public static function set_avatar( string $avatar, int $user_id ) {

		$updated = update_user_meta( $user_id, 'Kira_User_avatar', $avatar );
		if ( ! $updated ) {
			return [
				'data'   => false,
				'status' => 500,
			];
		} else {
			return [
				'data'   => true,
				'status' => 200,
			];
		}
	}
	/**
	 * Lists available avatars for different anime characters.
	 *
	 * @return array An associative array containing the avatars for each character.
	 *               The keys are the character names, and the values are arrays of avatar URLs.
	 *               Each URL is constructed using the character's name and a range of indices.
	 */
	public static function list_avatar() {
		$avatars = [
			'chibi'      => range( 1, 19 ),
			'dragonball' => range( 1, 6 ),
			'onepiece'   => range( 1, 12 ),
		];

		$results = [
			'chibi'      => [],
			'dragonball' => [],
			'onepiece'   => [],
		];

		foreach ( $avatars as $name => $file ) {
			$path = match ( $name ) {
				'chibi'         => KIRA_URI . '/avatar/chibi/chibi_',
				'dragonball'    => KIRA_URI . '/avatar/dragonball/av-db-',
				'onepiece'      => KIRA_URI . '/avatar/onepiece/user-',
			};
			$ext = in_array( $name, [ 'chibi' ] ) ? '.png' : '.jpeg';
			foreach ( $file as $index ) {
				$results[ $name ][] = $path . $index . $ext;
			}
		}

		return $results;
	}
	/**
	 * Uploads and sets the user's avatar image.
	 *
	 * @param int $user_id The ID of the user whose avatar is being set.
	 *
	 * @return array An array containing the status and message of the operation.
	 *               - 'data' contains the message and, if successful, the avatar URL.
	 *               - 'status' is the HTTP status code of the response.
	 */
	public static function upload_avatar( int $user_id ) {
		if ( ! function_exists( 'media_handle_upload' ) ) {
			require_once ABSPATH . 'wp-admin/includes/image.php';
			require_once ABSPATH . 'wp-admin/includes/file.php';
			require_once ABSPATH . 'wp-admin/includes/media.php';
		}

		$attachment_id = media_handle_upload( 'file', 0 );

		if ( is_wp_error( $attachment_id ) ) {
			return [
				'data'   => [
					'message' => __( 'error uploading image', 'kiranime' ),
					'error'   => $attachment_id->get_error_message(),
				],
				'status' => 500,
			];
		}

		$set = update_user_meta( $user_id, 'Kira_User_avatar', $attachment_id );

		if ( ! $set ) {
			return [
				'data'   => [ 'message' => __( 'error set image.', 'kiranime' ) ],
				'status' => 500,
			];
		}

		return [
			'data'   => [
				'message' => __( 'Set image success!', 'kiranime' ),
				'avatar'  => self::get_avatar( $user_id ),
			],
			'status' => 201,
		];
	}
	/**
	 * Saves user profile data.
	 *
	 * @param array $data User profile data.
	 *
	 * @return array Response with status and message.
	 */
	public static function save_profile_data( $data ) {
		if ( ! isset( $data['password'], $data['email'], $data['username'], $data['confirm'] ) ) {
			return [
				'status'  => 0,
				'message' => __( 'Field cannot be empty!', 'kiranime' ),
			];
		}

		$user = get_current_user_id();
		if ( ! wp_verify_nonce( $data['u_nonce'], $user ) ) {
			return [
				'status'  => 0,
				'message' => __( 'You\'re not allowed to do this!', 'kiranime' ),
			];
		}

		$current_user  = wp_get_current_user();
		$pass_changed  = false;
		$changed_login = [
			'email' => $current_user->user_email,
		];
		if ( 1 === $data['change_pass'] ) {
			if ( ! wp_check_password( $data['current_password'], $current_user->user_pass, $user ) ) {
				return [
					'status'  => 0,
					'message' => __( 'Current password is incorrect!', 'kiranime' ),
				];
			}

			if ( $data['password'] !== $data['confirm'] ) {
				return [
					'status'  => 0,
					'message' => __( 'Password is not the same!', 'kiranime' ),
				];
			}

			wp_set_password( $data['password'], $user );
			$pass_changed                   = true;
			$changed_login['user_password'] = $data['password'];
		}

		if ( $current_user->display_name !== $data['username'] ) {
			$uname = wp_update_user(
				[
					'ID'           => $current_user->ID,
					'display_name' => sanitize_user( $data['username'] ),
				]
			);
		}

		if ( is_email( $data['email'] ) && $data['email'] !== $current_user->user_email ) {
			if ( email_exists( $data['email'] ) ) {
				unset( $changed_login['email'] );
			} else {
				$mail = wp_update_user(
					[
						'ID'         => $current_user->ID,
						'user_email' => sanitize_email( $data['email'] ),
					]
				);
				if ( ! is_wp_error( $mail ) ) {
					$changed_login['user_login'] = sanitize_email( $data['email'] );
				}
			}
		}

		if ( $pass_changed ) {

			$user_sign = wp_signon( $changed_login );
			wp_set_current_user( $user_sign->ID );
		}

		return [
			'status'  => 1,
			'message' => __( 'Info updated!', 'kiranime' ),
			'data'    => [
				'name' => isset( $uname ) ? $uname : '',
				'mail' => isset( $mail ) ? $mail : '',
				'data' => $data,
			],
		];
	}
	/**
	 * Sends a password reset verification code to the user's email.
	 *
	 * @param string|null $userlogin The username or email of the user.
	 *
	 * @return array An array containing the status and message of the operation.
	 *               - 'data' contains the status and message.
	 *               - 'status' is the HTTP status code of the response.
	 */
	public function get_recovery_verification_code( $userlogin = null ) {
		if ( ! $userlogin ) {
			return [
				'data'   => [
					'status'  => false,
					'message' => __( 'Wrong username or password.', 'kiranime' ),
				],
				'status' => 403,
			];
		}
		$user_reset = trim( $userlogin );
		$result     = $this->custom_retrieve_password( $user_reset );
		if ( is_wp_error( $result ) ) {
			return [
				'data'   => [
					'status'  => false,
					'message' => $result->get_error_message(),
				],
				'status' => 400,
			];
		}

		return [
			'data'   => [
				'status'  => true,
				'message' => __( 'Please check your email to get reset password link.', 'kiranime' ),
			],
			'status' => 200,
		];
	}

	/**
	 * Retrieves a custom password reset key for the user.
	 *
	 * @param string $user_login The user data.
	 *
	 * @return string|WP_Error The password reset key or a WP_Error object if the key could not be generated.
	 */
	private function custom_retrieve_password( $user_login ) {
		if ( is_email( $user_login ) ) {
			$user_data = get_user_by( 'email', $user_login );
		} else {
			$user_data = get_user_by( 'login', $user_login );
		}

		if ( ! $user_data ) {
			return new WP_Error( 'invalid_login', __( 'Wrong username or password.', 'kiranime' ) );
		}

		$key = $this->get_reset_password_key( $user_data );
		if ( is_wp_error( $key ) ) {
			return $key;
		}

		if ( is_multisite() ) {
			$site_name = get_network()->site_name;
		} else {
			$site_name = wp_specialchars_decode( get_option( 'blogname' ), ENT_QUOTES );
		}
		$user_email = $user_data->user_email;

		$message = __( 'Someone has requested a password reset for the following account:', 'kiranime' ) . "\r\n\r\n";
		/* translators: user username.*/
		$message .= sprintf( __( 'Username: %s', 'kiranime' ), $user_data->user_login ) . "\r\n\r\n";
		$message .= __( 'If this was a mistake, just ignore this email and nothing will happen.', 'kiranime' ) . "\r\n\r\n";
		$message .= __( 'To reset your password, use the following code:', 'kiranime' ) . "\r\n\r\n";
		$message .= "$key\r\n\r\n";

		/* translators: sitename */
		$title = sprintf( __( '[%s] Password Reset', 'kiranime' ), $site_name );

		$title = apply_filters( 'retrieve_password_title', $title, $user_login, $user_data );

		$message = apply_filters( 'retrieve_password_message', $message, $key, $user_login, $user_data );

		if ( ! wp_mail( $user_email, wp_specialchars_decode( $title ), $message ) ) {
			return new WP_Error( 'sent_failed', __( 'The email could not be sent.', 'kiranime' ) );
		}

		return true;
	}

	/**
	 * Retrieves a password reset key for the user.
	 *
	 * @param WP_User $user The user data.
	 *
	 * @return string|WP_Error The password reset key or a WP_Error object if the key could not be generated.
	 */
	private function get_reset_password_key( WP_User $user ): string {
		if ( ! ( $user instanceof WP_User ) ) {
			return new WP_Error( 'invalidcombo', __( '<strong>Error:</strong> There is no account with that username or email address.' ) );
		}

		$rand_pass  = wp_generate_password( 20, false );
		$expiration = time() + DAY_IN_SECONDS;

		$key = $expiration . ':' . $rand_pass;
		update_user_meta( $user->ID, 'password_reset_key', $key );

		return $rand_pass;
	}

	/**
	 * Checks the reset password key and returns the user data if the key is valid.
	 *
	 * @param string $key         The password reset key.
	 * @param string $userlogin   The username or email of the user.
	 *
	 * @return WP_User|WP_Error The user data if the key is valid, or a WP_Error object if the key is invalid.
	 */
	private function check_reset_password_key( string $key, string $userlogin ) {
		if ( empty( $key ) || ! is_string( $key ) || empty( $userlogin ) || ! is_string( $userlogin ) ) {
			return new WP_Error( 'invalid_key', __( 'Invalid key.' ) );
		}

		if ( is_email( $userlogin ) ) {
			$userdata = get_user_by( 'email', $userlogin );
		} else {
			$userdata = get_user_by( 'login', $userlogin );
		}

		if ( ! $userdata ) {
			return new WP_Error( 'invalid_key', __( 'Invalid key.' ) );
		}

		$exist_key = get_user_meta( $userdata->ID, 'password_reset_key', true );
		if ( empty( $exist_key ) ) {
			return new WP_Error( 'expired_key', __( 'Invalid key.' ) );
		}

		list($expiration, $pass_key) = explode( ':', $exist_key );
		if ( ! $expiration || time() > $expiration || $pass_key !== $key ) {
			delete_user_meta( $userdata->ID, 'password_reset_key' );
			return new WP_Error( 'expired_key', __( 'Invalid key.' ) );
		}

		delete_user_meta( $userdata->ID, 'password_reset_key' );
		return $userdata;
	}

	/**
	 * Resets the user's password.
	 *
	 * @param array $args The reset password arguments.
	 *
	 * @return array The response with status and message.
	 */
	public function reset_my_password( $args ) {
		if ( ! $args || empty( $args ) || empty( $args['userlogin'] ) || empty( $args['new_password'] ) || empty( $args['repeat_password'] ) || empty( $args['verification_token'] ) ) {
			return [
				'data'   => [
					'status'  => false,
					'message' => __( 'Field cannot be empty!', 'kiranime' ),
				],
				'status' => 400,
			];
		}

		$user = $this->check_reset_password_key( $args['verification_token'], $args['userlogin'] );
		if ( is_wp_error( $user ) ) {
			return [
				'data'   => [
					'status'  => false,
					'message' => $user->get_error_message(),
				],
				'status' => 400,
			];
		}

		if ( ! $user ) {
			return new WP_REST_Response(
				[
					'status'  => false,
					'message' => __( 'Wrong username or password.', 'kiranime' ),
				]
			);
		}

		wp_set_password( $args['new_password'], $user->ID );
		return [
			'data'   => [
				'status'  => true,
				'message' => __( 'Password reset successuflly! You can login now.', 'kiranime' ),
			],
			'status' => 200,
		];
	}
}
