<?php
/**
 * Class for kiranime query
 *
 * @package   Kiranime
 * @since   2.0.0
 * @link      https://kiranime.moe
 * @author    Dzul Qurnain
 * @license   GPL-2.0+
 */
class Kira_Query {

	/**
	 * All posts without processing
	 *
	 * @var array $posts
	 */
	public $posts;

	/**
	 * Total posts count
	 *
	 * @var int $count
	 */
	public $count;

	/**
	 * All animes instances
	 *
	 * @var Anime[] $animes
	 */
	public $animes;

	/**
	 * All episode instances
	 *
	 * @var Episode[] $episodes
	 */
	public $episodes;

	/**
	 * Base query arguments
	 *
	 * @var array $base
	 */
	public $base = [
		'post_status'    => 'publish',
		'order'          => 'DESC',
		'orderby'        => 'date',
		'posts_per_page' => 10,
	];

	/**
	 * Query arguments for current query
	 *
	 * @var array $query  The query parameters.
	 */
	public $query = [];

	/**
	 * Post type for current query
	 *
	 * @var string $type
	 */
	public $type = 'anime';

	/**
	 * Wether the query results are empty or not.
	 *
	 * @var boolean $empty
	 */
	public $empty = false;

	/**
	 * Max number of pages for current query
	 *
	 * @var int $pages
	 */
	public $pages = 0;

	/**
	 * Current query WP_Query
	 *
	 * @var WP_Query $wp_query  The WordPress Query object.
	 */
	public $wp_query;

	/**
	 * Kira_Query constructor.
	 *
	 * @param array  $query  The query parameters.
	 * @param string $type   The type of query.
	 * @param bool   $regex  Whether to use regex.
	 * @param bool   $manual Whether to use manual mode.
	 */
	public function __construct( $query = [], $type = 'anime', $regex = false, $manual = false ) {
		if ( $regex ) {
			$this->query = array_merge( $this->base, array_merge( [ 'post_type' => $type ], $query ) );
		}
		if ( ! empty( $query ) && ! $regex && ! $manual ) {
			$this->query = array_merge( $this->base, array_merge( [ 'post_type' => $type ], $query ) );
			$this->type  = $type;

			$this->get_results();
		}
	}

	/**
	 * Sets the results for the current query.
	 *
	 * @param \WP_Query $res The WordPress Query object.
	 *
	 * @return void
	 */
	private function set_results( \WP_Query $res ) {
		$this->wp_query = $res;

		$this->pages = $res->max_num_pages;

		$this->count = $res->post_count;
		$this->posts = $res->posts;

		$this->empty = empty( $res->posts );

		if ( 'anime' === $this->type ) {
			$animes = [];
			foreach ( $res->posts as $post ) {
				$animes[] = new Anime( $post->ID );
			}

			$this->animes = $animes;
		} elseif ( 'episode' === $this->type ) {
			$episodes = [];
			foreach ( $res->posts as $post ) {
				$episodes[] = new Episode( $post->ID );
			}

			$this->episodes = $episodes;
		}
	}

	/**
	 * Retrieves and sets the results for the current query.
	 *
	 * @return void
	 */
	private function get_results() {
		$res = new WP_Query( $this->query );

		$this->set_results( $res );
	}
	/**
	 * Retrieves a list of anime featured in the spotlight section.
	 *
	 * @return Kira_Query The current instance.
	 */
	public function spotlight() {
		$max_count    = get_theme_mod( '__show_spotlight_count', 10 );
		$spotlight_by = get_theme_mod( '__show_spotlight_by', 'updated' );
		$popular_by   = get_theme_mod( '__show_spotlight_popular_by', 'total' );
		$anime_status = get_theme_mod( '__show_spotlight_status', 'all' );
		$meta_order   = match ( $spotlight_by ) {
			'updated'   => 'kiranime_anime_updated',
			default     => null
		};
		if ( empty( $meta_order ) ) {
			$meta_order = match ( $popular_by ) {
				'daily'     => gmdate( 'dmY' ) . '_kiranime_views',
				'weekly'    => gmdate( 'WY' ) . '_kiranime_views',
				'monthly'     => gmdate( 'FY' ) . '_kiranime_views',
				default     => 'total_kiranime_views'
			};
		}

		$default = [
			'post_type'           => 'anime',
			'post_status'         => 'publish',
			'posts_per_page'      => $max_count,
			'orderby'             => 'meta_value_num',
			'order'               => 'DESC',
			'meta_key'            => $meta_order,
			'no_found_rows'       => true,
			'ignore_sticky_posts' => true,
			'tax_query'           => [],
		];

		// If 'all' is not selected for anime_status, add a condition.
		if ( 'all' !== $anime_status ) {
			$status_id = get_term_by( 'slug', $anime_status, 'status' );

			if ( ! empty( $status_id ) ) {
				$default['tax_query'][] = [
					'taxonomy' => 'status',
					'fields'   => 'term_id',
					'terms'    => $status_id->term_id,
				];
			}
		}

		$with_checks = array_merge(
			$default,
			[
				'meta_query' => [
					'relation' => 'AND',
					[
						'key'     => MetaPrefix::anime->value . 'spotlight',
						'compare' => '=',
						'value'   => 'on',
					],
				],
			]
		);

		$q_1 = new WP_Query( $with_checks );
		if ( empty( $q_1->posts ) ) {
			$q_1 = new WP_Query( $default );
		}
		$this->set_results( $q_1 );
		return $this;
	}

	/**
	 * Executes a search query based on the provided keyword.
	 *
	 * @param string $query The keyword to search for.
	 *
	 * @return array An array containing the search results.
	 */
	public function search_query( $query = '' ) {

		$result  = $this->advanced_search(
			[
				'keyword' => $query,
				'single'  => [],
			],
			true
		);
		$results = '';
		foreach ( $result['data'] as $p ) {
			$anime    = $p;
			$type     = isset( $anime->taxonomies['type'] ) ? $anime->taxonomies['type'][0]->name : '';
			$image    = get_the_post_thumbnail(
				$anime->post,
				'smallthumb',
				[
					'class' => 'inset-0 absolute object-cover h-full w-auto min-w-[3rem]',
					'alt'   => $anime->post->post_title,
				]
			);
			$en_title = $anime->meta['english'] ?? '';
			$title    = $anime->post->post_title;
			ob_start();?>
				<a href="<?php echo esc_url_raw( $anime->url ); ?>" class="w-full p-2 border-b border-dashed border-gray-400 border-opacity-30 flex gap-2">
				<div class="pbe-17 relative overflow-hidden w-12 h-full flex-shrink-0 flex-grow-0">
				<?php echo $image; ?>
				</div>
				<div class="flex-auto group">
					<h3 class="text-[13px] font-medium line-clamp-1 leading-6 group-hover:text-accent">
						<?php if ( ! empty( $en_title ) ) : ?>
							<span data-en-title style="-webkit-line-clamp: 1;"><?php echo $en_title; ?></span>
							<span data-nt-title style="-webkit-line-clamp: 1;"><?php echo $title; ?></span>
						<?php else : ?>
							<?php echo $title; ?>
						<?php endif; ?>
					</h3>
					<div class="flex items-center flex-wrap gap-1 text-xs">
						<span class="block w-full">
							<?php echo esc_attr( $anime->meta['premiered'] ?? '' ); ?>
						</span>
						<span class="uppercase"><?php echo esc_attr( $type ?? '' ); ?></span>
						<span class="material-icons-round text-base">arrow_right</span>
						<span><?php /* Translators: Anime duration */ printf( esc_attr__( '%sM', 'kiranime' ), preg_replace( '/[^0-9]/mi', '', $anime->meta['duration'] ?? '24' ) ); ?></span>
					</div>
				</div>
			</a>
			<?php
			$results .= ob_get_clean();
		}

		return [ 'result' => $results ];
	}
	/**
	 * Executes a season anime search based on the provided query.
	 *
	 * @param string $query The search query.
	 *
	 * @return array An array of anime titles that match the search query.
	 */
	public function get_season_anime_search( $query = '' ) {
		$result = $this->advanced_search(
			[
				'keyword' => $query,
				'single'  => [],
			],
			false,
			true
		);
		return array_map( fn ( $v ) => get_the_title( $v ), $result );
	}

	/**
	 * Executes an advanced search query based on provided parameters.
	 *
	 * @param array $query   The search query parameters.
	 * @param bool  $is_header Whether to return header data.
	 * @param bool  $raw     Whether to return raw post IDs.
	 *
	 * @return array The search results.
	 */
	public function advanced_search( $query = [], $is_header = false, $raw = false ) {
		$count  = get_theme_mod( '__archive_count', 24 );
		$dquery = [
			'post_type'      => 'anime',
			'fields'         => 'ids',
			'orderby'        => 'meta_value_num',
			'meta_key'       => 'total_kiranime_views',
			'posts_per_page' => $count,
			'tax_query'      => [],
			'meta_query'     => [
				'relation' => 'AND',
			],
		];

		$keyword = sanitize_text_field( trim( $query['keyword'] ) );

		if ( $keyword ) {
			$dquery['meta_query'][] = [
				'key'     => 'kiranime_anime_search_index',
				'value'   => $keyword,
				'compare' => 'REGEXP',
			];
		}

		$single_queries = $query['single'] ?? [];
		foreach ( $single_queries as $key => $value ) {
			if ( in_array( $key, [ 'season', 'year' ] ) ) {
				continue;
			}
			$sanitized_value = sanitize_text_field( $value );
			$dquery[ $key ]  = $sanitized_value;
		}

		$single_queries['season'] ??= '';
		$single_queries['year']   ??= '';
		if ( $single_queries['season'] || $single_queries['year'] ) {
			$season                 = $single_queries['season'] ? $single_queries['season'] . ' ' : '';
			$year                   = $single_queries['year'] ? $single_queries['year'] : '';
			$premiered              = $season . $year;
			$dquery['meta_query'][] = [
				'key'     => MetaPrefix::anime->value . 'premiered',
				'value'   => $premiered . '$',
				'compare' => 'REGEXP',
			];
		}

		$taxonomies = $query['tax'] ?? [];
		foreach ( $taxonomies as $taxonomy ) {
			$operator              = 'genre' === $taxonomy['taxonomy'] ? 'AND' : 'IN';
			$dquery['tax_query'][] = [
				'taxonomy' => $taxonomy['taxonomy'],
				'field'    => 'term_id',
				'terms'    => $taxonomy['terms'],
				'operator' => $operator,
			];
		}

		$q = new WP_Query( $dquery );

		if ( $raw ) {
			return $q->posts;
		}

		$results = [];
		foreach ( $q->posts as $p ) {
			$anime = new Anime( $p );
			if ( $is_header ) {
				$anime->get_featured( type: KiraType::anime )->gets( MetaPrefix::anime )->get_taxonomies( 'type', 'anime_attribute', 'status' )->add_view()->get_episodes( true, 1 );
			}
			$results[] = $anime;
		}

		$result = [
			'data'  => $results,
			'pages' => $q->max_num_pages,
			'total' => $q->found_posts,
		];
		if ( ! $is_header ) {
			ob_start();
			get_template_part(
				'template-parts/sections/listing/use',
				'grid',
				[
					'animes' => $results,
				]
			);
			$result['data'] = ob_get_clean();
		}

		return $result;
	}

	public function advanced_search_first_page( $query = [] ) {
		$count = get_theme_mod( '__archive_count', 24 );

		$dquery = [
			'post_type'      => 'anime',
			'fields'         => 'ids',
			'order'          => $query['order'] ?? 'desc',
			'orderby'        => $query['orderby'] ?? 'meta_value_num',
			'posts_per_page' => $count,
			'tax_query'      => [],
			'meta_query'     => [
				'relation' => 'AND',
			],
		];

		if ( ! empty( $query['orderby'] ) && ! in_array( $query['orderby'], [ 'title', 'date' ] ) ) {
			$dquery['meta_key'] = match ( $query['orderby'] ) {
				'popular' => 'total_kiranime_views',
				'favorite'=> 'bookmark_count',
				'updated'   => 'kiranime_anime_updated'
			};
			$dquery['orderby'] = 'meta_value_num';
		}

		if ( ! empty( $query['keyword'] ) ) {
			$dquery['meta_query'][] = [
				'key'     => 'kiranime_anime_search_index',
				'value'   => $query['keyword'],
				'compare' => 'REGEXP',
			];
		}

		$taxs = [
			'genre'    => $query['genre'],
			'producer' => $query['producer'],
			'studio'   => $query['studio'],
			'licensor' => $query['licensor'],
			'type'     => $query['type'],
			'status'   => $query['status'],
		];
		foreach ( $taxs as $taxonomy => $values ) {
			if ( empty( $values ) ) {
				continue;
			}
			$operator              = 'genre' === $taxonomy ? 'AND' : 'IN';
			$dquery['tax_query'][] = [
				'taxonomy' => $taxonomy,
				'field'    => 'slug',
				'terms'    => $values,
				'operator' => $operator,
			];
		}

		$q = new WP_Query( $dquery );

		$results = array_map( fn( $v )=> new Anime( $v ), $q->posts );
		ob_start();
			get_template_part(
				'template-parts/sections/listing/use',
				'grid',
				[
					'animes' => $results,
				]
			);
		$html_results = ob_get_clean();

		$result = [
			'data'       => $html_results,
			'pagination' => [
				'pages' => $q->max_num_pages,
				'total' => $q->found_posts,
			],
		];

		return $result;
	}

	/**
	 * Executes an admin search query based on the provided keyword.
	 *
	 * @param string $query The keyword to search for.
	 *
	 * @return array An array containing the search results.
	 *
	 * @type array [
	 *     'data'   => An array of search results,
	 *     'status' => The HTTP status code,
	 * ]
	 */
	public function admin_search( string $query ) {

		$q = new WP_Query(
			array_merge(
				$this->base,
				[
					'meta_query'          => [
						'relation' => 'AND',
						[
							'key'     => 'kiranime_anime_search_index',
							'value'   => $query,
							'compare' => 'REGEXP',
						],
					],
					'post_type'           => 'anime',
					'posts_per_page'      => 10,
					'order'               => 'ASC',
					'orderby'             => 'title',
					'post_status'         => [
						'draft',
						'publish',
					],
					'ignore_sticky_posts' => true,
					'no_found_rows'       => true,
				]
			)
		);

		$results = array_map(
			function ( $post ) {
				$meta     = json_decode( get_post_meta( $post->ID, MetaPrefix::anime->value, true ) ?: '[]' );
				$episodes = $meta ? $meta['episodes'] : 0;
				return [
					'title'    => $post->post_title,
					'id'       => $post->ID,
					'slug'     => $post->post_name,
					'anime_id' => $post->ID,
					'episodes' => $episodes,
				];
			},
			$q->posts
		);

		return [
			'data'   => $results,
			'status' => 200,
		];
	}

	/**
	 * Applies a regular expression to the post titles in the WHERE clause of a WP_Query.
	 *
	 * @param string   $where    The current WHERE clause of the WP_Query.
	 * @param WP_Query $wp_query The current WP_Query object.
	 *
	 * @return string The modified WHERE clause with the added regular expression.
	 */
	public function use_regex( $where, $wp_query ) {
		global $wpdb;
		$search_term = $wp_query->get( 'search_title' );
		if ( ! empty( $search_term ) ) {
			$where .= ' AND ' . $wpdb->posts . '.post_title REGEXP ' . "'" . $search_term . "'";
		}
		return $where;
	}

	/**
	 * Applies a regular expression to the post titles in the WHERE clause of a WP_Query.
	 *
	 * This function modifies the WHERE clause of a WP_Query to include a regular expression
	 * that matches the post titles. It retrieves the search keyword from the query parameters
	 * and uses it to construct the regular expression.
	 *
	 * @param string   $where    The current WHERE clause of the WP_Query.
	 * @param WP_Query $query    The current WP_Query object.
	 *
	 * @return string The modified WHERE clause with the added regular expression.
	 */
	public function search_keywords( $where, $query ) {
		global $wpdb;
		$search_term = $query->get( 'keyword' );
		if ( ! empty( $search_term ) ) {
			$where .= ' AND ' . $wpdb->posts . '.post_title LIKE \'%' . esc_sql( $wpdb->esc_like( $search_term ) ) . '%\'';
		}
		return $where;
	}

	/**
	 * Retrieves a list of anime objects based on a regular expression search in the post titles.
	 *
	 * @return Kira_Anime_Query The current instance of the class.
	 *
	 * @uses add_filter() To add a custom WHERE clause to the WP_Query.
	 * @uses WP_Query() To execute the modified query.
	 * @uses new Anime() To create an Anime object for each post in the query results.
	 * @uses remove_filter() To remove the custom WHERE clause from the WP_Query.
	 * @uses $this->animes[] To store the created Anime objects.
	 * @uses $this->count, $this->pages, $this->empty To store the query results count, pages, and emptiness.
	 */
	public function get_regex_result() {
		add_filter( 'posts_where', [ $this, 'use_regex' ], 10, 2 );
		$main = new WP_Query( $this->query );
		remove_filter( 'posts_where', [ $this, 'use_regex' ], 10, 2 );

		foreach ( $main->posts as $p ) {
			$this->animes[] = new Anime( $p->ID );
		}

		$this->count = $main->post_count;
		$this->pages = $main->max_num_pages;
		$this->empty = 0 === $main->post_count;

		return $this;
	}

	/**
	 * Retrieves a list of anime objects based on a trending status.
	 *
	 * The function constructs a WP_Query with specific parameters to fetch anime posts based on the trending status.
	 * If the trending status is not 'all', it adds a tax_query to filter the posts based on the status.
	 * The function then executes the query and sets the results using the set_results method.
	 *
	 * @return Kira_Anime_Query The current instance of the class.
	 */
	public function trending() {
		$trend_status = get_theme_mod( '__show_trending_status', 'all' );
		$query        = [
			'orderby'                => 'meta_value_num',
			'meta_key'               => gmdate( 'FY' ) . '_kiranime_views',
			'posts_per_page'         => get_theme_mod( '__show_trending_count', 10 ),
			'post_type'              => 'anime',
			'no_found_rows'          => true,
			'ignore_sticky_posts'    => true,
			'update_post_term_cache' => false,
			'update_post_meta_cache' => false,
		];

		if ( 'all' !== $trend_status ) {
			$query['tax_query'] = [
				[
					'taxonomy' => 'status',
					'field'    => 'slug',
					'terms'    => $trend_status,
				],
			];
		}

		$res = new WP_Query( $query );
		$this->set_results( $res );
		return $this;
	}
}
