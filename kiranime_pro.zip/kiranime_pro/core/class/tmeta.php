<?php

trait Kira_Meta {

	/**
	 * The metadata for the post.
	 *
	 * @var array $meta
	 */
	public array $meta = [];
	/**
	 * An array to store the meta keys.
	 *
	 * @var array $meta_keys
	 */
	public array $meta_keys = [
		'anime'        => [ 'spotlight', 'rate', 'native', 'english', 'synonyms', 'aired', 'premiered', 'duration', 'episodes', 'score', 'name', 'season', 'voted', 'voted_by', 'vote_score', 'characters', 'id', 'service_name', 'trailer' ],
		'episode'      => [ 'number', 'title', 'released', 'parent_id', 'parent_name', 'parent_slug', 'anime_id', 'duration', 'anime_season', 'anime_type', 'tmdb_fetch_episode', 'thumbnail' ],
		'episode_show' => [ 'number', 'title', 'duration', 'released', 'thumbnail' ],
	];
	/**
	 * The download data for the current post.
	 *
	 * @var array $download
	 */
	public array $download = [];

	/**
	 * The images data for the current post.
	 *
	 * @var array $images
	 */
	public array $images = [
		'featured_url'    => '',
		'featured_html'   => '',
		'background_url'  => '',
		'background_html' => '',
	];

	/**
	 * Retrieves a meta value.
	 *
	 * @param string $key     The meta key.
	 * @param bool   $single  Whether to return a single value.
	 * @return mixed          The meta value.
	 */
	public function get( string $key = '', bool $single = true ) {
		return get_post_meta( $this->id, $key, $single );
	}

	/**
	 * Sets a meta value for the current post.
	 *
	 * @param string $key   The meta key.
	 * @param mixed  $value The meta value.
	 *
	 * @return int|bool Meta ID if the key didn't exist, true on successful update, false on failure or if the value passed to the function
	 * is the same as the one that is already in the database.
	 */
	public function set( string $key = '', mixed $value = '' ) {
		return update_post_meta( $this->id, $key, $value );
	}

	/**
	 * Removes a meta value from the post.
	 *
	 * @param string $key The meta key.
	 *
	 * @return bool True on success, false on failure.
	 */
	public function remove( string $key ) {
		return delete_post_meta( $this->id, $key );
	}

	/**
	 * Get post metadata
	 *
	 * @param MetaPrefix $prefix enum prefix for post type.
	 *
	 * @return self
	 */
	public function gets( MetaPrefix $prefix ) {
		$metas = [];
		foreach ( $this->meta_keys[ $this->post->post_type ] as $key ) {
			if ( in_array( $key, [ 'season', 'name', 'premiered', 'parent_id', 'number', 'spotlight', 'thumbnail' ] ) ) {
				$this->meta[ $key ] = $this->get( $prefix->value . $key );
				continue;
			}
		}

		$metadata_value = $this->get( $prefix->value . 'metadata', true );

		$metadata = Kira_Utility::safe_decode( value: $metadata_value, assoc:true, unslash:true, convert:true );
		$metadata = ! empty( $metadata ) ? array_merge( $metadata, $metas ) : $metas;
		foreach ( $metadata as $key => $value ) {
			$this->meta[ $key ] = $value;
		}

		return $this;
	}

	/**
	 * Update post metadata
	 *
	 * @param KiraType $type enum post type.
	 * @param array    $updates the update data.
	 *
	 * @return self
	 */
	public function sets( KiraType $type, array $updates = [] ) {
		$prefix  = MetaPrefix::fromName( $type->value );
		$to_save = $this->get_to_save( $type, $prefix, $updates );

		foreach ( $to_save as $key => $value ) {
			$this->set( $prefix->value . $key, is_array( $value ) ? json_encode( $value, JSON_UNESCAPED_UNICODE ) : $value );
		}

		return $this->gets( $prefix );
	}

	/**
	 * Get the meta data to save.
	 *
	 * @param KiraType   $type    The type of the post.
	 * @param MetaPrefix $prefix  The prefix for the meta keys.
	 * @param array      $the_meta The existing meta data.
	 *
	 * @return array The meta data to save.
	 */
	private function get_to_save( KiraType $type, MetaPrefix $prefix, array $the_meta = [] ) {
		$separated = match ( $type ) {
			KiraType::anime => [
				'season',
				'name',
				'premiered',
				'spotlight',
			],
			KiraType::episode => [
				'number',
				'parent_id',
				'thumbnail',
			],
			default => []
		};

		$metas         = [];
		$accepted_keys = $this->meta_keys[ $type->value ];
		foreach ( $the_meta as $key => $value ) {
			$key = str_ireplace( $prefix->value, '', $key );
			if ( ! in_array( $key, $accepted_keys ) ) {
				continue;
			}

			if ( 'characters' === $key ) {
				$value = is_array( $value ) ? json_decode( json_encode( $value, JSON_UNESCAPED_UNICODE ), true ) : json_decode( wp_unslash( $value ), true );
			}

			$value = Kira_Utility::escape_quotes( $value );

			if ( in_array( $key, $separated ) ) {
				$metas[ $key ] = $value;
				continue;
			}

			$metas['metadata'][ $key ] = $value;
		}

		return $metas;
	}

	/**
	 * Sets the spotlight value for the current post.
	 *
	 * @param bool|string|null $value The spotlight value.
	 * @param string           $key   The meta key.
	 *
	 * @return $this
	 */
	public function set_spotlight( bool|string|null $value = '', $key = '' ) {
		if ( is_null( $value ) || ( is_bool( $value ) && $value ) || empty( $value ) ) {
			$this->remove( $key );
		} else {
			$this->set( $key, 'on' );
		}
		return $this;
	}

	/**
	 * Sets the featured image for the post.
	 *
	 * @param KiraType        $type The type of post (anime or episode).
	 * @param string|int|null $featured The URL or ID of the featured image.
	 *
	 * @return $this
	 */
	public function set_featured( KiraType $type, string|int|null $featured = null ) {
		$prefix = MetaPrefix::fromName( $type->value );
		$name   = KiraType::anime === $type ? 'featured' : 'thumbnail';
		$key    = $prefix->value . $name;

		if ( empty( $featured ) ) {
			return $this;
		}

		if ( get_option( '__kira_external_images', false ) ) {
			if ( filter_var( $featured, FILTER_VALIDATE_URL ) ) {
				$this->meta[ $name ] = $featured;
				$this->set( $key, $featured );
			}
			return $this;
		}

		if ( filter_var( $featured, FILTER_VALIDATE_URL ) ) {
			if ( str_contains( $featured, get_bloginfo( 'url' ) ) ) {
				$id = Kira_Utility::image_to_id( $featured );
			} else {
				$downloaded = Kira_Utility::get_remote_image( $featured, $this->id );
				if ( ! empty( $downloaded['status'] ) ) {
					$id = $downloaded['thumbnail_id'];
				}
			}
		} else {
			$id = intval( $featured );
		}

		if ( 0 === $id ) {
			$id = get_post_thumbnail_id( $this->id ) ?: 0;
		}

		if ( is_numeric( $id ) && $id > 0 ) {
			set_post_thumbnail( $this->id, $id );
		}

		$this->meta[ $name ] = $id;

		return $this;
	}


	/**
	 * Sets the background image for the specified type.
	 *
	 * @param KiraType   $type The type of content (anime or episode).
	 * @param string|int $background The URL or ID of the background image.
	 * @return $this
	 */
	public function set_background( KiraType $type, string|int $background = '' ) {
		$prefix = MetaPrefix::fromName( $type->value );
		$key    = $prefix->value . 'background';

		$id = $background;

		if ( get_option( '__kira_external_images', false ) ) {
			$this->meta['background'] = $background;
			$this->set( $key, $id );
			return $this;
		}

		if ( ! empty( $background ) && is_numeric( $background ) ) {
			$this->meta['background'] = $background;
		} elseif ( filter_var( $background, FILTER_VALIDATE_URL ) || filter_var( $background, FILTER_VALIDATE_DOMAIN ) ) {
			if ( str_contains( $background, get_bloginfo( 'url' ) ) === false ) {
				$downloaded = Kira_Utility::get_remote_image( $background, $this->id );
				if ( ! empty( $downloaded['status'] ) ) {
					$id = $downloaded['thumbnail_id'];
				}
			} else {
				$id = Kira_Utility::image_to_id( $background );
			}
		}

		$this->meta['background'] = $id;
		$this->set( $key, $id );

		return $this;
	}

	/**
	 * If the external image is enabled, then use the external image if available or get the thumbnail from the current post.
	 *
	 * @param KiraType $type The post type.
	 * @param string   $size The image size.
	 * @param array    $attributes The html attribute to add.
	 */
	private function get_external_featured_image( KiraType $type, string $size = 'kirathumb', array $attributes = [] ) {
		$meta_key  = KiraType::anime === $type ? 'kiranime_anime_featured' : 'kiranime_episode_thumbnail';
		$meta_name = KiraType::anime === $type ? 'featured' : 'thumbnail';

		$featured = $this->get( $meta_key, true );

		if ( empty( $featured ) ) {
			return $this;
		}

		$this->meta[ $meta_name ] = $featured;
		if ( is_numeric( $featured ) ) {
			$this->images['featured_url']  = wp_get_attachment_url( $featured );
			$this->images['featured_html'] = wp_get_attachment_image( $featured, $size, false, $attributes );

			return $this->set_lazy_load();
		}

		$this->images['featured_url'] = $featured;

		$attributes['class'] ??= '';
		$attributes['alt']   ??= $this->post->post_title . ' thumbnail';

		$attr = '';
		foreach ( $attributes as $key => $value ) {
			$value = esc_attr( $value );
			$attr .= "$key='$value' ";
		}

		$this->images['featured_html'] = "<img src='$featured' $attr decoding='async'>";

		return $this->set_lazy_load();
	}

	/**
	 * Retrieves the featured image for the specified type.
	 *
	 * @param KiraType $type The type of post (anime or episode).
	 * @param string   $custom_name Custom name for the featured image.
	 * @param string   $size Size of the featured image.
	 * @param array    $attributes Additional attributes for the featured image.
	 * @return $this
	 */
	public function get_featured( KiraType $type, string $custom_name = '', string $size = 'kirathumb', array $attributes = [] ) {

		if ( get_option( '__kira_external_images', false ) ) {
			$this->get_external_featured_image( $type, $size, $attributes );
		}

		if ( ! empty( $this->images['featured_url'] ) ) {
			return $this;
		}

		$featured = get_post_thumbnail_id( $this->id );

		if ( empty( $featured ) || intval( $featured ) <= 0 ) {
			$meta_key  = KiraType::anime === $type ? 'kiranime_anime_featured' : 'kiranime_episode_thumbnail';
			$meta_name = KiraType::anime === $type ? 'featured' : 'thumbnail';

			$featured = $this->get( $meta_key, true );

			if ( ! empty( $featured ) ) {
				$this->set_featured( KiraType::episode, $featured );
				$featured = $this->meta[ $meta_name ] ?? $this->get( $meta_key, true );
			}
		}

		if ( $featured ) {
			$this->images['featured_url']  = wp_get_attachment_url( $featured );
			$this->images['featured_html'] = wp_get_attachment_image( $featured, $size, false, $attributes );
		}

		return $this->set_lazy_load();
	}

	/**
	 * Set the lazy load attribute for the given image.
	 *
	 * @param string $name The field name [featured or background].
	 *
	 * @return $this
	 */
	private function set_lazy_load( string $name = 'featured' ) {
		// Convert double quotes to single quotes.
		$this->images[ $name . '_html' ] = str_replace( '"', "'", $this->images[ $name . '_html' ] );
		if ( get_option( 'kira_use_lazy_load' ) && ! empty( $this->images[ $name . '_html' ] ) ) {
			$html                            = str_ireplace(
				[ "src='", "srcset='", "class='", "sizes='" ],
				[ "data-src='", "data-srcset='","class='lazyload ", "data-sizes='" ],
				$this->images[ $name . '_html' ]
			);
			$this->images[ $name . '_html' ] = str_ireplace( 'data-data', 'data', $html );
		}

		// Adjust image size if width and height are set to 1.
		$pattern = "/(<img.*)width='1' height='1'(.*)/";
		if ( ! empty( $this->images[ $name . '_html' ] ) && preg_match( $pattern, $this->images[ $name . '_html' ], $match ) ) {
			$this->images[ $name . '_html' ] = preg_replace( $pattern, '$1 $2', $this->images[ $name . '_html' ] );
		}
		return $this;
	}

	/**
	 * Retrieves the background image for the specified type.
	 *
	 * @param KiraType $type The type of content (anime or episode).
	 * @param array    $attr Additional attributes for the background image.
	 * @param string   $size Size of the background image.
	 * @return $this
	 */
	public function get_background( KiraType $type, array $attr = [], string $size = 'full' ) {
		$prefix = MetaPrefix::fromName( $type->value );
		$name   = 'background';
		$key    = $prefix->value . $name;

		if ( get_option( '__kira_external_images', false ) ) {
			return $this->get_external_background( $type, $size, $attr );
		}

		$this->meta[ $name ] = $this->get( $key );
		if ( ! isset( $this->meta[ $name ] ) || empty( $this->meta[ $name ] ) ) {
			return $this;
		}

		if ( ! is_numeric( $this->meta[ $name ] ) ) {
			$this->set_background( $type, $this->meta[ $name ] );
		}

		$this->images['background_url']  = wp_get_attachment_url( $this->meta[ $name ] );
		$this->images['background_html'] = wp_get_attachment_image( attachment_id: $this->meta[ $name ], attr: $attr, size: $size );

		return $this->set_lazy_load( 'background' );
	}

	/**
	 * If the external image is enabled, then use the external image if available or get the thumbnail from the current post.
	 *
	 * @param KiraType $type The post type.
	 * @param string   $size The image size.
	 * @param array    $attributes The html attribute to add.
	 */
	private function get_external_background( KiraType $type, string $size = 'kirathumb', array $attributes = [] ) {
		$prefix    = MetaPrefix::fromName( $type->value );
		$meta_name = 'background';
		$meta_key  = $prefix->value . $meta_name;

		$featured = $this->get( $meta_key, true );

		if ( empty( $featured ) ) {
			return $this;
		}

		$this->meta[ $meta_name ] = $featured;
		if ( is_numeric( $featured ) ) {
			$this->images['background_url']  = wp_get_attachment_url( $featured );
			$this->images['background_html'] = wp_get_attachment_image( $featured, $size, false, $attributes );

			return $this->set_lazy_load();
		}

		$this->images['background_url'] = $featured;

		$attr = '';
		foreach ( $attributes as $key => $value ) {
			$attr .= "$key='$value' ";
		}

		$this->images['background_html'] = "<img src='$featured' $attr decoding='async'>";

		return $this->set_lazy_load( 'background' );
	}

	/**
	 * Retrieves the download data for the current episode.
	 *
	 * @return $this
	 */
	public function get_download() {
		$meta = $this->get( 'kiranime_download_data' );

		if ( empty( $meta ) ) {
			return $this;
		}

		$this->download = Kira_Utility::safe_decode( $meta, true ) ?? [];
		return $this;
	}

	/**
	 * Sets the download data for the current episode.
	 *
	 * @param array $download The download data.
	 * @return $this
	 */
	public function set_download( array $download ) {
		if ( ! is_array( $download ) ) {
			return $this;
		}
		$this->download = $download;
		$this->set( 'kiranime_download_data', json_encode( $download, JSON_UNESCAPED_UNICODE ) );
		return $this;
	}

	/**
	 * Retrieves the streams data for the current episode.
	 *
	 * @param KiraType $type The type of content (anime or episode).
	 * @param bool     $backend Whether the function is being called from the backend.
	 * @return $this
	 */
	public function get_streams( KiraType $type, bool $backend = false ) {
		if ( KiraType::episode !== $type ) {
			return $this;
		}
		$streams               = $this->get( 'kiranime_episode_players' );
		$this->meta['streams'] = $streams;
		$streams_data          = Kira_Utility::safe_decode( value: $streams, assoc: true, convert: true );
		$processed             = $this->process_player( $streams_data, $backend );
		$this->streams         = $processed;
		return $this;
	}

	/**
	 * Sets the streams data for the current episode.
	 *
	 * @param KiraType $type The type of content (anime or episode).
	 * @param array    $streams The streams data.
	 * @return $this
	 */
	public function set_streams( KiraType $type, array $streams = [] ) {

		if ( ! is_array( $streams ) || KiraType::episode !== $type ) {
			return $this;
		}

		$sanitized = $this->sanitize_streams( $streams );
		$this->set( 'kiranime_episode_players', json_encode( $sanitized, JSON_UNESCAPED_UNICODE ) );
		return $this;
	}

	/**
	 * Sanitizes the streams data.
	 *
	 * @param array $streams The streams data.
	 * @return array The sanitized streams data.
	 */
	private function sanitize_streams( array $streams ) {
		$sanitized         = [];
		$remove_duplicates = [];
		foreach ( $streams as $stream ) {
			if ( in_array( $stream['host'] . '-' . $stream['type'], $remove_duplicates ) ) {
				continue;
			}

			$remove_duplicates[] = $stream['host'] . '-' . $stream['type'];

			if ( preg_match( '/' . get_shortcode_regex() . '/', $stream['url'] ) ) {
				$new_url     = str_replace( '"', "'", $stream['url'] );
				$sanitized[] = [
					'url'  => $new_url,
					'host' => $stream['host'],
					'type' => $stream['type'],
				];
				continue;
			}

			if ( str_contains( $stream['url'], '<' ) ) {
				$url         = str_ireplace( [ '<', '>', '"' ], [ '_tag_open_', '_tag_close_', "'" ], $stream['url'] );
				$sanitized[] = [
					'url'  => $url,
					'host' => $stream['host'],
					'type' => $stream['type'],
				];
				continue;
			}

			$sanitized[] = $stream;
		}

		return $sanitized;
	}

	/**
	 * Processes the player data.
	 *
	 * @param array $players The player data.
	 * @param bool  $backend Whether the function is being called from the backend.
	 * @return array The processed player data.
	 */
	private function process_player( $players = [], bool $backend = false ) {
		if ( is_null( $players ) || ! is_array( $players ) ) {
			return [];
		}

		$results = [];

		foreach ( $players as $player ) {
			$url      = is_array( $player ) ? $player['url'] : $player->url;
			$host     = is_array( $player ) ? $player['host'] : $player->host;
			$type     = is_array( $player ) ? $player['type'] : $player->type;
			$url_type = 'string';

			if ( stripos( $url, '-dxd-' ) !== false ) {
				$url = explode( '-dxd-', $url );
				$url = base64_decode( array_pop( $url ) );
			}

			if ( stripos( $url, '_tag_open_' ) !== false ) {
				$url      = str_ireplace( [ '_tag_open_', '_tag_close_' ], [ '<', '>' ], $url );
				$url_type = 'html';
			}

			if ( str_contains( $url, '[' ) && ! $backend ) {
				preg_match_all( '/' . get_shortcode_regex() . '/', $url, $matches, PREG_SET_ORDER );
				if ( empty( $matches ) ) {
					continue;
				}

				$url     = do_shortcode( $url );
				$is_html = $this->is_html_video( $url );
				if ( $is_html ) {
					$url_type = 'html';
				}
			}

			$results[] = $backend ? [
				'url'  => $url,
				'host' => $host,
				'type' => $type,
			] : array_merge(
				[
					'url'  => $url,
					'host' => $host,
					'type' => $type,
				],
				[ 'url_type' => $url_type ]
			);
		}

		return $results;
	}

	/**
	 * Checks if the given video is an HTML video.
	 *
	 * @param string $video The video URL.
	 * @return bool True if the video is an HTML video, false otherwise.
	 */
	private function is_html_video( $video ) {
		try {
			$doc            = new DOMDocument();
			$internal_error = libxml_use_internal_errors( true );
			$doc->loadHTML( $video );
			$body = $doc->getElementsByTagName( 'body' );
			libxml_use_internal_errors( $internal_error );
			return ! str_contains( $body->item( 0 )->firstChild?->nodeName, 'text' );
		} catch ( \Exception $e ) {
			return false;
		}
	}

	/**
	 * Retrieves the image ID by URL.
	 *
	 * @param string $key The meta key.
	 * @param string $name The meta name.
	 * @param string $source The image source URL.
	 * @param bool   $is_featured Whether the image is featured.
	 * @return $this
	 */
	public function get_image_id_by_url( string $key, string $name, string $source, bool $is_featured = false ) {
		$id = Kira_Utility::get_remote_image( $source, $this->id );
		if ( empty( $id['status'] ) ) {
			$this->set( $key, $source );
			return $this;
		}
		$this->set( $key, $id['thumbnail_id'] );

		if ( $is_featured ) {
			set_post_thumbnail( $this->id, $id['thumbnail_id'] );
		}

		$this->meta[ $name ] = $this->get( $key );
		return $this;
	}

	/**
	 * Sets the search index for the current post.
	 *
	 * @param MetaPrefix $prefix The meta prefix for the post type.
	 * @return $this
	 */
	public function set_index( MetaPrefix $prefix ) {
		if ( ! isset( $this->meta['synonyms'], $this->meta['native'], $this->meta['english'] ) ) {
			$this->gets( $prefix );
		}
		$synonyms     = ! empty( $this->meta['synonyms'] ) ? ( is_array( $this->meta['synonyms'] ) ? implode( $this->meta['synonyms'] ) : $this->meta['synonyms'] ) : '';
		$data         = [ $synonyms, $this->meta['native'] ?? '', $this->meta['english'] ?? '', $this->post->post_title, $this->post->post_name ];
		$data         = array_filter( $data, fn ( $val ) => (bool) $val );
		$search_index = implode( ', ', $data );
		$this->set( $prefix->value . 'search_index', $search_index );
		$this->meta['search_index'] = $this->get( $prefix->value . 'search_index' );
		return $this;
	}

	/**
	 * Initializes the metadata for the specified post type.
	 *
	 * @param KiraType $type The type of post.
	 * @return $this
	 */
	public function init_meta( KiraType $type ) {
		$prefix   = MetaPrefix::fromName( $type->value )->value;
		$metadata = match ( $type ) {
			KiraType::anime => [
				[
					'key'   => $prefix . 'vote_sum',
					'value' => 0,
				],
				[
					'key'   => $prefix . 'vote_data',
					'value' => json_encode( [] ),
				],
				[
					'key'   => 'total_kiranime_views',
					'value' => 0,
				],
				[
					'key'   => $prefix . 'updated',
					'value' => time(),
				],
				[
					'key'   => 'bookmark_count',
					'value' => 0,
				],
				[
					'key'   => gmdate( 'dmY' ) . '_kiranime_views',
					'value' => 0,
				],
				[
					'key'   => gmdate( 'WY' ) . '_kiranime_views',
					'value' => 0,
				],
				[
					'key'   => gmdate( 'FY' ) . '_kiranime_views',
					'value' => 0,
				],

			],
			KiraType::episode => []
		};

		foreach ( $metadata as $data ) {
			$current_value = $this->get( $data['key'] );
			if ( $current_value ) {
				continue;
			}

			$this->set( $data['key'], $data['value'] );

		}

		return $this;
	}
}
