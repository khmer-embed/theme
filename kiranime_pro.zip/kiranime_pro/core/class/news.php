<?php

/**
 * Class for handling News [post]
 *
 * @package   Kiranime
 * @since     3.0.0
 * @link      https://kiranime.moe
 * @author    Dzul Qurnain
 * @license   GPL-2.0+
 */
class Kiranime_News {

	/**
	 * Constructor for Kiranime_News class.
	 *
	 * @param int|string $id The post ID. Default is 0.
	 */
	public function __construct( public int|string $id = 0 ) {
	}

	/**
	 * Returns the post thumbnail for the current post ID.
	 * If no thumbnail is found, it returns a default image based on the specified size.
	 *
	 * @param string $size     The size of the thumbnail to retrieve. Default is 'full'.
	 * @param array  $attr     Additional attributes for the image tag. Default is an empty array.
	 *
	 * @return string The HTML for the post thumbnail or a default image.
	 */
	public function thumbnail( $size = 'full', $attr = [] ) {
		$current = get_the_post_thumbnail( $this->id, $size, $attr );

		if ( ! $current ) {
			$uri      = get_template_directory_uri();
			$no_image = 'full' === $size ? $uri . '/avatar/no_image_large.png' : $uri . '/avatar/no_image_small.png';
			$class    = isset( $attr['class'] ) ? $attr['class'] : 'no_image';
			return '<img src="' . $no_image . '" class="' . $class . '">';
		}

		return $current;
	}
}
