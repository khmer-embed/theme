<?php

require_once KIRA_DIR . '/class/tmeta.php';

/**
 * Class representing an anime.
 */
class Anime {

	use Kira_Meta;

	/**
	 * WP_Post for the anime
	 *
	 * @var WP_Post|null $post
	 */
	public ?WP_Post $post = null;

	/**
	 * Array of taxonomies for the anime
	 *
	 * @var array $taxonomies
	 */
	public array $taxonomies = [];

	/**
	 * Wether the anime is existing or not
	 *
	 * @var boolean $is_exist
	 */
	public bool $is_exist = false;

	/**
	 * Array of episodes instances for the anime
	 *
	 * @var Episode[] $episodes
	 */
	public ?array $episodes = [];

	/**
	 * Array of related seasons for the anime
	 *
	 * @var array $seasons
	 */
	public array $seasons = [];

	/**
	 * Array of current anime view data statistics
	 *
	 * @var array $statistics
	 */
	public array $statistic = [];

	/**
	 * Array of current anime votes data statistics
	 *
	 * @var array $votes
	 */
	public array $vote = [];

	/**
	 * The episode order
	 *
	 * @var string $episode_order
	 */
	public string $episode_order = 'kiranime_episode_number';

	/**
	 * URL of the anime
	 *
	 * @var string $url
	 */
	public string $url = '';

	/**
	 * Scheduled episode for current anime
	 *
	 * @var Episode $scheduled
	 */
	public ?Episode $scheduled = null;

	/**
	 * Instantiate anime class
	 *
	 * @param string|int|WP_Error|null $id The id of the anime.
	 * @param boolean                  $return_error wether to return when fail to initialize.
	 *
	 * @return void|false Returns false if failed to initialize and $return_error is true.
	 */
	public function __construct( public string|int|\WP_Error|null $id = 0, bool $return_error = false ) {
		if ( $id && ! is_wp_error( $id ) ) {
			$this->init();
		} elseif ( $return_error ) {
			return false;
		}
	}

	/**
	 * Initializes the Anime object with post data and other properties.
	 *
	 * This method retrieves the post data for the given anime ID, sets the URL, ID, and existence status,
	 * and updates the internal properties accordingly.
	 *
	 * @return void
	 */
	private function init(): void {
		$this->post     = get_post( $this->id );
		$this->url      = get_post_permalink( $this->id );
		$this->id       = $this->id;
		$this->is_exist = true;
	}

	/**
	 * Retrieves and sets the taxonomies associated with the anime.
	 *
	 * This function accepts a variable number of taxonomy names as arguments and retrieves the corresponding terms for the anime.
	 * The retrieved terms are stored in the `$taxonomies` property of the Anime object.
	 *
	 * @param string ...$tax The names of the taxonomies to retrieve terms for.
	 * @return self The Anime object for method chaining.
	 */
	public function get_taxonomies( string ...$tax ): self {
		foreach ( $tax as $t ) {
			$this->taxonomies[ $t ] = wp_get_post_terms( $this->id, $t );
		}
		return $this;
	}

	/**
	 * Retrieves and sets the view statistics for the anime.
	 *
	 * This function calculates and stores the view statistics for the anime, including daily, weekly, monthly, and total views.
	 * The view statistics are stored in the `$statistic` property of the Anime object.
	 *
	 * @param string $name The name of the meta to retrieve the view statistics for.
	 * @return self The Anime object for method chaining.
	 */
	public function get_statistic( string $name = 'all' ): self {
		$suffix  = '_kiranime_views';
		$queries = [
			'day'   => gmdate( 'dmY' ) . $suffix,
			'week'  => gmdate( 'WY' ) . $suffix,
			'month' => gmdate( 'FY' ) . $suffix,
			'total' => 'total' . $suffix,
		];

		if ( 'all' === $name ) {
			foreach ( $queries as $k => $q ) {
				$this->statistic[ $k ] = $this->get( $q, true );
			}
		} elseif ( ! empty( $queries[ $name ] ) ) {
			$this->statistic[ $name ] = $this->get( $queries[ $name ], true );
		}
		return $this;
	}

	/**
	 * Retrieves and sets the episodes associated with the anime.
	 *
	 * This function queries the database for episodes related to the anime,
	 * and populates the `$episodes` property of the Anime object.
	 *
	 * @param bool $is_latest Whether to retrieve only the latest episode. Default is true.
	 * @param int  $count The number of episodes to retrieve. Default is -1 (all episodes).
	 * @param bool $asc Use Ascending Order. Default is false.
	 * @param bool $return Whether to return the result or not. Default is false.
	 *
	 * @return self|array|Episode|null The Anime object for method chaining or an array of episodes, or an episode object.
	 */
	public function get_episodes( bool $is_latest = true, int $count = -1, bool $asc = false, bool $return = false ): self|array|Episode|null {
		$results             = [];
		$this->episode_order = get_option( '__q_episode_by', false );

		$args = [
			'post_type'           => 'episode',
			'post_status'         => 'publish',
			'order'               => $asc ? 'ASC' : 'DESC',
			'fields'              => 'ids',
			'posts_per_page'      => $is_latest ? 1 : $count,
			'no_found_rows'       => true,
			'ignore_sticky_posts' => true,
			'meta_query'          => [
				[
					'key'   => MetaPrefix::episode->value . 'parent_id',
					'value' => $this->id,
				],
			],
		];

		$args['orderby'] = match ( $this->episode_order ) {
			'kiranime_episode_number' => 'meta_value_num',
			'kiranime_episode_released'=> 'meta_value',
			'publish_date'  => 'date',
			default => 'meta_value_num'
		};

		if ( 'date' !== $args['orderby'] ) {
			if ( empty( $this->episode_order ) ) {
				$args['meta_key']  = 'kiranime_episode_number';
				$args['meta_type'] = 'DECIMAL';
			} else {
				$args['meta_key'] = $this->episode_order;
				if ( str_contains( $this->episode_order, 'number' ) ) {
					$args['meta_type'] = 'NUMERIC';
				}
			}
		}

		$sql_results = new WP_Query( $args );
		$episodes    = $sql_results->post_count ? $sql_results->posts : [];

		foreach ( $episodes as $episode ) {
			$ep = new Episode( $episode );
			$ep->gets( MetaPrefix::episode )->get_taxonomies( 'episode_type' )->get_featured( type: KiraType::episode, size: 'kirathumb' );
			$results[] = $ep;
		}

		if ( $return ) {
			if ( $is_latest || 1 === $count ) {
				return ! empty( $results ) ? reset( $results ) : null;
			}

			return $results;
		}

		$this->episodes = $is_latest && ! empty( $results ) ? [ $results[0] ] : $results;
		return $this;
	}

	/**
	 * Retrieves and sets the related anime seasons based on the anime's name.
	 *
	 * This function queries the database for anime posts that match the anime's name and season,
	 * and populates the `$seasons` property of the Anime object with the retrieved posts.
	 *
	 * @return self The Anime object for method chaining.
	 *
	 * @throws Exception If the anime's name is empty.
	 */
	public function get_season(): self {
		if ( empty( $this->meta['name'] ) ) {
			return $this;
		}

		$season_animes = new WP_Query(
			[
				'post_type'           => 'anime',
				'post_status'         => 'publish',
				'orderby'             => 'meta_value',
				'meta_key'            => MetaPrefix::anime->value . 'season',
				'order'               => 'ASC',
				'meta_query'          => [
					[
						'key'     => MetaPrefix::anime->value . 'name',
						'value'   => $this->meta['name'],
						'compare' => '=',
					],
				],
				'no_found_rows'       => true,
				'ignore_sticky_posts' => true,
				'posts_per_page'      => 100,
			]
		);

		$this->seasons = $season_animes->posts;
		return $this;
	}

	/**
	 * Creates a new anime post based on the provided data.
	 *
	 * @param array $anime The anime data to be used for creating the post.
	 * @return self|null The Anime object if the post was created successfully, null otherwise.
	 *
	 * @throws Exception If the anime's name is empty.
	 */
	public function create_anime( array $anime ): ?self {
		if ( empty( $anime ) ) {
			return null;
		}

		$title_scrumble = array_map( fn( $val )=> substr( $val, 0, 3 ), explode( ' ', $anime['title'] ) );
		$title_scrumble = implode( ' ', $title_scrumble );
		$title_len      = strlen( $title_scrumble ) > 15 ? $title_scrumble : $title_scrumble . Kira_Utility::random_str( 10 );
		$search_title   = sanitize_title( $title_len );
		$existence      = get_page_by_path( $search_title, OBJECT, 'anime' );
		$post_status    = ! empty( $anime['status'] ) ? $anime['status'] : ( ! empty( $anime['post_status'] ) ? $anime['post_status'] : 'draft' );
		$post_data      = [
			'post_type'    => 'anime',
			'post_status'  => $post_status,
			'post_author'  => get_current_user_id(),
			'post_title'   => $anime['title'],
			'post_content' => $anime['synopsis'] ?? '',
			'post_name'    => $search_title,
		];

		if ( $existence ) {
			$this->id        = $existence->ID;
			$post_data['ID'] = $this->id;
			wp_update_post( $post_data, false, false );
		} else {
			$created_post_id = wp_insert_post( $post_data, true, false );
			if ( is_wp_error( $created_post_id ) ) {
				return null;
			}
			$this->id = $created_post_id;
		}

		$this->post = get_post( $this->id );
		$this->update_taxonomy( $anime )->init_meta( KiraType::anime )->sets( KiraType::anime, $anime );

		$thumb_id = get_post_thumbnail_id( $this->id );
		if ( ! empty( $anime['featured'] ) && ( ! $thumb_id || '-1' === $thumb_id ) ) {
			$this->set_featured( KiraType::anime, $anime['featured'] );
		}

		$bg = $this->meta['background'] ?? '';
		if ( empty( $bg ) && ! empty( $anime['background'] ) ) {
			$this->set_background( KiraType::anime, $anime['background'] );
		}

		$this->set_index( MetaPrefix::anime );

		Kiranime_Cache::clear_single_post( $this->id, 'anime' );

		return $this;
	}

	/**
	 * Updates the taxonomy terms associated with the anime post.
	 *
	 * @param array $anime The anime data to be used for updating taxonomy terms.
	 *
	 * @return self The Anime object for method chaining.
	 */
	public function update_taxonomy( array $anime ): self {
		foreach ( [ 'anime_attribute', 'type', 'genre', 'producer', 'studio', 'licensor', 'status' ] as $taxonomy ) {
			$datakey = 'status' === $taxonomy ? 'airing_status' : $taxonomy;
			if ( isset( $anime[ $datakey ] ) ) {
				wp_set_post_terms( $this->id, $anime[ $datakey ], $taxonomy );
			}
		}
		return $this;
	}

	/**
	 * Adds a view count to the anime post.
	 *
	 * This function updates the view count for the anime post in different time periods (day, week, month, total).
	 * It also checks if the last update was within the last half a day and clears the past views if necessary.
	 *
	 * @return self The Anime object for method chaining.
	 */
	public function add_view(): self {
		$suffix = '_kiranime_views';
		$result = [];

		$dates = [ gmdate( 'dmY' ) . $suffix, gmdate( 'WY' ) . $suffix, gmdate( 'FY' ) . $suffix, 'total' . $suffix ];
		foreach ( $dates as $value ) {
			$current = (int) get_post_meta( $this->id, $value, true );
			++$current;
			update_post_meta( $this->id, $value, $current );
			$result[ $value ] = $current;
		}

		$last_update = (int) get_post_meta( $this->id, 'update_kiranime_views', true );
		$updated     = $last_update && ( time() - $last_update ) < ( DAY_IN_SECONDS / 2 );

		if ( ! $updated ) {
			$past_views = [
				gmdate( 'dmY', strtotime( '-1 day' ) ) . $suffix,
				gmdate( 'WY', strtotime( '-1 week' ) ) . $suffix,
				gmdate( 'FY', strtotime( '-1 month' ) ) . $suffix,
			];

			foreach ( $past_views as $date ) {
				delete_post_meta( $this->id, $date );
			}

			update_post_meta( $this->id, 'update_kiranime_views', time() );
		}

		$this->statistic = $result;
		return $this;
	}

	/**
	 * Adds a vote count to the anime post.
	 *
	 * @param int $vote_value The value of the vote to be added.
	 *
	 * @return self The Anime object for method chaining.
	 */
	public function add_vote( int $vote_value ): self {
		if ( ! $vote_value ) {
			return $this;
		}

		$data  = get_post_meta( $this->id, 'kiranime_anime_vote_data', true );
		$value = $data ? json_decode( $data, true ) : [];

		if ( $this->vote['status'] ?? false ) {
			foreach ( $value as &$val ) {
				if ( get_current_user_id() === ( $val['user'] ?? 0 ) ) {
					$val['value'] = absint( $vote_value );
					break;
				}
			}
		} else {
			$value[] = [
				'user'  => get_current_user_id(),
				'value' => absint( $vote_value ),
			];
		}

		$total_votes = count( $value );
		$total_value = array_sum( array_column( $value, 'value' ) );

		update_post_meta( $this->id, 'kiranime_anime_vote_data', json_encode( $value ) );
		update_post_meta( $this->id, 'kiranime_anime_vote_sum', round( $total_value / $total_votes, 1 ) );

		return $this->get_votes();
	}

	/**
	 * Retrieves and sets the vote data for the anime post.
	 *
	 * @return self The Anime object for method chaining.
	 */
	public function get_votes(): self {
		if ( ! $this->id ) {
			return $this;
		}

		$sum   = (float) get_post_meta( $this->id, 'kiranime_anime_vote_sum', true );
		$voted = get_post_meta( $this->id, 'kiranime_anime_vote_data', true );
		$voted = $voted ? json_decode( $voted, true ) : [];

		$search = [];
		foreach ( $voted as $vote ) {
			if ( get_current_user_id() === ( $vote['user'] ?? 0 ) ) {
				$search[] = $vote;
				break;
			}
		}

		$this->vote = [
			'vote_score' => number_format_i18n( $sum ),
			'voted'      => number_format_i18n( count( $voted ) ),
			'status'     => ! empty( $search ),
			'vote_data'  => $search[0] ?? false,
			'html'       => [
				'1' => '<span class="material-icons-round text-3xl text-yellow-200 plb-1">sentiment_very_dissatisfied</span>',
				'2' => '<span class="material-icons-round text-3xl text-yellow-200 plb-1">sentiment_dissatisfied</span>',
				'3' => '<span class="material-icons-round text-3xl text-yellow-200 plb-1">sentiment_neutral</span>',
				'4' => '<span class="material-icons-round text-3xl text-yellow-200 plb-1">sentiment_satisfied</span>',
				'5' => '<span class="material-icons-round text-3xl text-yellow-200 plb-1">sentiment_very_satisfied</span>',
			],
		];
		return $this;
	}

	/**
	 * Retrieves and sets the scheduled episode for the anime post.
	 *
	 * This function queries the database for the next episode related to the anime,
	 * and populates the `$scheduled` property of the Anime object with the retrieved episode.
	 *
	 * @return self The Anime object for method chaining.
	 */
	public function get_scheduled(): self {
		$post = new WP_Query(
			[
				'post_type'      => 'episode',
				'post_status'    => 'future',
				'orderby'        => 'date',
				'order'          => 'asc',
				'meta_key'       => 'kiranime_episode_parent_id',
				'meta_value'     => $this->id,
				'meta_compare'   => '=',
				'posts_per_page' => 1,
				'fields'         => 'ids',
			]
		);

		if ( $post->post_count ) {
			$p               = array_shift( $post->posts );
			$this->scheduled = ( new Episode( $p ) )->gets( MetaPrefix::episode );
		}

		return $this;
	}

	/**
	 * Saves the anime post data.
	 *
	 * This function verifies the nonce, checks for autosave, and ensures the user has the necessary capabilities.
	 * It then processes the POST data, updates the anime post meta, sets the featured image, background, and index,
	 * and clears the cache for the anime post.
	 *
	 * @return int|null The ID of the anime post, or null if the post was not saved.
	 */
	public function save_post_anime(): ?int {

		if ( empty( $_POST['kiranime_anime_editor_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['kiranime_anime_editor_nonce'] ) ), 'kiranime_anime_editor_nonce' ) || ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) || ! current_user_can( 'edit_posts' ) ) {
			return $this->id;
		}

		$updates = $_POST;

		$serialize_download = [];
		if ( ! empty( $_POST['save_download_data'] ) ) {
			$serialize_download = json_decode( wp_unslash( $updates['save_download_data'] ), true );
		}

		$this
			->sets( KiraType::anime, $updates )
			?->set_download( $serialize_download )
			?->set_featured( KiraType::anime, sanitize_text_field( wp_unslash( $updates['kiranime_anime_featured'] ?? $updates['kiranime_external_thumbnail'] ?? '' ) ) )
			?->set_background( KiraType::anime, sanitize_text_field( wp_unslash( $updates['kiranime_anime_background'] ?? '' ) ) )
			?->init_meta( KiraType::anime )
			?->set_spotlight( $updates['kiranime_anime_spotlight'] ?? null, MetaPrefix::anime->value . 'spotlight' )
			?->set_index( MetaPrefix::anime )
			?->set_updated( $this->id );

		return $this->id;
	}

	/**
	 * Updates the 'kiranime_anime_updated' post meta for the specified anime post ID.
	 *
	 * This function clears the cache for the specified anime post and updates the post meta with the current timestamp.
	 *
	 * @param string|int|null $id The ID of the anime post. If not provided, the function will use the ID of the current anime object.
	 *
	 * @return bool True if the post meta was updated successfully, false otherwise.
	 */
	public static function set_updated( string|int|null $id = null ): bool {
		if ( is_null( $id ) ) {
			return false;
		}

		Kiranime_Cache::clear_single_post( $id, 'anime' );
		Kiranime_Cache::clear_widget_block();
		return update_post_meta( $id, MetaPrefix::anime->value . 'updated', time() );
	}
}
