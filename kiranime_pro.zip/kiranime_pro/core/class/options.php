<?php
/**
 * Class Kiranime_Options
 *
 * Handles Options for the Kiranime Theme.
 *
 * @package Kiranime
 * @since 3.5.4
 */
class Kira_Options {

	/**
	 * Kira_Options constructor.
	 */
	public function __construct() {
		add_action( 'admin_menu', array( $this, 'add_options_page' ) );
		add_action( 'admin_init', array( $this, 'register_settings' ) );
	}

	/**
	 * Adds a submenu page under the "Kira Tools" menu.
	 *
	 * @since 1.0.0
	 */
	public function add_options_page() {
		add_menu_page( 'Kira Tools', 'Kira Tools', 'edit_posts', 'kiranime_tools', '', 'dashicons-admin-generic', 80 );
		if ( ! empty( get_option( gtAcCLK( 1 ), false ) ) ) {
			add_submenu_page( 'kiranime_tools', 'Settings', 'Settings', 'edit_posts', 'kiranime_tools', [ $this, 'options_render_settings' ] );
			add_submenu_page( 'kiranime_tools', 'Info Grabber', 'Grabber', 'edit_posts', 'kiranime_tools_grabbers', [ $this, 'render_grabber' ] );
			add_submenu_page( 'kiranime_tools', 'Reported Episode', 'Reports', 'edit_posts', 'kiranime_tools_episode_reports', [ $this, 'reports' ] );

			add_submenu_page( 'kiranime_tools', 'Kiranime Theme Activation', 'Activation', 'manage_options', 'kiranime_tools_activation_data', [ $this, 'activation' ] );

			if ( empty( get_option( 'kiranime_search_index_done', false ) ) ) {
				add_submenu_page( 'kiranime_tools', 'Build Search Index', 'Search Index', 'manage_options', 'kiranime_tools_create_search_index', [ $this, 'kiranime_build_search_index' ] );
			}

			if ( empty( get_option( 'kiranime_watchlist_migrated', false ) ) ) {
				add_submenu_page( 'kiranime_tools', 'Migrate Watchlist', 'Migrate Watchlist', 'edit_posts', 'kiranime_tools_migrate_watchlist', [ $this, 'kiranime_migrate_watchlist' ] );
			}

			if ( empty( get_option( 'kiranime_anime_migrated', false ) ) ) {
				add_submenu_page( 'kiranime_tools', 'Migrate Anime', 'Migrate Anime Data', 'edit_posts', 'kiranime_tools_migrate_anime_data', [ $this, 'kiranime_migrate_anime_data' ] );
			}
		} else {
			add_submenu_page( 'kiranime_tools', 'Kiranime Theme Activation', 'Activation', 'manage_options', 'kiranime_tools', [ $this, 'activation' ] );
			update_option( 'kiranime_watchlist_migrated', 1 );
			update_option( 'kiranime_anime_migrated', 1 );
		}
	}

	/**
	 * Handles the activation process.
	 *
	 * @return void
	 */
	public function activation() {
		$act_email = get_option( gtAcCLK( 4 ), '' );
		$act_key   = get_option( gtAcCLK( 3 ), '' );
		$theme     = wp_get_theme();
		$key       = get_option( gtAcCLK( 2 ), '' );
		$active    = get_option( gtAcCLK( 1 ), false );
		ob_start();
		$hostname = get_bloginfo( 'url' );
		?>
	
		<script>
			var activation_data = {
				active: <?php echo $active ? 1 : 0; ?>,
				kiraKey: "<?php echo $key; ?>",
				actKey: "<?php echo $act_key; ?>",
				actEmail: "<?php echo $act_email; ?>",
				theme_name: "<?php echo $theme->get( 'TextDomain' ); ?>",
				hostname: "<?php echo $hostname; ?>",
			}
		</script>
		<div id="kiranime-activation-page"></div>
		<?php
		echo ob_get_clean();
	}

	/**
	 * Handle the watchlist migration.
	 */
	public function kiranime_migrate_watchlist() {

		?>
	
		<div id="watchlist_migrator" class="bg-white rounded-md shadow-md drop-shadow-md mbs-6 mie-6">
			<h2 class="w-full block leading-7 text-lg plb-4 pbs-4 ml-4">Watchlist Updater</h2>
			<div class="p-4 mbs-4">
				<div class="mbe-2">Click button below to start migrating user watchlist. This might take a while if you have
					lots
					of anime post. Please don't close this tab while processing.</div>
				<button id="watchlist_migrate" class="inline-flex disabled:opacity-50 justify-center plb-2 pli-8 border border-transparent shadow-sm text-sm font-medium rounded-md text-text-color bg-accent-3 hover:bg-accent-4 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-accent-2">Start
					Migrate</button>
	
				<div class="index-result hidden">
					<div class="progress_shell" style="width: 100%;height: 1.75rem;border: 1px solid #0284c7;border-radius: 999px;position: relative;overflow: hidden;">
						<div class="progress_fill" style="width: 0;height: 100%;background: #026bc7;position: absolute;z-index: 1;">
	
						</div>
						<div class="current_progress animate-pulse" style="width: 0;height: 100%;background: #00abff;position: absolute;inset: 0;z-index: 0;"></div>
						<div class="text_progress" style="position: absolute;inset: 0;z-index: 2;text-align: center;color: white;font-weight: 600;">
							Starting...
						</div>
					</div>
				</div>
			</div>
		</div>
		<script>
			let page = 1,
				max_page = 0;
	
			async function proc_data() {
	
				const indexRes = $(".index-result");
				const progShell = $(".progress_shell");
				const progFill = $(".progress_fill");
				const procCur = $(".current_progress");
				const textProg = $(".text_progress");
	
				procCur.width(max_page === 0 ? `10%` : `${(page / max_page) * 100}%`)
				textProg.text(max_page === 0 ? `Starting...` : `Processing ${page}/${max_page}`)
	
				indexRes.removeClass('hidden');
	
	
				const req = await fetch(site_rest_url + 'watchlist/migrate?page=' + page);
				const res = await req.json();
	
				if (res.status) {
					max_page = res.max_pages;
					progFill.width(`${(page / res.max_pages) * 100}%`)
					page++;
					if (page <= max_page) return await proc_data();
	
					textProg.text('All watchlist hash been migrated successfully.');
					return;
				}
	
				alert('Something went wrong when migrating the data.')
			}
	
			document.querySelector('#watchlist_migrate').addEventListener('click', async (e) => {
				e.preventDefault();
				e.target.classList.add('hidden');
				await proc_data();
			})
	
			if (typeof $ === 'undefined') {
				$ = jQuery;
			}
		</script>
		<?php
	}

	/**
	 * Handle the Anime search index [advanced search].
	 */
	public function kiranime_build_search_index() {
		?>
		<div id="search_index_rebuilder" class="bg-white rounded-md shadow-md drop-shadow-md mbs-6 mie-6">
			<h1 class="leading-10 font-semibold text-lg pli-4">Search Index Tools</h1>
			<div class="p-4 mbs-4">
				<div class="mbe-2">Click button below to start reindex all anime. This might take times if you have lots of
					anime
					post.
					Please don't close this tab while processing.</div>
				<button id="get-no-index" class="inline-flex disabled:opacity-50 justify-center plb-2 pli-8 border border-transparent shadow-sm text-sm font-medium rounded-md text-text-color bg-accent-3 hover:bg-accent-4 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-accent-2">Reindex</button>
	
				<div class="index-result">
	
				</div>
			</div>
		</div>
		<?php
	}
	/**
	 * Handle the Anime data migration for version before 3.5.0.
	 */
	public function kiranime_migrate_anime_data() {
		?>
		<div class="my-8">
			<h1 class="font-semibold text-2xl">Migrate Post data(Anime, Episode)</h1>
		</div>
		<div id="migrate_anime_data" class="space-y-6" style="width: 99%;">
			<div class="progress-info flex flex-col">
				<span data-current-process></span>
				<span data-total-anime></span>
				<span data-current-total></span>
			</div>
			<div class="progress-bar h-fit" style="width: 0;">
				<div class="rounded-md h-4 border-none outline-accent-2 outline-1 outline-offset-2 bg-accent-2 w-full"></div>
			</div>
			<div class="progress-start">
				<div class="w-[calc(100%-1rem)] flex gap-4 items-center">
				<label for="progress_delay">Process Interval (miliseconds)</label>
				<input type="number" id="progress_delay" name="progress_delay" value="0">
				</div>
				<button id="start-anime-migrate" class="px-4 py-2 mt-5 text-sm font-medium bg-accent-2 outline-transparent border-transparent rounded-sm text-white">Start migrate</button>
				<button id="kiranime_anime_migrated" class="px-4 py-2 mt-5 text-sm font-medium bg-error-2 hidden outline-transparent border-transparent rounded-sm text-white">Remove Page (after completed)</button>
			</div>
			<span class="text-error-2"></span>
			<span class="text-accent-2"></span>
			<ul class="progress-logs max-h-96 bg-primary/85 text-white/90 p-4 overflow-y-auto">
				<li>Process logs</li>
			</ul>
		</div>
		<?php
	}

	/**
	 * Register required kiranime settings.
	 */
	public function register_settings() {
		register_setting( 'kiranime_settings', '__a_tmdb' );
		register_setting( 'kiranime_settings', '__a_jikan' );
		register_setting( 'kiranime_settings', '__q_episode_by' );
		register_setting( 'kiranime_settings', '__kira_external_images' );
		register_setting( 'kiranime_settings', '__q_use_post_date' );
		register_setting( 'kiranime_settings', '__q_use_rand_prefix' );
		register_setting( 'kiranime_settings', '__u_def_language' );
		register_setting( 'kiranime_settings', '__u_status_i_du' );
		register_setting( 'kiranime_settings', '__u_status_bg' );
		register_setting( 'kiranime_settings', '__u_status_completed_slug' );
		register_setting( 'kiranime_settings', '__a_show_video_meta' );
		register_setting( 'kiranime_settings', '__use_recaptcha' );
		register_setting( 'kiranime_settings', '__q_title_switcher' );
		register_setting( 'kiranime_settings', '__q_en_title_label' );
		register_setting( 'kiranime_settings', '__q_jp_title_label' );
		register_setting( 'kiranime_settings', 'kiranime_recaptcha_secretkey' );
		register_setting( 'kiranime_settings', 'kiranime_recaptcha_sitekey' );
		register_setting( 'kiranime_settings', 'kira_disable_login_page' );
		register_setting( 'kiranime_settings', 'kira_use_lazy_load' );
		register_setting( 'kiranime_settings', 'kira_use_full_width' );
		register_setting( 'kiranime_settings', '__kira_cache_driver' );
		register_setting( 'kiranime_settings', '__kira_use_cache' );
		register_setting( 'kiranime_settings', '__kira_redis_db' );
		register_setting( 'kiranime_settings', '__kira_redis_host' );
		register_setting( 'kiranime_settings', '__kira_redis_password' );
		register_setting( 'kiranime_settings', '__kira_redis_port' );
		register_setting( 'kiranime_settings', '__kira_redis_username' );
		register_setting( 'kiranime_settings', '__kira_memcached_host' );
		register_setting( 'kiranime_settings', '__kira_memcached_port' );
		register_setting( 'kiranime_settings', '__kira_cache_time' );
		register_setting( 'kiranime_settings', '__ads_header' );
		register_setting( 'kiranime_settings', '__ads_footer' );
		register_setting( 'kiranime_settings', '__ads_after_trending' );
		register_setting( 'kiranime_settings', '__ads_after_featured' );
		register_setting( 'kiranime_settings', '__ads_after_char_va' );
		register_setting( 'kiranime_settings', '__ads_after_episode_lists' );
		register_setting( 'kiranime_settings', '__ads_before_body_episode' );
		register_setting( 'kiranime_settings', '__ads_replace_content_episode' );
		register_setting( 'kiranime_watchlist', '__watchlist_url' );
		register_setting( 'kiranime_watchlist', '__watchlist_title' );
		register_setting( 'kiranime_watchlist', '__watchlist_description' );
		register_setting( 'kiranime_watchlist', '__watchlist_og_meta' );
		register_setting( 'kiranime_settings', '__enable_custom_avatar' );
	}
	/**
	 * Handle the settings rendering.
	 */
	public function options_render_settings() {
		$main_options = [
			'Grabber' => [
				[
					'name'       => __( 'TMDB API Key (v3)', 'kiranime' ),
					'input_type' => 'text',
					'type'       => 'input',
					'value'      => get_option( '__a_tmdb', '' ),
					'key'        => '__a_tmdb',
					'info'       => __( 'TMDB API key. More info: https://developers.themoviedb.org/3', 'kiranime' ),
				],
				[
					'name'       => __( 'Jikan Self Hosted URL', 'kiranime' ),
					'input_type' => 'text',
					'type'       => 'input',
					'value'      => get_option( '__a_jikan', 'https://api.jikan.moe/v4' ),
					'key'        => '__a_jikan',
					'info'       => __( 'Only if you are using a Self hosted Jikan API.', 'kiranime' ),
				],
				[
					'name'    => __( 'TMDB Language', 'kiranime' ),
					'type'    => 'select',
					'value'   => get_option( '__u_def_language', 'en' ),
					'key'     => '__u_def_language',
					'options' => $this->get_tmdb_language(),
					'info'    => __( 'The TMDB Language to use.', 'kiranime' ),
				],
				[
					'name'       => __( 'Use Post date', 'kiranime' ),
					'type'       => 'input',
					'input_type' => 'checkbox',
					'value'      => get_option( '__q_use_post_date', '' ),
					'key'        => '__q_use_post_date',
					'info'       => __( 'Use the post publish date for episode release.', 'kiranime' ),
				],
				[
					'name'       => __( 'Use Random Prefix [episode slug]', 'kiranime' ),
					'type'       => 'input',
					'input_type' => 'checkbox',
					'value'      => get_option( '__q_use_rand_prefix', '' ),
					'key'        => '__q_use_rand_prefix',
					'info'       => __( 'Use the rand prefix for episode release.', 'kiranime' ),
				],
				[
					'name'       => __( 'Use External Image', 'kiranime' ),
					'type'       => 'input',
					'input_type' => 'checkbox',
					'value'      => get_option( '__kira_external_images', '' ),
					'key'        => '__kira_external_images',
					'info'       => __( 'Use external images instead of downloading them.', 'kiranime' ),
				],
			],
			'Queries' => [
				[
					'name'    => __( 'Episode list by', 'kiranime' ),
					'type'    => 'select',
					'value'   => get_option( '__q_episode_by', 'number' ),
					'key'     => '__q_episode_by',
					'options' => [
						'kiranime_episode_number'   => __( 'Episode numbers', 'kiranime' ),
						'kiranime_episode_released' => __( 'Release date', 'kiranime' ),
						'publish_date'              => __( 'Published Post Date', 'kiranime' ),
					],
					'info'    => __( 'Use meta or date for the list of episodes.', 'kiranime' ),
				],
				[
					'name'       => __( 'Episode Video Meta', 'kiranime' ),
					'type'       => 'input',
					'value'      => get_option( '__a_show_video_meta', 'number' ),
					'key'        => '__a_show_video_meta',
					'input_type' => 'checkbox',
					'info'       => __( 'Auto Generate Video Meta.', 'kiranime' ),
				],
				[
					'name'       => __( 'Show Completed badge', 'kiranime' ),
					'type'       => 'input',
					'input_type' => 'checkbox',
					'value'      => get_option( '__u_status_i_du', '' ),
					'key'        => '__u_status_i_du',
					'info'       => __( 'Show completed status as a badge.', 'kiranime' ),
				],
				[
					'name'       => __( 'Completed badge color', 'kiranime' ),
					'type'       => 'input',
					'input_type' => 'color',
					'value'      => get_option( '__u_status_bg', get_theme_mod( 'error-color', '#f43f5e' ) ),
					'key'        => '__u_status_bg',
					'info'       => __( 'Completed badge color background.', 'kiranime' ),
				],
				[
					'name'       => __( 'Completed Taxonomy Slug', 'kiranime' ),
					'type'       => 'input',
					'input_type' => 'text',
					'value'      => get_option( '__u_status_completed_slug', 'completed' ),
					'key'        => '__u_status_completed_slug',
					'info'       => __( 'Completed slug [Anime -> Status -> Term slug].', 'kiranime' ),
				],
			],
			'Sites'   => [
				[
					'name'       => __( 'Use ReCaptcha', 'kiranime' ),
					'type'       => 'input',
					'input_type' => 'checkbox',
					'value'      => get_option( '__use_recaptcha', '' ),
					'key'        => '__use_recaptcha',
					'info'       => __( 'Use ReCaptcha for important form.', 'kiranime' ),
				],
				[
					'name'       => __( 'ReCaptcha Secret Key (v2)', 'kiranime' ),
					'type'       => 'input',
					'input_type' => 'text',
					'value'      => get_option( 'kiranime_recaptcha_secretkey', '' ),
					'key'        => 'kiranime_recaptcha_secretkey',
					'info'       => __( 'Your ReCaptcha secret Key.', 'kiranime' ),
				],
				[
					'name'       => __( 'ReCaptcha Site Key (v2)', 'kiranime' ),
					'type'       => 'input',
					'input_type' => 'text',
					'value'      => get_option( 'kiranime_recaptcha_sitekey', '' ),
					'key'        => 'kiranime_recaptcha_sitekey',
					'info'       => __( 'Your ReCaptcha Site Key.', 'kiranime' ),
				],
				[
					'name'       => __( 'Use Lazy Load [image]', 'kiranime' ),
					'type'       => 'input',
					'input_type' => 'checkbox',
					'value'      => get_option( 'kira_use_lazy_load', '' ),
					'key'        => 'kira_use_lazy_load',
					'info'       => __( 'Load the image using built in lazy load module.', 'kiranime' ),
				],
				[
					'name'       => __( 'Use Title Switcher', 'kiranime' ),
					'type'       => 'input',
					'input_type' => 'checkbox',
					'value'      => get_option( '__q_title_switcher', '' ),
					'key'        => '__q_title_switcher',
					'info'       => __( 'Use Title switcher to switch between english [field: english] and romaji [field: post title] [default].', 'kiranime' ),
				],
				[
					'name'       => __( 'EN Label [title switcher]', 'kiranime' ),
					'type'       => 'input',
					'input_type' => 'text',
					'value'      => get_option( '__q_en_title_label', 'EN' ),
					'key'        => '__q_en_title_label',
					'info'       => __( 'EN Label Title switcher for english [the "english" meta field].', 'kiranime' ),
				],
				[
					'name'       => __( 'JP Lable [title switcher]', 'kiranime' ),
					'type'       => 'input',
					'input_type' => 'text',
					'value'      => get_option( '__q_jp_title_label', 'JP' ),
					'key'        => '__q_jp_title_label',
					'info'       => __( 'JP Label Title switcher for Romaji [the "post title" field].', 'kiranime' ),
				],
				[
					'name'       => __( 'Disable WP Login page', 'kiranime' ),
					'type'       => 'input',
					'input_type' => 'checkbox',
					'value'      => get_option( 'kira_disable_login_page', '' ),
					'key'        => 'kira_disable_login_page',
					'info'       => __( 'Disable the default wp-login.php page.', 'kiranime' ),
				],
				[
					'name'       => __( 'Watchlist Page Title', 'kiranime' ),
					'value'      => get_option( '__watchlist_title', '{{username}} Watchlist' ),
					'key'        => '__watchlist_title',
					'type'       => 'input',
					'input_type' => 'text',
					'info'       => __( 'The title for the watchlist page [browser tab, head title].', 'kiranime' ),
				],
				[
					'name'       => __( 'Watchlist Description', 'kiranime' ),
					'value'      => get_option( '__watchlist_description', '{{display_name}} public watchlist.' ),
					'key'        => '__watchlist_description',
					'type'       => 'input',
					'input_type' => 'text',
					'info'       => __( 'The description for the watchlist page [meta description].', 'kiranime' ),
				],
				[
					'name'       => __( 'Enable Custom Avatar', 'kiranime' ),
					'value'      => get_option( '__enable_custom_avatar', 'on' ),
					'key'        => '__enable_custom_avatar',
					'type'       => 'input',
					'input_type' => 'checkbox',
					'info'       => __( 'Let user upload their own avatar image.', 'kiranime' ),
				],
			],
			'Cache'   => [
				[
					'name'       => __( 'Use Built in Cache', 'kiranime' ),
					'type'       => 'input',
					'input_type' => 'checkbox',
					'value'      => get_option( '__kira_use_cache', '' ),
					'key'        => '__kira_use_cache',
					'info'       => __( 'Use the built in cache module.', 'kiranime' ),
				],
				[
					'name'    => __( 'Cache Driver', 'kiranime' ),
					'type'    => 'select',
					'value'   => get_option( '__kira_cache_driver', '' ),
					'key'     => '__kira_cache_driver',
					'options' => [
						'redis'     => [
							'name'    => __( 'Redis', 'kiranime' ),
							'enabled' => Kiranime_Cache::check_available( 'redis' ),
						],
						'memcached' => [
							'name'    => __( 'Memcached', 'kiranime' ),
							'enabled' => Kiranime_Cache::check_available( 'memcached' ),
						],
						'wordpress' => [
							'name'    => __( 'WordPress default [transient]', 'kiranime' ),
							'enabled' => true,
						],
					],
					'info'    => __( 'Select cache driver to use. Redis and Memcached will be selectable if your server supported.', 'kiranime' ),
				],
				[
					'depend'     => '__kira_cache_driver',
					'dependency' => 'redis',
					'name'       => __( 'Redis Host', 'kiranime' ),
					'type'       => 'input',
					'input_type' => 'text',

					'value'      => get_option( '__kira_redis_host', '127.0.0.1' ),
					'key'        => '__kira_redis_host',
				],
				[
					'depend'     => '__kira_cache_driver',
					'dependency' => 'redis',
					'name'       => __( 'Redis Port', 'kiranime' ),
					'type'       => 'input',
					'input_type' => 'text',
					'value'      => get_option( '__kira_redis_port', '6379' ),
					'key'        => '__kira_redis_port',
				],
				[
					'depend'     => '__kira_cache_driver',
					'dependency' => 'redis',
					'name'       => __( 'Redis Database', 'kiranime' ),
					'type'       => 'input',
					'input_type' => 'text',
					'info'       => __( 'Redis Database to use.', 'kiranime' ),
					'value'      => get_option( '__kira_redis_db', '0' ),
					'key'        => '__kira_redis_db',
				],
				[
					'depend'     => '__kira_cache_driver',
					'dependency' => 'redis',
					'name'       => __( 'Redis Username', 'kiranime' ),
					'type'       => 'input',
					'input_type' => 'text',

					'value'      => get_option( '__kira_redis_username', '' ),
					'key'        => '__kira_redis_username',
					'info'       => __( 'Fill only if your redis using username.', 'kiranime' ),
				],
				[
					'depend'     => '__kira_cache_driver',
					'dependency' => 'redis',
					'name'       => __( 'Redis Password', 'kiranime' ),
					'type'       => 'input',
					'input_type' => 'text',

					'value'      => get_option( '__kira_redis_password', '' ),
					'key'        => '__kira_redis_password',
					'info'       => __( 'Fill only if your redis using a password.', 'kiranime' ),
				],
				[
					'depend'     => '__kira_cache_driver',
					'dependency' => 'memcached',
					'name'       => __( 'Memcached Host', 'kiranime' ),
					'type'       => 'input',
					'input_type' => 'text',
					'value'      => get_option( '__kira_memcached_host', '127.0.0.1' ),
					'key'        => '__kira_memcached_host',
				],
				[
					'depend'     => '__kira_cache_driver',
					'dependency' => 'memcached',
					'name'       => __( 'Memcached port', 'kiranime' ),
					'type'       => 'input',
					'input_type' => 'text',
					'value'      => get_option( '__kira_memcached_port', '11211' ),
					'key'        => '__kira_memcached_port',
				],
				[
					'name'       => __( 'Cache Time', 'kiranime' ),
					'type'       => 'input',
					'input_type' => 'text',
					'value'      => get_option( '__kira_cache_time', '7200' ),
					'key'        => '__kira_cache_time',
					'info'       => __( 'How long the cache will be before expired in seconds.', 'kiranime' ),
				],
			],
			'Ads'     => [
				[
					'name'  => __( 'Head', 'kiranime' ),
					'type'  => 'textarea',
					'value' => get_option( '__ads_header', '' ),
					'key'   => '__ads_header',
					'info'  => __( 'Before closing head tag.', 'kiranime' ),
				],
				[
					'name'  => __( 'Footer', 'kiranime' ),
					'type'  => 'textarea',
					'value' => get_option( '__ads_footer', '' ),
					'key'   => '__ads_footer',
					'info'  => __( 'Before closing body tag.', 'kiranime' ),
				],
				[
					'name'  => __( 'After Trending', 'kiranime' ),
					'type'  => 'textarea',
					'value' => get_option( '__ads_after_trending', '' ),
					'key'   => '__ads_after_trending',
					'info'  => __( 'Ads After trending section.', 'kiranime' ),
				],
				[
					'name'  => __( 'After Featured', 'kiranime' ),
					'type'  => 'textarea',
					'value' => get_option( '__ads_after_featured', '' ),
					'key'   => '__ads_after_featured',
					'info'  => __( 'Ads after featured sections.', 'kiranime' ),
				],
				[
					'name'  => __( 'After Characters', 'kiranime' ),
					'type'  => 'textarea',
					'value' => get_option( '__ads_after_char_va', '' ),
					'key'   => '__ads_after_char_va',
					'info'  => __( 'Ads after Characters section [anime page].', 'kiranime' ),
				],
				[
					'name'  => __( 'After Episode Lists', 'kiranime' ),
					'type'  => 'textarea',
					'value' => get_option( '__ads_after_episode_lists', '' ),
					'key'   => '__ads_after_episode_lists',
					'info'  => __( 'Ads after episode slider [anime page].', 'kiranime' ),
				],
				[
					'name'  => __( 'Before Episode Body', 'kiranime' ),
					'type'  => 'textarea',
					'value' => get_option( '__ads_before_body_episode', '' ),
					'key'   => '__ads_before_body_episode',
					'info'  => __( 'Ads before episode body [episode page].', 'kiranime' ),
				],
				[
					'name'  => __( 'Replace Anime Content', 'kiranime' ),
					'type'  => 'textarea',
					'value' => get_option( '__ads_replace_content_episode', '' ),
					'key'   => '__ads_replace_content_episode',
					'info'  => __( 'Replace anime info content into an ad [episode page]. You may use responsive ads to avoid layout change when visited from mobile.', 'kiranime' ),
				],
			],
		];

		return Render::options( $main_options );
	}
	/**
	 * Handle the grabber rendering.
	 */
	public function render_grabber() {
		$grabber_options = [
			'Anime Info'       => 'kiranime_anime_grabber',
			'Episode Info'     => 'kiranime_episode_grabber',
			'Episode Importer' => 'kiranime_episode_importer',
		];

		echo Render::render_grabber( $grabber_options );
	}
	/**
	 * Array of tmdb languages.
	 */
	private function get_tmdb_language() {
		$languages = [
			'ab' => 'Abkhazian',
			'aa' => 'Afar',
			'af' => 'Afrikaans',
			'ak' => 'Akan',
			'sq' => 'Albanian',
			'am' => 'Amharic',
			'ar' => 'Arabic',
			'an' => 'Aragonese',
			'hy' => 'Armenian',
			'as' => 'Assamese',
			'av' => 'Avaric',
			'ae' => 'Avestan',
			'ay' => 'Aymara',
			'az' => 'Azerbaijani',
			'bm' => 'Bambara',
			'ba' => 'Bashkir',
			'eu' => 'Basque',
			'be' => 'Belarusian',
			'bn' => 'Bengali',
			'bi' => 'Bislama',
			'bs' => 'Bosnian',
			'br' => 'Breton',
			'bg' => 'Bulgarian',
			'my' => 'Burmese',
			'cn' => 'Cantonese',
			'ca' => 'Catalan',
			'ch' => 'Chamorro',
			'ce' => 'Chechen',
			'ny' => 'Chichewa; Nyanja',
			'cv' => 'Chuvash',
			'kw' => 'Cornish',
			'co' => 'Corsican',
			'cr' => 'Cree',
			'hr' => 'Croatian',
			'cs' => 'Czech',
			'da' => 'Danish',
			'dv' => 'Divehi',
			'nl' => 'Dutch',
			'dz' => 'Dzongkha',
			'en' => 'English',
			'eo' => 'Esperanto',
			'et' => 'Estonian',
			'ee' => 'Ewe',
			'fo' => 'Faroese',
			'fj' => 'Fijian',
			'fi' => 'Finnish',
			'fr' => 'French',
			'fy' => 'Frisian',
			'ff' => 'Fulah',
			'gd' => 'Gaelic',
			'gl' => 'Galician',
			'lg' => 'Ganda',
			'ka' => 'Georgian',
			'de' => 'German',
			'el' => 'Greek',
			'gn' => 'Guarani',
			'gu' => 'Gujarati',
			'ht' => 'Haitian; Haitian Creole',
			'ha' => 'Hausa',
			'he' => 'Hebrew',
			'hz' => 'Herero',
			'hi' => 'Hindi',
			'ho' => 'Hiri Motu',
			'hu' => 'Hungarian',
			'is' => 'Icelandic',
			'io' => 'Ido',
			'ig' => 'Igbo',
			'id' => 'Indonesian',
			'ia' => 'Interlingua',
			'ie' => 'Interlingue',
			'iu' => 'Inuktitut',
			'ik' => 'Inupiaq',
			'ga' => 'Irish',
			'it' => 'Italian',
			'ja' => 'Japanese',
			'jv' => 'Javanese',
			'kl' => 'Kalaallisut',
			'kn' => 'Kannada',
			'kr' => 'Kanuri',
			'ks' => 'Kashmiri',
			'kk' => 'Kazakh',
			'km' => 'Khmer',
			'ki' => 'Kikuyu',
			'rw' => 'Kinyarwanda',
			'ky' => 'Kirghiz',
			'kv' => 'Komi',
			'kg' => 'Kongo',
			'ko' => 'Korean',
			'kj' => 'Kuanyama',
			'ku' => 'Kurdish',
			'lo' => 'Lao',
			'la' => 'Latin',
			'lv' => 'Latvian',
			'lb' => 'Letzeburgesch',
			'li' => 'Limburgish',
			'ln' => 'Lingala',
			'lt' => 'Lithuanian',
			'lu' => 'Luba-Katanga',
			'mk' => 'Macedonian',
			'mg' => 'Malagasy',
			'ms' => 'Malay',
			'ml' => 'Malayalam',
			'mt' => 'Maltese',
			'zh' => 'Mandarin',
			'gv' => 'Manx',
			'mi' => 'Maori',
			'mr' => 'Marathi',
			'mh' => 'Marshall',
			'mo' => 'Moldavian',
			'mn' => 'Mongolian',
			'na' => 'Nauru',
			'nv' => 'Navajo',
			'nr' => 'Ndebele',
			'nd' => 'Ndebele',
			'ng' => 'Ndonga',
			'ne' => 'Nepali',
			'xx' => 'No Language',
			'se' => 'Northern Sami',
			'no' => 'Norwegian',
			'nb' => 'Norwegian Bokmål',
			'nn' => 'Norwegian Nynorsk',
			'oc' => 'Occitan',
			'oj' => 'Ojibwa',
			'or' => 'Oriya',
			'om' => 'Oromo',
			'os' => 'Ossetian; Ossetic',
			'pi' => 'Pali',
			'fa' => 'Persian',
			'pl' => 'Polish',
			'pt' => 'Portuguese',
			'pa' => 'Punjabi',
			'ps' => 'Pushto',
			'qu' => 'Quechua',
			'rm' => 'Raeto-Romance',
			'ro' => 'Romanian',
			'rn' => 'Rundi',
			'ru' => 'Russian',
			'sm' => 'Samoan',
			'sg' => 'Sango',
			'sa' => 'Sanskrit',
			'sc' => 'Sardinian',
			'sr' => 'Serbian',
			'sh' => 'Serbo-Croatian',
			'sn' => 'Shona',
			'sd' => 'Sindhi',
			'si' => 'Sinhalese',
			'cu' => 'Slavic',
			'sk' => 'Slovak',
			'sl' => 'Slovenian',
			'so' => 'Somali',
			'st' => 'Sotho',
			'es' => 'Spanish',
			'su' => 'Sundanese',
			'sw' => 'Swahili',
			'ss' => 'Swati',
			'sv' => 'Swedish',
			'tl' => 'Tagalog',
			'ty' => 'Tahitian',
			'tg' => 'Tajik',
			'ta' => 'Tamil',
			'tt' => 'Tatar',
			'te' => 'Telugu',
			'th' => 'Thai',
			'bo' => 'Tibetan',
			'ti' => 'Tigrinya',
			'to' => 'Tonga',
			'ts' => 'Tsonga',
			'tn' => 'Tswana',
			'tr' => 'Turkish',
			'tk' => 'Turkmen',
			'tw' => 'Twi',
			'ug' => 'Uighur',
			'uk' => 'Ukrainian',
			'ur' => 'Urdu',
			'uz' => 'Uzbek',
			've' => 'Venda',
			'vi' => 'Vietnamese',
			'vo' => 'Volapük',
			'wa' => 'Walloon',
			'cy' => 'Welsh',
			'wo' => 'Wolof',
			'xh' => 'Xhosa',
			'ii' => 'Yi',
			'yi' => 'Yiddish',
			'yo' => 'Yoruba',
			'za' => 'Zhuang',
			'zu' => 'Zulu',
		];
		return $languages;
	}
	/**
	 * Handle the Reports page rendering.
	 */
	public function reports() {
		$reports     = new WP_Query(
			[
				'post_type'      => 'reported',
				'posts_per_page' => 20,
				'order'          => 'desc',
				'orderby'        => 'date',
			]
		);
		$report_data = [];
		foreach ( $reports->posts as $post ) {
			$report_data[] = [
				'post'  => $post,
				'value' => get_post_meta( $post->ID, 'reported_value', true ),
				'link'  => get_post_meta( $post->ID, 'reported_episode', true ),
			];
		}
		?>
		<script>
			var reports = <?php echo json_encode( $report_data ); ?>;
			var total = <?php echo $reports->post_count; ?>;
			var pages = <?php echo $reports->max_num_pages; ?>;
		</script>
		<div id="episode-reports"></div>
		<?php
	}
}
