<?php

/**
 * This is class for user watchlists
 *
 * @package   Kiranime
 * @since   2.0.0
 * @link      https://kiranime.moe
 * @author    Dzul Qurnain
 * @license   GPL-2.0+
 */
class Kiranime_Watchlist {


	/**
	 * Array of watchlist for current user
	 *
	 * @var array $watchlists
	 */
	public array $watchlists = [];

	/**
	 * Kira_User_Watchlist constructor.
	 *
	 * @param string|int $user_id The user ID.
	 */
	public function __construct( private string|int $user_id ) {
		$this->get();
	}

	/**
	 * Retrieves the watchlist type name based on the provided type.
	 *
	 * @param string|null $type The type of watchlist. If not provided, returns an array of all watchlist types.
	 *
	 * @return string|array The name of the watchlist type if the type is provided, or an array of all watchlist types if no type is provided.
	 */
	public static function types( string $type = null ) {
		$types = [
			'plan_to_watch' => __( 'Plan to Watch', 'kiranime' ),
			'watching'      => __( 'Watching', 'kiranime' ),
			'completed'     => __( 'Completed', 'kiranime' ),
			'on_hold'       => __( 'On Hold', 'kiranime' ),
			'dropped'       => __( 'Dropped', 'kiranime' ),
			'remove'        => __( 'Remove', 'kiranime' ),
		];

		if ( $type ) {
			return $types[ $type ];
		}

		return $types;
	}

	/**
	 * Retrieves static types in a structured format.
	 *
	 * This function iterates through the static types defined in the class and constructs an array
	 * containing the key and name of each type.
	 *
	 * @return array An array of associative arrays, where each array represents a static type.
	 *               Each associative array contains the 'key' and 'name' of the type.
	 */
	public static function get_static_types() {
		$result = [];
		foreach ( self::types() as $key => $name ) {
			$result[] = [
				'key'  => $key,
				'name' => $name,
			];
		}

		return $result;
	}

	/**
	 * Saves the user's watchlist data to the database.
	 *
	 * @return bool True if the data was successfully saved, false otherwise.
	 */
	public function save() {
		return update_user_meta( $this->user_id, 'watchlist_data', $this->watchlists );
	}

	/**
	 * Saves the user's ID to the subscribers list of the specified anime.
	 *
	 * @param string|int $anime_id The ID of the anime to save the user's ID for.
	 * @param bool       $delete Whether to delete the user's ID from the subscribers list. Default is false.
	 *
	 * @return self The current instance for method chaining.
	 */
	public function save_users( string|int $anime_id, bool $delete = false ): self {
		$current_value = get_post_meta( $anime_id, 'subscribers_data', true );
		if ( ! $current_value ) {
			$current_value = [];
		}
		$current_value = is_string( $current_value ) ? json_decode( $current_value ) : $current_value;

		if ( $delete && in_array( $this->user_id, $current_value ) ) {
			$current_value = array_filter( $current_value, fn ( $e ) => $e !== $this->user_id );
		} else {
			$current_value[] = $this->user_id;
		}
		update_post_meta( $anime_id, 'subscribers_data', $current_value );
		return $this;
	}

	/**
	 * Adds or subtracts the bookmark count for a specific anime.
	 *
	 * @param string|int $anime_id The ID of the anime.
	 * @param int        $type     The type of operation (1 for adding, -1 for subtracting). Default is 1.
	 *
	 * @return self The current instance for method chaining.
	 */
	public function add_subs_count( string|int $anime_id, $type = 1 ) {
		$bookmark_count = intval( get_post_meta( $anime_id, 'bookmark_count', true ) );
		$bookmark_count = $bookmark_count + $type;
		$bookmark_count = $bookmark_count > 0 ? $bookmark_count : 0;
		update_post_meta( $anime_id, 'bookmark_count', $bookmark_count );
		return $this;
	}

	/**
	 * Removes an anime from the user's watchlist.
	 *
	 * @param string|int          $anime_id The ID of the anime to be removed.
	 * @param WatchlistType|false $type The type of watchlist from which to remove the anime.
	 *
	 * @return array An array containing a message and a status indicating whether the removal was successful.
	 */
	public function remove( string|int $anime_id, WatchlistType|false $type ) {
		$result = true;
		if ( $type ) {
			$result = $this->remove_by_type( $type->value, intval( $anime_id ) )->add_subs_count( intval( $anime_id ), -1 )->save();
		} else {
			$this->watchlists = array_map( fn ( $val ) => array_filter( $val, fn ( $v ) => intval( $v ) !== intval( $anime_id ) ), $this->watchlists );
			$result           = $this->add_subs_count( intval( $anime_id ), -1 )->save_users( intval( $anime_id ), true )->save();
		}
		return [
			'message' => __( 'Anime removed from watchlist.', 'kiranime' ),
			'status'  => false !== $result,
		];
	}

	/**
	 * Sets the watchlist array for a specific type.
	 *
	 * @param string|int          $anime_id The ID of the anime to be added to the watchlist.
	 * @param WatchlistType|false $type The type of watchlist (e.g., 'plan_to_watch', 'watching', 'on_hold', 'completed', 'dropped').
	 *
	 * @return string|self The message indicating the result of adding the anime to the watchlist, or the current instance for method chaining.
	 */
	public function set( string|int $anime_id, WatchlistType|false $type ) {
		if ( ! $type ) {
			return __( 'Invalid watchlist type!', 'kiranime' );
		}

		$current_value = $this->get_by_type( $type->value );

		if ( in_array( $anime_id, $current_value ) ) {
			return __( 'Already added!', 'kiranime' );
		}

		$duplicate = $this->is_duplicate( $anime_id );
		if ( $duplicate ) {
			$this->remove_by_type( $duplicate, $anime_id );
		}

		array_unshift( $current_value, $anime_id );
		$this
		->set_by_type( $type->value, $current_value )
		->add_subs_count( $anime_id, $duplicate ? 0 : 1 )
		->clear_cache( $duplicate ? [ $duplicate, $type->value ] : $type->value )
		->save_users( $anime_id )
		->save();

		return $duplicate ?
		/* translators: watchlist name (watching, ...etc) */
		sprintf( esc_html__( 'Anime has been moved to %1$s', 'kiranime' ), $this->types( $type->value ) )
		: __( 'Anime added to watch list!', 'kiranime' );
	}

	/**
	 * Checks if the provided anime ID is already present in the user's watchlist.
	 *
	 * @param string|int $anime_id The ID of the anime to check for duplicates.
	 *
	 * @return string|false The watchlist type where the duplicate anime is found, or false if no duplicates are found.
	 */
	public function is_duplicate( string|int $anime_id ) {
		foreach ( $this->watchlists as $watchlist => $value ) {
			$found = array_search( $anime_id, $value, true );
			if ( false !== $found ) {
				return $watchlist;
			}
		}

		return false;
	}

	/**
	 * Sets the watchlist array for a specific type.
	 *
	 * @param string $type The type of watchlist (e.g., 'plan_to_watch', 'watching', 'on_hold', 'completed', 'dropped').
	 * @param array  $value The array of anime IDs to be set for the specified watchlist type.
	 *
	 * @return self The current instance for method chaining.
	 */
	public function set_by_type( string $type, array $value ): self {
		$this->watchlists[ $type ] = $value;
		return $this;
	}

	/**
	 * Retrieves an array of anime IDs for a specific watchlist type.
	 *
	 * @param string $type The type of watchlist (e.g., 'plan_to_watch', 'watching', 'on_hold', 'completed', 'dropped').
	 *
	 * @return array An array of anime IDs for the specified watchlist type. If the watchlist type does not exist, an empty array is returned.
	 */
	public function get_by_type( string $type ): array {
		if ( isset( $this->watchlists[ $type ] ) ) {
			return $this->watchlists[ $type ];
		}
		return [];
	}

	/**
	 * Removes an anime ID from the watchlist array for a specific type.
	 *
	 * @param string     $type The type of watchlist (e.g., 'plan_to_watch', 'watching', 'on_hold', 'completed', 'dropped').
	 * @param string|int $anime_id The ID of the anime to be removed from the watchlist.
	 *
	 * @return self The current instance for method chaining.
	 */
	public function remove_by_type( string $type, string|int $anime_id ) {
		$this->watchlists[ $type ] = array_filter( $this->watchlists[ $type ], fn ( $val ) => $val !== $anime_id );
		return $this;
	}

	/**
	 * Retrieves and sets the user's watchlist data.
	 *
	 * @return self The current instance for method chaining.
	 */
	public function get() {
		$wl = get_user_meta( $this->user_id, 'watchlist_data', true );

		$this->watchlists = $wl ? ( is_string( $wl ) ? json_decode( $wl, true ) : $wl ) : [];
		return $this;
	}

	/**
	 * Retrieves anime data based on the provided watchlist type, page, and per page.
	 *
	 * @param WatchlistType|false $type The watchlist type to filter anime data.
	 * @param string|int          $page The page number to retrieve anime data. Default is 1.
	 * @param string|int          $per_page The number of anime data to retrieve per page. Default is 20.
	 *
	 * @return Anime[] An array containing anime data and pagination information.
	 */
	public function get_anime( WatchlistType|false $type, string|int $page = 1, string|int $per_page = 20 ): array {
		$ids = [];

		if ( ! $type ) {
			foreach ( $this->watchlists as $wl => $value ) {
				$ids = [ ...$ids, ...$value ];
			}
		} else {
			$ids = $this->get_by_type( $type->value );
		}

		if ( empty( $ids ) ) {
			return [];
		}

		$animes = [];

		$chunks = array_chunk( $ids, $per_page );

		$use = $chunks[ $page - 1 ];

		if ( ! $use ) {
			return [];
		}

		$max_pages   = round( ceil( count( $ids ) / $per_page ) );
		$lang_switch = get_option( '__q_title_switcher', false );
		foreach ( $use as $id ) {
			$anime = new Anime( $id );
			$anime
				->get_featured( KiraType::anime )
				->gets( MetaPrefix::anime )
				->get_taxonomies( 'anime_attribute', 'status', 'type' )
				->get_episodes( true, -1 );

			$episode = ! empty( $anime->episodes ) ? $anime->episodes[0] : null;

			$animes[] = [
				'meta'       => $anime->meta,
				'episodes'   => $episode?->meta['number'],
				'taxonomies' => array_map(
					fn ( $val ) => array_shift(
						array_map(
							fn ( $v ) => [
								'name' => $v->name,
								'slug' => $v->slug,
							],
							$val
						)
					),
					$anime->taxonomies
				),
				'images'     => $anime->images,
				'url'        => $anime->url,
				'anime_id'   => $anime->id,
				'post'       => [
					'post_title' => $anime->post->post_title,
				],
				'ls'         => $lang_switch,
			];
		}

		$result = [
			'animes' => $animes,
			'pages'  => $max_pages,
		];

		return $result;
	}

	/**
	 * Retrieves the user IDs who have subscribed to a specific anime.
	 *
	 * @param string|int $anime_id The ID of the anime for which to retrieve subscribers.
	 *
	 * @return array An array of user IDs who have subscribed to the anime. If no users have subscribed, an empty array is returned.
	 */
	public static function get_users( string|int $anime_id ) {
		$ids = get_post_meta( $anime_id, 'subscribers_data', true );
		if ( empty( $ids ) ) {
			return [];
		}
		return is_string( $ids ) ? json_decode( $ids ) : $ids;
	}

	/**
	 * Clears the cache for the user's watchlist data.
	 *
	 * @param string|array $type The watchlist type to clear cache for. If not provided, clears cache for all types.
	 *
	 * @return self The current instance for method chaining.
	 */
	public function clear_cache( string|array $type = null ) {

		if ( is_array( $type ) ) {
			foreach ( $type as $k ) {
				$key   = 'watchlist_data_' . $this->user_id . '_' . $k;
				$cache = new Kiranime_Cache( $key );
				$cache->delete( '' );
			}

			return $this;
		}
		$key   = $type ? 'watchlist_data_' . $this->user_id . '_' . $type : 'watchlist_data_' . $this->user_id;
		$cache = new Kiranime_Cache( $key );

		$cache->delete( '' );
		return $this;
	}

	/**
	 * Migrates user watchlist data from old bookmark meta to new watchlist data.
	 *
	 * @param int $page The page number to retrieve anime data. Default is 1.
	 *
	 * @return array An array containing the status and maximum number of pages.
	 */
	public static function migrate_watchlist( $page = 1 ) {
		$types = [ 'plan_to_watch', 'watching', 'on_hold', 'completed', 'dropped' ];

		$posts = new WP_Query(
			[
				'post_type'      => 'anime',
				'posts_per_page' => 10,
				'paged'          => $page,
			]
		);

		foreach ( $posts->posts as $post ) {

			delete_post_meta( $post->ID, 'bookmark_count' );

			foreach ( $types as $type ) {
				$user_subs = get_post_meta( $post->ID, 'bookmark_' . $type . '_by', false );
				if ( $user_subs ) {
					foreach ( $user_subs as $uid ) {
						$wl = new self( $uid );
						$wl->set( $post->ID, WatchlistType::fromName( $type ) );
					}
				}

				delete_post_meta( $post->ID, 'bookmark_' . $type . '_by' );
			}
		}

		if ( $page === $posts->max_num_pages ) {
			update_option( 'kiranime_watchlist_migrated', 1 );
		}

		return [
			'status'    => true,
			'max_pages' => $posts->max_num_pages,
		];
	}

	/**
	 * Sets and displays the title and description meta tags for a user's watchlist.
	 *
	 * This function checks for SEO plugins like Rank Math, YOAST SEO, and All in One SEO Pack.
	 * If any of these plugins are active, it sets the title and description meta tags accordingly.
	 * If none of these plugins are active, it uses the default wp_head hook to set the title and description meta tags.
	 *
	 * @param WP_User|false $user The user object for whom the title and description meta tags are being set.
	 *
	 * @return bool Returns true if the title and description meta tags are successfully set, false otherwise.
	 */
	public static function metadata( WP_User|false $user ) {
		include_once ABSPATH . 'wp-admin/includes/plugin.php';

		/* translators: Username */
		$title       = get_option( '__watchlist_title', wp_sprintf( __( '%1$s Watchlist', 'kiranime' ), ucfirst( $user->display_name ) ) );
		$title       = str_ireplace( [ '{{display_name}}', '{{username}}' ], [ $user->display_name, $user->user_login ], $title );
		$description = get_option( '__watchlist_description', '{{display_name}} public watchlist.' );
		$description = str_ireplace( [ '{{display_name}}', '{{username}}' ], [ $user->display_name, $user->user_login ], $description );

		/**
		 * Use Rank Math hook to display the title and description meta if available
		 */
		if ( is_plugin_active( 'seo-by-rank-math/rank-math.php' ) ) {
			add_filter( 'rank_math/frontend/title', fn () => $title . ' | ' . get_bloginfo( 'sitename' ) );
			add_filter( 'rank_math/frontend/description', fn () => $description );

			return true;
		}

		/**
		 * Use YOAST SEO hook to display the title and description meta if available
		 */
		if ( is_plugin_active( 'wordpress-seo/wp-seo.php' ) ) {
			add_filter( 'wpseo_title', fn () => $title . ' | ' . get_bloginfo( 'sitename' ) );
			add_filter( 'wpseo_metadesc', fn () => $description );

			return true;
		}

		/**
		 * Use AIOSEO hook to display the title and description meta if available
		 */
		if ( is_plugin_active( 'all-in-one-seo-pack/all_in_one_seo_pack.php' ) ) {
			add_filter( 'aioseo_title', fn () => $title . ' | ' . get_bloginfo( 'sitename' ) );
			add_filter( 'aioseo_description', fn () => $description );
			return true;
		}

		/**
		 * Use default wp_head hook to display the title and description meta
		 */
		remove_action( 'wp_head', '_wp_render_title_tag', 1 );
		add_filter(
			'wp_head',
			function () use ( $title ) {
				echo '<title>' . $title . ' </title>';
			}
		);
		add_filter(
			'wp_head',
			function () use ( $description ) {
				echo "<meta name='description' content='$description' />";
			}
		);
	}

	/**
	 * Retrieves the URL for a user's watchlist.
	 *
	 * @param int|string $user_id The ID or login name of the user. Default is 0.
	 *
	 * @return string The URL for the user's watchlist. If the user ID is not provided or the watchlist URL cannot be generated, an empty string is returned.
	 */
	public static function get_watchlist_url( int|string $user_id = 0 ) {
		if ( ! $user_id ) {
			return '';
		}
		$cache  = new Kiranime_Cache( 'get_watchlist_url' );
		$cached = $cache->get( $user_id );

		if ( $cached ) {
			return $cached;
		}

		$watchlist_url = Kira_Utility::page_link( 'pages/watchlist.php' );
		if ( ! $watchlist_url ) {
			return '';
		}

		$user   = get_userdata( $user_id );
		$result = $watchlist_url . $user->user_login . '/';
		$cache->set( $user_id, $result, DAY_IN_SECONDS );
		return $result;
	}
}
