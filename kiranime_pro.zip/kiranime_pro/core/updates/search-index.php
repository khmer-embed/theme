<?php

/**
 * Kiranime re-index handler
 *
 * @package   Kiranime
 * @since     1.0.0
 * @link      https://kiranime.moe
 * @author    Dzul Qurnain
 */
class Kiranime_Search_Index {

	/**
	 * Posts that need to be re-indexed
	 *
	 * @var WP_Post[]
	 */
	public array $posts = [];

	/**
	 * Search index constructor
	 */
	public function __construct() {
	}

	/**
	 * Starts the indexing process for all anime posts.
	 *
	 * This function retrieves all anime posts (including drafts, published, and future) and stores their IDs.
	 * It then iterates over all pages of results to ensure all posts are included.
	 *
	 * @return array An associative array containing the following keys:
	 *  - 'ids': An array of post IDs.
	 *  - 'total': The total number of posts retrieved.
	 */
	public function start_indexing() {
		$args = [
			'post_type'      => 'anime',
			'post_status'    => [ 'draft', 'publish', 'future' ],
			'posts_per_page' => 100,
			'order'          => 'ASC',
			'orderby'        => 'date',
			'fields'         => 'ids',
		];

		$first_query = new WP_Query( $args );

		$max_pages    = $first_query->max_num_pages;
		$current_page = 1;
		$this->posts  = array_merge( $this->posts, $first_query->posts );

		while ( $current_page <= $max_pages ) {
			++$current_page;
			$args['paged'] = $current_page;

			$query       = new WP_Query( $args );
			$max_pages   = $query->max_num_pages;
			$this->posts = array_merge( $this->posts, $query->posts );
		}

		return [
			'ids'   => $this->posts,
			'total' => $first_query->post_count,
		];
	}
	/**
	 * Builds the search index for a specific anime post.
	 *
	 * This function retrieves the anime post with the given ID, sets the search index for the post,
	 * and returns the search index data.
	 *
	 * @param int $id The ID of the anime post. Default is 0.
	 *
	 * @return mixed|bool The search index data if the post is found and the index is set successfully,
	 *                    or false if the post ID is not provided.
	 */
	public function build_search_index( $id = 0 ) {
		if ( ! $id ) {
			return false;
		}

		$anime = new Anime( $id );
		$anime->set_index( MetaPrefix::anime );
		return $anime->meta['search_index'];
	}
}
