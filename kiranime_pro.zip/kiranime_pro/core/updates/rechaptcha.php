<?php

/**
 * Kiranime recaptcha handler
 *
 * @package   Kiranime
 * @since     1.0.0
 * @link      https://kiranime.moe
 * @author    Dzul Qurnain
 */
class Kiranime_Recaptcha {

	/**
	 * Whether the reCAPTCHA response is valid.
	 *
	 * @var bool
	 */
	public bool $is_valid = false;

	/**
	 * The captcha session.
	 *
	 * @var mixed $session
	 */
	private mixed $session = null;

	/**
	 * The reCAPTCHA site key.
	 *
	 * @var string|null $site_key
	 */
	public string|null $site_key = null;

	/**
	 * The reCAPTCHA secret key.
	 *
	 * @var string|null $secret_key
	 */
	private string|null $secret_key = null;

	/**
	 * The visitors api.
	 *
	 * @var mixed $ip
	 */
	private mixed $ip = null;

	/**
	 * The result message.
	 *
	 * @var string|null $message
	 */
	public string|null $message = null;

	/**
	 * The reCAPTCHA response.
	 *
	 * @var mixed
	 */
	public mixed $google_response = null;

	/**
	 * Constructor for Kiranime_Recaptcha class.
	 *
	 * @param string $session The session string.
	 * @param string $ip      The user's IP address.
	 *
	 * @throws Exception If session string is not provided.
	 */
	public function __construct( $session = null, $ip = null ) {
		if ( ! $session ) {
			throw new Exception( 'Session string required', 1 );
		}

		$this->ip      = $ip;
		$this->session = $session;
		$this->init();
	}

	/**
	 * Initializes the reCAPTCHA site and secret keys.
	 *
	 * This function retrieves the reCAPTCHA site and secret keys from the WordPress options.
	 * If the keys are not found, it defaults to false.
	 *
	 * @return void
	 */
	private function init() {
		$this->site_key   = get_option( 'kiranime_recaptcha_sitekey', false );
		$this->secret_key = get_option( 'kiranime_recaptcha_secretkey', false );
	}

	/**
	 * Validates the reCAPTCHA session.
	 *
	 * This function sends a request to the Google reCAPTCHA API to verify the user's response.
	 * It retrieves the response from the API, checks the response status, and updates the
	 * internal properties accordingly.
	 *
	 * @return Kiranime_Recaptcha The current instance of the class.
	 */
	public function validate_session() {
		$captcha_response = wp_remote_get( 'https://www.google.com/recaptcha/api/siteverify?secret=' . $this->secret_key . '&response=' . $this->session . '&remoteip=' . $this->ip );

		if ( is_wp_error( $captcha_response ) ) {
			$this->message  = $captcha_response->get_error_message();
			$this->is_valid = false;
			return $this;
		}

		$status = wp_remote_retrieve_response_code( $captcha_response );

		if ( $status >= 400 ) {
			$this->message  = __( 'Invalid response, please try again.', 'kiranime' );
			$this->is_valid = false;
			return $this;
		}

		$response = wp_remote_retrieve_body( $captcha_response );

		$this->google_response = json_decode( $response, true );
		if ( $this->google_response && $this->google_response['success'] ) {
			$this->is_valid = true;
			$this->message  = __( 'Allowed to continue.', 'kiranime' );
		} else {
			$this->is_valid = false;
			$this->message  = __( 'Invalid response, please try again.', 'kiranime' );
		}
	}
}
