<?php

add_action( 'kiranime_show_ads', 'kiranime_show_ads', 10, 2 );
function kiranime_show_ads( $location = null, $stricted = false ) {
	$ad    = '';
	$empty = true;

	if ( ! $stricted ) {
		$ad = "<div class='w-full'>";
	}

	if ( $location ) {
		$val = get_option( $location );
		if ( $val ) {
			$empty = false;
			$ad    = str_ireplace( "class='", "class='plb-2 sm:plb-5 ", $ad );
			$ad   .= $val;
		}
	}

	if ( ! $stricted ) {
		$ad .= '</div>';
	}

	echo $empty ? '' : $ad;
}
