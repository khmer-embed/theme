<?php

require_once KIRA_THEME_DIR . '/vendor/autoload.php';


class Kiranime_Cache {

	public bool $enabled                                 = false;
	public static string $prefix                         = 'kira_cache_';
	private string $global_prefix                        = '';
	public string $driver                                = '';
	public Memcached|Predis\Client|null $driver_instance = null;

	public function __construct( public string $group ) {
		try {
			$this->enabled = boolval( get_option( '__kira_use_cache', '' ) );

			if ( $this->enabled ) {
				$this->driver = get_option( '__kira_cache_driver', 'wp_cache' );

				$this->global_prefix = md5( get_bloginfo( 'url' ) );

				if ( empty( $GLOBALS[ 'kiranime_cache_driver_' . $this->global_prefix ] ) ) {

					$this->driver_instance = match ( $this->driver ) {
						'redis' => $this->get_redis_driver(),
						'memcached' => $this->get_memcached_driver(),
						default    => null,
					};
				} else {
					$this->driver_instance = $GLOBALS[ 'kiranime_cache_driver_' . $this->global_prefix ];
				}
			}
		} catch ( \Throwable $e ) {
			write_log( $e->getMessage(), 'Kiranime cache' );
		}
	}

	/**
	 * Creates a new Redis client and connects to the specified Redis server.
	 *
	 * This function attempts to establish a connection to a Redis server using the provided configuration options.
	 * If the connection is successful and the server responds with a PING command, the function returns the Redis client instance.
	 * If any error occurs during the connection process, the function returns null.
	 *
	 * @return Predis\Client|null The Redis client instance if the connection is successful, null otherwise.
	 */
	private function get_redis_driver(): Predis\Client|null {
		try {
			$redis = new Predis\Client(
				[
					'scheme'   => 'tcp',
					'host'     => get_option( '__kira_redis_host', '127.0.0.1' ),
					'port'     => (int) get_option( '__kira_redis_port', 6379 ),
					'database' => (int) get_option( '__kira_redis_db', 0 ),
					'password' => get_option( '__kira_redis_password', '' ),
					'username' => get_option( '__kira_redis_username', '' ),
				]
			);

			if ( 'pong' !== $redis->ping( 'pong' ) ) {
				return null;
			}

			return $redis;
		} catch ( \Throwable $e ) {
			return null;
		}
	}


	private function get_memcached_driver(): Memcached|null {
		try {
			if ( class_exists( 'Memcached' ) ) {
				$memcached = new Memcached();
				$memcached->addServer( get_option( '_kira_memcached_host', '127.0.0.1' ), (int) get_option( '_kira_memcached_port', 11211 ) );

				if ( empty( $memcached->getStats() ) ) {
					return null;
				}

				return $memcached;
			}

			return null;
		} catch ( \Throwable $e ) {
			return null;
		}
	}

	private function get_key( string $key ): string {
		return $this->global_prefix . '_' . $this->group . md5( $key );
	}

	public function set( string $key, mixed $value, int|string $expires = 3600 ): bool {
		if ( ! $this->enabled || is_null( $value ) ) {
			return false;
		}

		$to_store = match ( gettype( $value ) ) {
			'array', 'object' => json_encode( $value, JSON_UNESCAPED_UNICODE ),
			default => $value,
		};

		try {
			$cache_key = $this->get_key( $key );
			if ( $this->driver_instance ) {
				return match ( $this->driver ) {
					'redis'=> 'OK' === $this->driver_instance?->SET(
						$cache_key,
						$to_store,
						'EX',
						$expires
					)->getPayload(),
					'memcached' => ! empty( $this->driver_instance?->set( $cache_key, $to_store, $expires ) ),
					default => set_transient( $cache_key, $to_store, intval( $expires ) )
				};
			}

			set_transient( $this->group . $this->group . $cache_key, $to_store, intval( $expires ) );
			return true;
		} catch ( \Throwable $e ) {
			return false;
		}
	}

	public function get( string $key ): mixed {
		if ( ! $this->enabled ) {
			return false;
		}

		try {
			if ( ! $this->enabled ) {
				return null;
			}

			$cache_key = $this->get_key( $key );

			$result = null;
			if ( $this->driver && $this->driver_instance ) {
				$result = $this->driver_instance?->get( $cache_key );
			} else {
				$result = get_transient( $cache_key );
			}

			if ( 'null' === $result ) {
				return null;
			}

			return $result;
		} catch ( \Throwable $e ) {
			return null;
		}
	}

	public function delete( string $key = '' ): bool {
		try {
			if ( ! $this->enabled ) {
				return false;
			}

			$cache_key = $this->get_key( $key );

			if ( $this->driver && $this->driver_instance ) {
				return 'redis' === $this->driver ? (bool) $this->driver_instance?->del( $cache_key ) : $this->driver_instance?->delete( $cache_key );
			}

			return delete_transient( $cache_key );
		} catch ( \Throwable $e ) {
			return false;
		}
	}

	public function deleteGroup( array $keys ): bool {
		foreach ( $keys as $key ) {
			$this->delete( $key );
		}

		return true;
	}

	public function clear_all_cache( string|null $pattern = null ) {
		if ( ! $this->enabled ) {
			return false;
		}

		try {
			return match ( $this->driver ) {
				'redis' => $this->clear_redis_cache( $pattern ),
				'memcached'=> $this->clear_memcached_cache( $pattern ),
				default => $this->clear_wp_transient( $pattern )
			};
		} catch ( \Throwable $e ) {
			return false;
		}
	}

	private function clear_redis_cache( string|null $pattern = null ): bool {
		$reg = $pattern ?? "{$this->global_prefix}*";

		$cursor     = null;
		$chunk_size = 1000;

		while ( 0 !== $cursor ) {
			$iterator = $this->driver_instance->scan(
				$cursor,
				[
					'match' => $reg,
					'count' => $chunk_size,
				]
			);

			$keys   = $iterator[1];
			$cursor = $iterator[0];

			if ( ! empty( $keys ) ) {
				foreach ( $keys as $key ) {
					$this->driver_instance->del( $key );
				}
			}

			if ( empty( $cursor ) ) {
				break;
			}
		}

		return true;
	}

		/**
		 * Clears all cache entries from the Memcached cache.
		 * This function retrieves all keys from the Memcached instance, filters them based on the current group's prefix,
		 * and then deletes each matching key from the cache.
		 *
		 * @param string|null $pattern The pattern to search for keys.
		 *
		 * @return bool True if the cache was successfully cleared, false otherwise.
		 */
	private function clear_memcached_cache( string|null $pattern = null ): bool {
		$keys  = $this->driver_instance?->getAllKeys();
		$regex = $pattern ?? "{$this->global_prefix}.*";
		foreach ( $keys as $item ) {
			if ( preg_match( '/' . $regex . '/', $item ) ) {
				$this->driver_instance?->delete( $item );
			}
		}

		return true;
	}

		/**
		 * Clears WordPress transients cache for the current group.
		 *
		 * This function deletes all WordPress transients cache entries for the current group.
		 * If a pattern is provided, it will only delete the cache entries that match the pattern.
		 *
		 * @param string|null $pattern The pattern to search for keys. If null, it will use the default pattern.
		 *
		 * @return bool True if the cache was successfully cleared, false otherwise.
		 */
	private function clear_wp_transient( string|null $pattern = null ) {
		$keys = $pattern ?? "{$this->global_prefix}";
		global $wpdb;

		$result = $wpdb->query(
			$wpdb->prepare(
				"DELETE FROM $wpdb->options WHERE $wpdb->options.`option_name` RLIKE %s",
				$keys
			)
		);
		return false !== $result;
	}

		/**
		 * Checks if the specified cache driver is available.
		 *
		 * This function attempts to establish a connection to the specified cache driver and verifies if it is available.
		 * If the cache driver is 'redis', it creates a new Redis client, connects to the specified Redis server,
		 * and sends a PING command to check if the server is responsive.
		 * If the cache driver is 'memcached', it checks if the Memcached PHP extension is available, creates a new Memcached instance,
		 * adds a server to the instance, and retrieves server statistics to verify if the server is responsive.
		 * If the cache driver is neither 'redis' nor 'memcached', it returns true.
		 *
		 * @param string $driver The cache driver to check for availability.
		 *
		 * @return bool True if the specified cache driver is available, false otherwise.
		 */
	public static function check_available( string $driver ) {

		if ( 'redis' === $driver ) {
			try {
				$client = new Predis\Client(
					[
						'scheme'   => 'tcp',
						'host'     => get_option( '__kira_redis_host', '127.0.0.1' ),
						'port'     => (int) get_option( '__kira_redis_port', 6379 ),
						'username' => get_option( '__kira_redis_username', '' ),
						'password' => get_option( '__kira_redis_password', '' ),
						'database' => (int) get_option( '__kira_redis_db', 0 ),
					]
				);

				$result = $client?->ping( 'PONG' );
				$client?->disconnect();
				return 'PONG' === $result;
			} catch ( \Exception $e ) {
				return false;
			}
		}

		if ( 'memcached' === $driver ) {
			try {

				if ( ! class_exists( 'Memcached' ) ) {
					return false;
				}

				$memcached = new Memcached();
				$memcached->addServer( get_option( '__kira_memcached_host', '127.0.0.1' ), (int) get_option( '__kira_memcached_port', 11211 ) );
				$result = ! empty( $memcached->getStats() );
				$memcached->quit();
				return $result;
			} catch ( \Exception $e ) {
				return false;
			}
		}

		return true;
	}

	public static function clear_all() {
		$cache = new self( '' );
		return $cache->clear_all_cache();
	}

	public static function clear_single_post( int|string $id = 0, string|null $current_type = null ) {
		if ( empty( $current_type ) ) {
			$current_type = get_post_type( $id );
		}
		$cache = new self( 'file-' . $current_type );
		return $cache->delete( 'file_post_' . $id );
	}

	public static function clear_widget_block( string|null $key = null ) {
		$cache = new self( 'widget_block' );

		if ( ! empty( $key ) ) {
			return $cache->delete( $key );
		}
		$result = match ( $cache->driver ) {
			'redis' => $cache->clear_redis_cache( "{$cache->global_prefix}_{$cache->group}*" ),
			'memcached'=> $cache->clear_memcached_cache( "{$cache->global_prefix}_{$cache->group}.*" ),
			default => $cache->clear_wp_transient( "{$cache->global_prefix}_{$cache->group}.*" )
		};

		return $result;
	}
}


function gtAcCLK( $type = 1 ) {
	return match ( $type ) {
		1   => base64_decode( 'aXNfa2lyYW5pbWVfYWN0aXZl' ),
		2   => base64_decode( 'X19hX2FjdF9rZXk=' ),
		3   => base64_decode( 'X19hX2FjdF9pbmxpbmU=' ),
		4   => base64_decode( 'X19hX2FjdF9lbWFpbA==' ),
	};
}
