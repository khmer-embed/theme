<?php

class Kiranime_Most_Popular extends WP_Widget {


	public function __construct() {
		parent::__construct(
			'Kiranime_Most_Popular',
			'Kiranime Most Popular List',
			array( 'description' => 'Show Most popular list.' )
		);
	}

	public function widget( $args, $instance ) {
		$cache  = new Kiranime_Cache( 'widget_block' );
		$cached = $cache->get( 'Kiranime_Most_Popular' );

		if ( $cached ) {
			echo $cached;
			return;
		}

		$title = $instance['title'];

		$query  = new Kira_Query(
			[
				'orderby'        => 'meta_value_num',
				'meta_key'       => 'total_kiranime_views',
				'posts_per_page' => 10,
				'no_found_rows'  => 1,
			]
		);
		$animes = $query->animes;
		ob_start();
		?>

		<div class="w-full">
			<div class="mie-4 md:pli-5 lg:pli-0 plb-2 sm:mbe-4">
				<h2 class="text-lg lg:text-xl xl:text-2xl leading-10 font-semibold p-0 m-0 text-accent"><?php echo $title; ?></h2>
			</div>
			<ul class="bg-overlay pli-5 plb-4">
				<?php
				foreach ( $animes as $anime ) :
					$anime
						->gets( MetaPrefix::anime )
						->get_taxonomies( 'type', 'anime_attribute' )
						->get_featured( type: KiraType::anime, size: 'smallthumb', attributes: [ 'class' => 'absolute inset-0 w-full h-auto object-cover' ] );
					$latest   = $anime->get_episodes( is_latest:true, return:true );
					$en_title = $anime->meta['english'];
					$title    = $anime->post->post_title;
					?>
					<li class="flex gap-5 border-b border-white border-opacity-5 plb-4 relative">
						<div class="relative w-12 h-16  overflow-hidden flex-shrink-0">
							<?php echo $anime->images['featured_html']; ?>
						</div>
						<div class="flex-auto w-9/12 text-sm">
							<h3 class="mbe-1 font-medium leading-6 line-clamp-2 ">
								<a href="<?php echo esc_url( $anime->url ); ?>" title="<?php echo esc_attr( $title ); ?>" class="hover:text-accent-2">
									<?php if ( ! empty( $en_title ) ) : ?>
										<span data-en-title><?php echo $en_title; ?></span>
										<span data-nt-title class="show"><?php echo esc_html( $title ); ?></span>
									<?php else : ?>
										<?php echo esc_html( $title ); ?>
									<?php endif; ?>
								</a>
							</h3>
							<div class="text-spec flex gap-1 items-center">
								<span class="inline-block uppercase"><?php echo esc_html( ! empty( $anime->taxonomies['type'] ) ? $anime->taxonomies['type'][0]->name : '' ); ?></span>
								<?php if ( ! empty( $anime->taxonomies['type'] ) && 'movie' !== $anime->taxonomies['type'][0]->slug ) : ?>
									<span class="w-1 h-1 bg-white bg-opacity-10 inline-block"></span>
									<span class="inline-block"><?php /* Translators: Episode number */ printf( esc_attr__( 'E %s', 'kiranime' ), $latest ? $latest->meta['number'] : '?' ); ?></span>
								<?php endif; ?>
								<span class="w-1 h-1 bg-white bg-opacity-10 inline-block"></span>
								<span class="inline-block fdi-duration"><?php /* Translators: Anime duration */ printf( esc_attr__( '%sM', 'kiranime' ), number_format_i18n( absint( preg_replace( '/[^0-9]/mi', '', $anime->meta['duration'] ?? '24' ) ) ) ); ?></span>

							</div>
						</div>
					</li>
				<?php endforeach; ?>
			</ul>
		</div>

		<?php
		$result = ob_get_clean();
		$cache->set( 'Kiranime_Most_Popular', $result, get_option( '__kira_cache_time', 1800 ) );
		echo $result;
	}

	public function form( $instance ) {
		$title = $instance['title'] ?: __( 'New Title' );
		?>
		<p>
			<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:' ); ?></label>
			<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
		</p>
		<?php
	}

	public function update( $new_instance, $old_instance ) {
		Kiranime_Cache::clear_widget_block( 'Kiranime_Most_Popular' );
		return array_merge( $old_instance, $new_instance );
	}
}
