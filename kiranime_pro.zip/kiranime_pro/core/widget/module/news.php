<?php

class News_Module extends WP_Widget {

	public function __construct() {
		parent::__construct(
			// widget ID
			'kiranime_News_Module',
			// widget name
			'Kiranime News Module',
			// widget description
			array( 'description' => __( 'For News (post).', 'kiranime' ) )
		);
	}

	public function form( $instance ) {
		$status = get_terms(
			[
				'taxonomy'   => 'status',
				'hide_empty' => false,
			]
		);
		$s      = [];
		foreach ( $status as $stat ) {
			$s[ $stat->slug ] = $stat->name;
		}

		$options = [
			'title'      => [
				'type'     => 'text',
				'name'     => 'Title',
				'selected' => isset( $instance['title'] ) ? $instance['title'] : '',
			],
			'post_count' => [
				'name'     => 'Post Count',
				'type'     => 'text',
				'selected' => isset( $instance['post_count'] ) ? $instance['post_count'] : '',
			],
		];
		?>
		<p>
			<?php
			foreach ( $options as $key => $field ) :
				if ( 'text' === $field['type'] ) :
					?>

					<label for="<?php echo $this->get_field_id( $key ); ?>"><?php echo $field['name']; ?>:</label>
					<input class="widefat" id="<?php echo $this->get_field_id( $key ); ?>" name="<?php echo $this->get_field_name( $key ); ?>" type="text" value="<?php echo $field['selected']; ?>" />
					<?php
			endif;
			endforeach;
			?>
		</p>
		<?php
	}

	public function widget( $args, $instance ) {
		$instance['id'] = $args['widget_id'] ?? '';
		echo load_widget_news_data( $instance );
	}

	public function update( $new_instance, $old_instance ) {
		$instance = array_merge( $old_instance, $new_instance );
		return $instance;
	}
}
