<?php

class Kiranime_Popular_List extends WP_Widget {


	public function __construct() {
		parent::__construct(
			'Kiranime_Popular_List',
			'Kiranime Popular List',
			'Kiranime_Popular_List_domain',
			array(
				'description' => 'Show popular list.',
				'Kiranime_Popular_List_domain',
			)
		);
	}

	// Creating widget front-end

	public function widget( $args, $instance ) {
		$cache  = new Kiranime_Cache( 'widget_block' );
		$cached = $cache->get( 'Kiranime_Popular_List' );
		if ( $cached ) {
			echo $cached;
			return;
		} else {
			ob_start();
			Render::popular_list( $instance );
			$result = ob_get_clean();
			$cache->set( 'Kiranime_Popular_List', $result, get_option( '__kira_cache_time', 1800 ) );
			echo $result;
			return;
		}
	}

	// Widget Backend
	public function form( $instance ) {
		$title  = $instance['title'] ?? __( 'New title', 'kiranime' );
		$status = $instance['status'] ?? 'all';

		$statuses = get_terms(
			[
				'taxonomy'   => 'status',
				'hide_empty' => true,
			]
		);
		?>
		<p>
			<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:' ); ?></label>
			<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
		<div data-anime-status>
			<label for="<?php echo $this->get_field_id( 'status' ); ?>"><?php _e( 'Anime Status', 'kiranime' ); ?></label><br />
			<div style="width: 100%;display: flex;align-items: center;gap: 0.5rem;flex-wrap: wrap;">
				<?php
				foreach ( $statuses as $val ) :
					$checked = ( is_array( $status ) && in_array( $val->term_id, $status ) ) || ( is_string( $status ) && stripos( $status, $val->term_id ) >= 0 );
					?>
					<div style="width: max-content;display: flex;align-items: center;gap: 0.5rem;">
						<input type="checkbox" class="checkbox" id="<?php echo $this->get_field_id( 'status' ); ?>-<?php echo $val->name; ?>" name="<?php echo $this->get_field_name( 'status' ) . '[]'; ?>" value="<?php echo $val->term_id; ?>" <?php checked( $checked ); ?> />
						<label style="line-height: 1;" for="<?php echo $this->get_field_id( 'status' ); ?>-<?php echo $val->name; ?>"><?php echo $val->name; ?></label><br />
					</div>
				<?php endforeach; ?>
			</div>
		</div>
		</p>
		<?php
	}

	public function update( $new_instance, $old_instance ) {
		Kiranime_Cache::clear_widget_block( 'Kiranime_Popular_List' );
		return array_merge( $old_instance, $new_instance );
	}
}
