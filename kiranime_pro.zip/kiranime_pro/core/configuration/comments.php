<?php

if ( ! function_exists( 'kiranime_better_comments' ) ) :
	function kiranime_better_comments( $comment, $args, $depth ) {
		$uid    = isset( $comment ) ? $comment->user_id : 0;
		$avatar = Kira_User::get_avatar( $uid, [ 'class' => 'w-16 h-16 rounded-full' ] );
		?>
		<li <?php comment_class( 'mbe-3' ); ?> kira-comment-wrapper id="comment-<?php comment_ID(); ?>">
			<div id="div-comment-<?php comment_ID(); ?> " class="comment w-full flex gap-2 bg-secondary rounded-lg pis-2 min-h-[6rem]">
				<div class="w-16 min-h-[inherit] hidden sm:flex items-center justify-center">
					<?php echo $avatar; ?>
				</div>
				<div class="bg-tertiary font-normal text-sm w-full min-h-[inherit] p-2 pbs-4 pis-4 rounded-e-lg">
					<div class="comment-arrow"></div>
					<?php if ( '0' === $comment->comment_approved ) : ?>
						<em><?php esc_html_e( 'Your comment is awaiting moderation.', 'kiranime' ); ?></em>
						<br />
					<?php endif; ?>
					<div class="flex items-center justify-between w-full ">
						<div>
							<strong> <a href="<?php echo Kiranime_Watchlist::get_watchlist_url( $uid ); ?>"><?php echo get_comment_author(); ?></a></strong>
							<span> ~ </span>

							<span>
							<?php
									/* translators: 1: date, 2: time */
									printf( esc_html__( '%1$s at %2$s', 'kiranime' ), get_comment_date(), get_comment_time() )
							?>
									</span>
						</div>
						<span class="float-right" kira-respond-comment data-comment-parent="<?php comment_ID(); ?>" data-comment-post-id="<?php the_ID(); ?>">
							<span class="material-icons-round">reply</span>
							<?php
							comment_reply_link(
								array_merge(
									$args,
									[
										'add_below' => 'comment',
										'depth'     => $depth,
										'max_depth' => $args['max_depth'],
									]
								)
							)
							?>
						</span>
					</div>
					<p> <?php comment_text(); ?></p>
				</div>
			</div>
			<div id="respond-<?php comment_ID(); ?>"></div>
		</li>
		<?php
	}
endif;
