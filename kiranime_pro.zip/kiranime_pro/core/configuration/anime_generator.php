<?php
/**
 * Batch anime option page
 */
function kiranime_anime_grabber() {
	$api_key        = get_option( '__a_tmdb' );
	$jikan_endpoint = get_option( '__a_jikan' );

	$localize_js = 'var jikan_endpoint = "' . $jikan_endpoint . '"; var tmdb_api = "' . $api_key . '";';
	?>
<script>
	<?php echo $localize_js; ?>
</script>
<div class="w-full p-5 bg-white rounded-md  shadow-md drop-shadow-md lg:max-w-[95%]">
	<div id="kiranime-anime-generator">

	</div>
</div>
	<?php
}
