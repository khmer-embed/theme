<?php

/**
 * episode generator fields
 */
function kiranime_episode_grabber() {
	$api_key        = get_option( '__a_tmdb' );
	$jikan_endpoint = get_option( '__a_jikan' );

	$localize_js = 'var jikan_endpoint = "' . $jikan_endpoint . '"; var tmdb_api = "' . $api_key . '";';
	?>
<script>
	<?php echo $localize_js; ?>
</script>
<div class="w-full p-5 bg-white rounded-md  shadow-md drop-shadow-md lg:max-w-[95%]">
	<div id="kiranime-episode-generator">

	</div>
</div>
	<?php
}

function kiranime_episode_importer() {
	?>
<div class="w-full p-5 bg-white rounded-md  shadow-md drop-shadow-md lg:max-w-[95%]">
	<div id="kiranime-episode-importer">

	</div>
</div>
	<?php
}
