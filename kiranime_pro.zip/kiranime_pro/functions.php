<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * KIRANIME_REQUIRED_START
 * Do not change area!
 * This is important for kiranime to be able to work properly!
 */

define( 'KIRA_THEME_DIR', get_template_directory() );
define( 'KIRA_DIR', KIRA_THEME_DIR . '/core' );
define( 'KIRA_URI', get_template_directory_uri() );
define( 'KIRA_ASSETS', get_template_directory() . '/assets/' );
define( 'KIRA_ASSETS_URI', get_template_directory_uri() . '/assets/' );
define( 'KIRA_VER', wp_get_theme()->get( 'Version' ) );
define( 'KIRA_MODE', 1 );

require_once KIRA_DIR . '/kiranime-init.php';


/**
 * KIRANIME_REQUIRED_END
 */


/**
 * Debugging functions
 *
 * Use this to debug
 */
if ( ! function_exists( 'write_log' ) ) {

	/**
	 * Writes a log message to the PHP error log.
	 *
	 * This function is used for debugging purposes. It will only write to the log if WP_DEBUG is true.
	 *
	 * @param mixed       $log The log message. Can be a string or an array/object.
	 * @param string|null $log_name Optional. A name to identify the log message. If not provided, a default name will be used.
	 *
	 * @return void
	 */
	function write_log( mixed $log, string|null $log_name = null ) {
		if ( true === WP_DEBUG ) {
			error_log( $log_name ? "---$log_name---" : '----- KIRANIME DEBUG START -----' );
			if ( is_array( $log ) || is_object( $log ) ) {
				error_log( print_r( $log, true ) );
			} else {
				error_log( $log );
			}
			error_log( $log_name ? "---$log_name---" : '----- KIRANIME DEBUG END -----' );
		}
	}
}
