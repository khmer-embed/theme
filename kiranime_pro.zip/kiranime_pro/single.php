<?php

$current_id        = get_queried_object_id();
$current_post_type = get_post_type( $current_id );
$template          = 'file-' . $current_post_type;
$cache             = new Kiranime_Cache( $template );
if ( isset( $_GET['n_id'] ) ) {
	$notification_id = sanitize_text_field( wp_unslash( $_GET['n_id'] ) );
	Kiranime_Notification::checked( [ $notification_id ], get_current_user_id() );
}

get_header( 'single' );
$cache_key = 'file_post_' . $current_id;
$cached    = $cache->get( $cache_key );
if ( empty( $cached ) ) :
	ob_start();
	get_template_part( 'template-parts/packs/file', $current_post_type );
	$cached = ob_get_clean();
	$cache->set( $cache_key, $cached, get_option( '__kira_cache_time', 900 ) );
endif;
echo $cached;
get_footer();
