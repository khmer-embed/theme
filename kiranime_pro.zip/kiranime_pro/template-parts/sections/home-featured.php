<?php

$animes        = $args['query'];
$page_url      = $args['archive'];
$current_title = $args['title'];
?>
<section class="min-h-300 w-full mli-auto bg-secondary rounded-sm shadow drop-shadow z-0 hover:z-40 relative pbe-10">
	<h2 class="p-4 text-base leading-4 font-medium text-accent-2">
		<?php echo $current_title; ?>
	</h2>
	<ul class="m-0 p-0">
		<?php
		if ( $animes->post_count ) :
			foreach ( $animes->posts as $anime_arr ) :
				$anime = new Anime( $anime_arr->ID );
				$anime
					->get_featured( type: KiraType::anime, size: 'smallthumb', attributes: [ 'class' => 'absolute inset-0 w-full h-full object-cover' ] )
					->gets( MetaPrefix::anime )
					->get_taxonomies( 'type', 'anime_attribute' )
					->get_episodes( true )
					->get_statistic( 'total' );
				$meta         = $anime->meta;
				$latest       = ! empty( $anime->episodes ) ? $anime->episodes[0] : [];
				$current_type = isset( $anime->taxonomies['type'] ) ? $anime->taxonomies['type'] : [];

				$en_title      = $anime->meta['english'] ?? '';
				$current_title = $anime->post->post_title;
				?>
				<li class="odd:bg-tertiary flex gap-4 pli-4 plb-2 min-h-[5.25rem]">
					<div role="button" aria-label="anime-<?php echo $anime->post->post_name; ?>" 
																	<?php
																	if ( get_theme_mod( '__show_tooltip', 'show' ) === 'show' ) :
																		?>
						data-tippy-featured-id="<?php echo $anime->id; ?>" <?php endif; ?> class=" min-w-12 min-h-16 aspect-[3/4] pbe-16 rounded shadow relative overflow-hidden bg-primary flex-grow flex-shrink flex-[calc(100%/6)]">
						<a href="<?php echo $anime->url; ?>" title="<?php echo esc_attr( $current_title ); ?>">
							<?php echo $anime->images['featured_html']; ?>
						</a>
					</div>

					<div class="w-full flex-auto">
						<h3 class="text-sm line-clamp-2 font-medium leading-6 mbe-1">
							<a href="<?php echo $anime->url; ?>" title="<?php echo esc_attr( $current_title ); ?>" class="dynamic-name">
								<?php if ( ! empty( $en_title ) ) : ?>
									<span data-en-title><?php echo esc_html( $en_title ); ?></span>
									<span data-nt-title class="show"><?php echo esc_html( $current_title ); ?></span>
								<?php else : ?>
									<?php echo esc_html( $current_title ); ?>
								<?php endif; ?>
							</a>
						</h3>
						<div class="flex items-center text-xs gap-2">
							<span class="whitespace-nowrap uppercase">
								<?php echo esc_html( ! is_wp_error( $current_type ) && count( $current_type ) !== 0 ? $current_type[0]->name : 'TV' ); ?>
							</span>
							<span class="w-1 h-1 rounded-full bg-white bg-opacity-25 inline-block"></span>
							<?php if ( isset( $current_type[0] ) && ! empty( $current_type[0] ) && 'movie' !== $current_type[0]->slug ) : ?>
								<span class="whitespace-nowrap">
									<?php /* Translators: Episode Number */ printf( esc_html__( 'E %s', 'kiranime' ), ! empty( $latest->meta['number'] ) ? number_format_i18n( absint( $latest->meta['number'] ) ) : '?' ); ?>
								</span>
								<span class=" w-1 h-1 rounded-full bg-white bg-opacity-25 inline-block "></span>
							<?php endif; ?>
							<span class="whitespace-nowrap fdi-duration">
							<?php /* Translators: Anime duration */ printf( esc_html__( '%sM', 'kiranime' ), number_format_i18n( absint( preg_replace( '/[^0-9]/mi', '', $meta['duration'] ?? '24' ) ) ) ); ?>
							</span>
							<span class=" w-1 h-1 rounded-full bg-white bg-opacity-25 inline-block "></span>
							<span class="flex items-center gap-1">
								<svg xmlns="http://www.w3.org/2000/svg" class="w-4 h-4" viewBox="0 0 24 24"><path fill="currentColor" d="M17.66 11.2c-.23-.3-.51-.56-.77-.82c-.67-.6-1.43-1.03-2.07-1.66C13.33 7.26 13 4.85 13.95 3c-.95.23-1.78.75-2.49 1.32c-2.59 2.08-3.61 5.75-2.39 8.9c.04.1.08.2.08.33c0 .22-.15.42-.35.5c-.23.1-.47.04-.66-.12a.6.6 0 0 1-.14-.17c-1.13-1.43-1.31-3.48-.55-5.12C5.78 10 4.87 12.3 5 14.47c.06.5.12 1 .29 1.5c.14.6.41 1.2.71 1.73c1.08 1.73 2.95 2.97 4.96 3.22c2.14.27 4.43-.12 6.07-1.6c1.83-1.66 2.47-4.32 1.53-6.6l-.13-.26c-.21-.46-.77-1.26-.77-1.26m-3.16 6.3c-.28.24-.74.5-1.1.6c-1.12.4-2.24-.16-2.9-.82c1.19-.28 1.9-1.16 2.11-2.05c.17-.8-.15-1.46-.28-2.23c-.12-.74-.1-1.37.17-2.06c.19.38.39.76.63 1.06c.77 1 1.98 1.44 2.24 2.8c.04.14.06.28.06.43c.03.82-.33 1.72-.93 2.27"/></svg>	
								<?php echo Kira_Utility::get_view_count( $anime->statistic['total'] ?? 0 ); ?>
							</span>
						</div>
					</div>
				</li>
				<?php
		endforeach;
		endif;
		?>
	</ul>
	<div class="w-full absolute block-end-0">
		<a class=" p-4 plb-2 text-text-color text-opacity-90 bg-opacity-10 bg-white hover:bg-opacity-30 font-light flex items-center justify-center gap-2 " href="<?php echo $page_url; ?>">
			<?php _e( 'View More', 'kiranime' ); ?>
			<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 256 512" class="w-5 h-5 rtl:hidden">
				<path fill="currentColor" d="M224.3 273l-136 136c-9.4 9.4-24.6 9.4-33.9 0l-22.6-22.6c-9.4-9.4-9.4-24.6 0-33.9l96.4-96.4-96.4-96.4c-9.4-9.4-9.4-24.6 0-33.9L54.3 103c9.4-9.4 24.6-9.4 33.9 0l136 136c9.5 9.4 9.5 24.6.1 34z" />
			</svg>
		</a>
	</div>
</section>
