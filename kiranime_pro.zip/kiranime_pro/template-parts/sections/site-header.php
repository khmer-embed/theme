<?php
$uid         = get_current_user_id();
$uif         = get_userdata( $uid );
$nid         = Kiranime_Notification::get( true );
$unread      = array_filter(
	$nid,
	function ( $val ) {
		return ! $val['status'];
	}
);
$single_post = is_single() || is_page() || is_archive();
?>
<style>
	:root {
		--completed-status: 
		<?php
		echo get_option( '__u_status_bg', get_theme_mod( 'error-color', '#f43f5e' ) );
		?>
		;
	}
</style>
<div class="pis-4 sm:pli-5 md:pli-4 xl:pli-0 4xl:pli-10 relative w-full max-w-screen flex items-center justify-between h-full">
	<div id="kiranime-heading" class="relative w-full flex items-center h-full">
		<div data-sidebar-trigger class="cursor-pointer flex items-center">
			<span class="material-icons-round text-2xl lg:text-3xl">
				menu
			</span>
		</div>
		<?php
		if ( ! $single_post ) {
			echo "<h1 aria-label='logo " . get_bloginfo( 'name' ) . "'>";
		}
		?>
			<?php
			if ( get_theme_mod( 'custom_logo' ) ) {
				the_custom_logo();
			} else {
				?>
					<a href="/" id="logo" class="mie-4 md:mie-8 mis-4 md:mis-8 block">
						<?php echo get_bloginfo( 'name' ); ?>
					</a>
				<?php
			}
			if ( ! $single_post ) {
				echo '</h1>';
			}
			?>
		<div id="search" class="hidden lg:block lg:w-full lg:max-w-md">
			<div class="search-content relative">
				<?php $advanced_search_url = Kira_Utility::page_slug( 'pages/search.php' ); ?>
				<form action="/<?php echo $advanced_search_url; ?>" method="GET" autocomplete="off" class="relative">
					<a href="/<?php echo $advanced_search_url; ?>" class="absolute top-2 end-2 text-xs bg-primary bg-opacity-80 pli-2 plb-1 rounded-sm"><?php esc_html_e( 'Filter', 'kiranime' ); ?></a>

					<input type="text" data-search-ajax-input class="bg-white rounded text-gray-800 font-medium placeholder:font-normal h-10 leading-normal m-0 overflow-visible plb-2 pie-20 pis-4 transition-all duration-150 ease-in-out focus:shadow-md w-full focus:outline-none text-[13px] peer" name="s_keyword" placeholder="<?php esc_html_e( 'Search anime...', 'kiranime' ); ?>">
					<button type="submit" class="absolute top-1 end-16 pli-2 plb-1 w-max text-primary hidden peer-focus:block">
						<span class="material-icons-round text-2xl">
							search
						</span>
					</button>
				</form>
				<div class="bg-tertiary shadow-lg absolute top-10 inset-x-0 z-10 list-none hidden" data-search-ajax-result> 
					<div class="loading-relative" id="search-loading" style="display: none;">
						<div class="loading">
							<div class="span1"></div>
							<div class="span2"></div>
							<div class="span3"></div>
						</div>
					</div>
					<div data-search-result-area class="max-h-96 overflow-y-scroll overflow-x-hidden">

					</div>
					<a data-search-view-all href="/<?php echo $advanced_search_url; ?>" class="flex items-center justify-center w-full p-4 text-[13px] font-medium bg-accent-3">
						<?php esc_html_e( 'View all results', 'kiranime' ); ?>
						<span class="material-icons-round text-lg mis-2">
							east
						</span>
					</a>
				</div>
			</div>
		</div>
		<div class="lg:mis-8 hidden lg:flex items-center gap-2">
			<?php
			if ( get_theme_mod( '__show_social_link', 'show' ) === 'show' ) :
				foreach ( Kira_Utility::social() as $key => $val ) :
					if ( $val['link'] ) :
						if ( 'instagram' === $key ) :
							?>
							<div>
								<a href="<?php echo $val['link']; ?>" class="w-10 h-10 flex items-center justify-center rounded-sm icon-instagram" target="_blank">
									<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-instagram w-5 h-5 icon-instagram">
										<rect x="2" y="2" width="20" height="20" rx="5" ry="5"></rect>
										<path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"></path>
										<line x1="17.5" y1="6.5" x2="17.5" y2="6.5"></line>
									</svg>
								</a>
							</div>
						<?php else : ?>
							<div>
								<a href="<?php echo esc_url( $val['link'] ); ?>" class="w-10 h-10 flex items-center justify-center rounded-sm" target="_blank" style="background: <?php echo $val['color']; ?>;">
									<svg xmlns="http://www.w3.org/2000/svg" class="w-5 h-5" viewBox="<?php echo $val['vbox']; ?>">
										<path fill="currentColor" d="<?php echo $val['icon']; ?>" />
									</svg>
								</a>
							</div>
							<?php
						endif;
					endif;
				endforeach;
			endif;
			?>
		</div>
	</div>
	<div class="w-full flex items-center justify-end pie-4 md:pie-0 lg:w-fit min-w-max lg:gap-4 gap-1">
		<div class="w-1/3 max-w-12 lg:max-w-full flex items-center justify-end lg:hidden">
			<button data-mobile-search-trigger class="flex items-center">
				<span class="material-icons-round text-xl">
					search
				</span>
			</button>
		</div>
		<?php if ( get_option( '__q_title_switcher', false ) ) : ?>
			<div class="md:mis-4 hidden md:flex items-center">
				<span data-use-lang="en">
					<?php echo get_option( '__q_en_title_label', 'EN' ) ?? 'EN'; ?>
				</span>
				<span data-use-lang="jp" class="show">
					<?php echo get_option( '__q_jp_title_label', 'JP' ); ?>
				</span>
			</div>
		<?php endif; ?>
		<div title="<?php esc_html_e( 'I\'m feeling lucky!', 'kiranime' ); ?>" class="w-1/3 max-w-12">
			<div id="random-anime" class="relative leading-10 cursor-pointer rounded-full flex items-center justify-center lg:bg-white lg:bg-opacity-10 lg:w-10 lg:h-10">
				<span class="material-icons-round text-xl lg:text-[20px]">
					shuffle
				</span>
			</div>
		</div>

		<?php if ( ! is_user_logged_in() ) { ?>
			<span data-login-toggle class="block w-12 min-w-max rounded-sm bg-accent-3 md:pli-4 md:plb-2 lg:min-h-[2.5rem] pli-2 plb-1 cursor-pointer font-medium"><?php esc_html_e( 'Login', 'kiranime' ); ?></span>
		<?php } ?>

		<?php if ( is_user_logged_in() ) : ?>
			<div class="w-max flex items-center justify-end gap-3 md:gap-3 lg:gap-4 pie-4">
				<div class="relative w-1/3 max-w-12">
					<div id="history-active" class="lg:w-10 lg:h-10 relative leading-10 cursor-pointer rounded-full bg-opacity-0 lg:bg-opacity-10 bg-white flex items-center justify-center">
						<span class="material-icons-round text-xl lg:text-2xl">
							history
						</span>
					</div>
				</div>
				<div class="relative w-1/3 max-w-12">
					<div data-dropdown-notification-trigger role="button" aria-label="user notification" class="lg:w-10 lg:h-10 relative leading-10 cursor-pointer rounded-full  bg-opacity-0 lg:bg-opacity-10 bg-white flex items-center justify-center">
						<?php if ( isset( $unread ) && ! empty( $unread ) ) : ?>
							<div data-notification-number class="flex rounded-full absolute -top-1 -inline-end-1 bg-error-1 items-center justify-center overflow-hidden w-5 h-5 text-xs font-medium plb-1">
								<?php echo count( $unread ); ?> 
							</div>
						<?php endif; ?>
						<span class="material-icons-round text-xl lg:text-2xl">
							notifications
						</span>
					</div>
					<div data-dropdown-notification-content="0" class="w-full h-full min-w-[280px] bg-overlay rounded-xl shadow-lg overflow-hidden">
						<input type="hidden" name="notif-ids" value="
						<?php
																		$data = ! empty( $nid ) ? array_map(
																			function ( $val ) {
																				return $val['notif_id'];
																			},
																			$nid
																		) : [];
																		echo esc_attr( implode( ',', $data ) );
						?>
																		">
						<div data-set-all-notification-read onclick="readallnotif()" class="block w-full mbe-2 bg-black bg-opacity-20">
							<a class="flex items-center gap-2 justify-center w-full bg pli-4 plb-2  hover:text-accent cursor-pointer" data-position="dropdown">
								<span class="material-icons-round text-xl">
									check
								</span>
								<?php esc_html_e( 'Mark all as read', 'kiranime' ); ?></a>
						</div>
						<div data-notification-content-area class="max-h-52 overflow-y-auto overflow-x-hidden">
							<?php foreach ( $nid as $notification ) : ?>
								<a data-notification-id="<?php echo esc_attr( $notification['notif_id'] ); ?>" class="flex gap-2 mbe-2 text-xs font-medium pli-4 plb-2 <?php echo $notification['status'] ? 'opacity-75' : ''; ?>" href="<?php echo esc_url( $notification['url'] ); ?>?n_id=<?php echo esc_attr( $notification['notif_id'] ); ?>">
									<div class="w-12 h-16 overflow-hidden relative shrink-0 grow-0">
										<?php echo $notification['featured']; ?>
									</div>
									<div>
										<span class="block">
											<?php
											/* translators: 1: notification title (anime title), 2: episode number */
											printf( esc_html__( '%1$s - Episode %2$s Available NOW!', 'kiranime' ), $notification['title'], $notification['number'] );
											?>

										</span>
										<div class="text-xs font-light mbs-1 text-accent">
											<?php echo esc_html( $notification['published'] ); ?></div>
									</div>
								</a>
							<?php endforeach; ?>
						</div>
						<a class="block rounded-b-md shadow-md bg-secondary w-full pli-4 plb-2 text-sm" href="<?php echo Kira_Utility::page_link( 'pages/notification.php' ); ?>">
							<div class="text-center  hover:text-sky-300"><?php esc_html_e( 'View all', 'kiranime' ); ?></div>
						</a>
					</div>
				</div>
				<div class="w-7 h-7 md:w-9 md:h-9 lg:w-10 lg:h-10 bg-cover bg-center bg-no-repeat rounded-full relative cursor-pointer">
					<?php echo Kira_User::get_avatar( get_current_user_id(), [ 'class' => 'block absolute inset-0 rounded-full w-7 h-7 md:w-9 md:h-9 lg:w-10 lg:h-10' ], 'smallthumb' ); ?>
					<button class="absolute inset-0 opacity-0 w-full h-full" data-user-menu-dropdown aria-label="user menu dropdown">

					</button>

					<div data-user-menu-content data-user-menu-state="0" class="w-full h-full min-w-[280px] bg-overlay rounded-lg shadow-lg">
						<div class="pli-3 plb-1">
							<div class="w-full">
								<div class="w-full text-sm font-semibold text-accent leading-9">
									<strong data-current-username>
									<?php
									if ( $uif ) {
																		echo $uif->display_name;
									}
									?>
																	</strong>
								</div>
								<div class="w-full text-xs font-light text-gray-200">
									<?php
									if ( $uif ) {
										echo $uif->user_email;
									}
									?>
								</div>
							</div>
						</div>
						<div class="mbs-1 space-y-1">
							<?php foreach ( Kira_Utility::get_user_menu() as $menu_current ) : ?>
								<a class="pli-4 plb-3 flex items-center hover:text-accent gap-2 font-medium text-xs bg-overlay bg-opacity-20 rounded-xl" href="<?php echo $menu_current['link']; ?>">
									<span class="material-icons-round text-xl">
										<?php echo $menu_current['icon']; ?>
									</span>
									<?php echo esc_html( $menu_current['name'] ); ?>
								</a>
							<?php endforeach; ?>
						</div>
						<a data-logout-trigger class="p-5 hover:text-accent flex w-full items-center justify-end gap-2 font-medium text-xs rounded-md" href="#">
							<span class="material-icons-round text-xl">
								logout
							</span>
							<?php esc_html_e( 'Logout', 'kiranime' ); ?>
						</a>
					</div>
				</div>
			</div>
		<?php endif; ?>
	</div>
</div>
<div data-mobile-search-status="0" class="w-full pointer-events-none bg-primary bg-opacity-90 pbe-2 transform -translate-y-full opacity-0 transition-all duration-200 z-40">
	<div class="relative w-full plb-4">
		<form action="/<?php echo $advanced_search_url; ?>" autocomplete="off" class="w-full flex items-center justify-center relative pli-4">
			<a href="/<?php echo $advanced_search_url; ?>" class="w-1/12 h-9 rounded-sm flex items-center justify-center bg-overlay">
				<span class="material-icons-round text-2xl">
					filter_alt
				</span>
			</a>
			<input data-mobile-search-input type="text" class="w-10/12 h-9 pli-2 plb-1 leading-6 text-sm rounded-sm text-gray-900" name="s_keyword" placeholder="<?php esc_attr_e( 'Search anime...', 'kiranime' ); ?>" />
			<div class="bg-primary/90 shadow-lg absolute top-10 mbs-1 pbe-3 inset-x-0 z-10 pli-4 list-none" data-mobile-search-result>
				<div data-mobile-search-result-area class="max-h-[65svh] overflow-auto">

				</div>
				<a data-search-view-all href="/<?php echo $advanced_search_url; ?>" class="flex items-center justify-center w-full plb-2 bg-accent-3 text-sm rounded">
					<?php esc_html_e( 'View all results', 'kiranime' ); ?> <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 256 512" class="w-4 h-4 mis-2 inline-block">
						<path fill="currentColor" d="M224.3 273l-136 136c-9.4 9.4-24.6 9.4-33.9 0l-22.6-22.6c-9.4-9.4-9.4-24.6 0-33.9l96.4-96.4-96.4-96.4c-9.4-9.4-9.4-24.6 0-33.9L54.3 103c9.4-9.4 24.6-9.4 33.9 0l136 136c9.5 9.4 9.5 24.6.1 34z" />
					</svg></i>
				</a>
			</div>
			<button type="submit" class="w-1/12 flex items-center plb-2 text-accent end-8 h-9 justify-center">
				<span class="material-icons-round text-2xl">
					search
				</span>
			</button>
		</form>
	</div>
</div>
