<?php

$cache      = new Kiranime_Cache( 'trending_data' );
$cache_key  = 'current_trending_data';
$cached     = $cache->get( $cache_key );
$save_cache = false;
if ( empty( $cached ) ) :
	$query      = new Kira_Query();
	$query      = $query->trending();
	$save_cache = ! $query->empty;
	ob_start();
	?>
	<style>
		@media (min-width: 1024px) {
			.swiper-trending .swiper-slide {
				width: auto !important;
			}
		}
	</style>
	<div class="pli-2 lg:pli-5 lg:pbe-10 pbe-5 
	<?php
	if ( get_theme_mod( '__show_spotlight' ) === 'hide' ) :
		echo 'lg:mbs-17';
												else :
													echo '-mbs-4';
												endif;
												?>
												">
		<div class="p-4 pli-0 text-xl lg:text-2xl leading-4 lg:leading-10 font-semibold text-accent-2">
			<h2><?php _e( 'Trending', 'kiranime' ); ?></h2>
		</div> 
		<div class=" plb-0 mbs-2 md:flex justify-between w-full " style="background: linear-gradient(0deg,var(--primary-darkest-color) 0,rgba(18,19,21,0) 99%);">
			<div class="swiper swiper-trending">
				<div class="swiper-wrapper" style="min-width: 100vw;">
					<!-- Slides -->
					<?php
					foreach ( $query->animes as $index => $anime ) :
						$anime->get_featured( type: KiraType::anime, size: 'kirathumb', attributes: [ 'class' => 'w-full h-full sm:w-3/4 lg:w-40 lg:h-56 xl:w-52 xl:h-[19rem] absolute sm:start-1/5 lg:start-10 object-cover' ] )->gets( MetaPrefix::anime );
						$en_title      = $anime->meta['english'] ?? '';
						$current_title = $anime->post->post_title;
						?>
						<div class="swiper-slide md:min-w-[14rem]">
							<a href="<?php echo esc_url( $anime->url ); ?>" class="sm:flex hidden relative sm:pbe-64 md:pbe-56 overflow-hidden lg:max-h-64 lg:pbe-64 xl:max-h-[16rem] xl:pbe-64  shadow-sm min-w-full w-56">
								<div class="sm:w-1/5 lg:w-10 h-full flex flex-col items-center gap-2 absolute start-0 bottom-0 font-semibold font-montserrat bg-gradient-to-t from-primary to-secondary">
									<span class="h-5 line-clamp-1 -rotate-90 transform overflow-hidden overflow-ellipsis text-sm absolute bottom-24 items-center" style="bottom: 8rem;width: 12.5rem;">
										<?php if ( ! empty( $en_title ) ) : ?>
											<span data-nt-title class="show trending"><?php echo esc_html( $current_title ); ?></span>
											<span data-en-title class="trending"><?php echo esc_html( $en_title ); ?></span>
										<?php else : ?>
											<?php echo esc_html( $current_title ); ?>
										<?php endif; ?>
									</span>
									<span class="flex items-center justify-center absolute bottom-0 text-2xl text-accent"><?php echo number_format_i18n( $index < 9 ? '0' . ( $index + 1 ) : ( $index + 1 ) ); ?></span>
								</div>
								<?php echo $anime->images['featured_html'] ? $anime->images['featured_html'] : $index; ?>
							</a>
							<a href="<?php echo $anime->url; ?>" class="relative w-full sm:hidden">
								<div class="relative pbe-48 md:pbe-52 overflow-hidden">
									<?php echo $anime->images['featured_html'] ?? Kira_Utility::get_no_image(); ?>
									<div class="absolute -top-11 -start-11 w-20 h-20 z-10 bg-accent-3 text-text-color rotate-45 transform">
									</div>
									<span class="w-max top-[2.5%] start-[10%] text-center font-semibold z-20 text-xs absolute"><?php echo number_format_i18n( $index + 1 ); ?></span>
								</div>
							</a>
						</div>
					<?php endforeach; ?>
				</div>
				<div class="swiper-pagination lg:hidden"></div>
			</div>
			<div class="swiper-navigation mis-5 md:grid hidden">
				<div class="mbe-2 bg-tertiary rounded-sm rtl:rotate-180 shadow-sm p-2 trending-nav-next hover:bg-accent-3 flex items-center justify-center" tabindex="0" role="button" aria-label="Next slide">
					<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 192 512" class="w-6 h-6">
						<path fill="currentColor" d="M187.8 264.5L41 412.5c-4.7 4.7-12.3 4.7-17 0L4.2 392.7c-4.7-4.7-4.7-12.3 0-17L122.7 256 4.2 136.3c-4.7-4.7-4.7-12.3 0-17L24 99.5c4.7-4.7 12.3-4.7 17 0l146.8 148c4.7 4.7 4.7 12.3 0 17z" />
					</svg>
				</div>
				<div class="bg-tertiary rounded-sm shadow-sm rtl:rotate-180 p-2 trending-nav-prev hover:bg-accent-3 flex items-center justify-center" tabindex="0" role="button" aria-label="Previous slide">
					<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 192 512" class="w-6 h-6">
						<path fill="currentColor" d="M4.2 247.5L151 99.5c4.7-4.7 12.3-4.7 17 0l19.8 19.8c4.7 4.7 4.7 12.3 0 17L69.3 256l118.5 119.7c4.7 4.7 4.7 12.3 0 17L168 412.5c-4.7 4.7-12.3 4.7-17 0L4.2 264.5c-4.7-4.7-4.7-12.3 0-17z" />
					</svg>
				</div>
			</div>
		</div>
	</div>
	<?php
	$cached = ob_get_clean();
	$cache->set( $cache_key, $cached );
endif;
	echo $cached;
