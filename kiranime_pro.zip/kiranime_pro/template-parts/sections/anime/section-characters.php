<?php
$cast = [];

if ( isset( $args['characters'] ) ) {
	if ( is_string( $args['characters'] ) ) {
		$cast = json_decode( $args['characters'], true );
	} else {
		$cast = $args['characters'];
	}
}
if ( ! empty( $cast ) && get_theme_mod( '__show_characters', 'show' ) === 'show' ) :

	?>
	<section class="mbe-5">
		<h2 class="font-semibold col-span-full text-accent-2 text-xl lg:text-2xl leading-loose mbe-5">
			<?php esc_html_e( 'Characters and Voice Actors', 'kiranime' ); ?>
		</h2>
		<div data-characters style="--height-type: <?php echo count( $cast ) > 9 ? '240px' : 'max-content'; ?>;" class="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-2  overflow-hidden animate-kira">
			<?php foreach ( $cast as $index => $char ) : ?>
				<div data-character class="w-full min-h-[72px] h-fit rounded-sm shadow-sm shadow-tertiary bg-secondary bg-opacity-25 relative flex items-center justify-between">
					<div class="w-1/2 p-2 flex gap-4 items-center justify-start">
						<div class="rounded-full w-12 min-w-[3rem] relative h-12 overflow-hidden flex items-center justify-center">
							<img src="<?php echo esc_url( ! empty( $char['character']['image'] ) ? str_replace( '/large/', '/medium/', $char['character']['image'] ) : KIRA_URI . '/avatar/no_image.png' ); ?>" alt="<?php echo esc_html( ! empty( $char['character']['name'] ) ? $char['character']['name'] : '' ); ?>" class="block inset-0 w-full h-auto" loading="lazy">
						</div>
						<div class="w-auto">
							<h4 class="text-xs font-medium line-clamp-2 text-start min-[480px]:w-fit">
								<?php echo esc_html( ! empty( $char['character']['name'] ) ? $char['character']['name'] : '' ); ?></h4>
							<span class="font-light text-xs text-secondary/90">
								<?php echo esc_html( ! empty( $char['role'] ) ? $char['role'] : 'MAIN' ); ?>
							</span>
						</div>
					</div>
					<div class="w-1/2 p-2 flex gap-4 items-center justify-end">
						<?php
						if ( ! empty( $char['voice_actors'] ) ) :
							$is_japanese = array_filter(
								$char['voice_actors'],
								function ( $val ) {
									return 'Japanese' === $val['lang'];
								}
							);

							if ( ! empty( $is_japanese ) ) :
								?>
								<div class="w-auto flex flex-col items-end ">
									<h4 class="text-xs font-medium self-end w-min text-end min-[480px]:w-fit">
										<?php echo esc_html( ! empty( $is_japanese[0]['name'] ) ? $is_japanese[0]['name'] : '-' ); ?></h4>
									<span class="font-light text-xs text-secondary/90">
										<?php echo esc_html( ! empty( $is_japanese[0]['lang'] ) ? $is_japanese[0]['lang'] : 'Japanese' ); ?>
									</span>
								</div>
								<div class="rounded-full w-12 min-w-[3rem] relative h-12 overflow-hidden flex items-center justify-center">
									<img src="<?php echo ! empty( $is_japanese[0]['image'] ) ? str_replace( '/large/', '/medium/', $is_japanese[0]['image'] ) : KIRA_URI . '/avatar/no_image.png'; ?>" alt="<?php echo esc_attr( ! empty( $is_japanese[0]['name'] ) ? $is_japanese[0]['name'] : '-' ); ?>" class="block inset-0 w-full h-auto" loading="lazy">
								</div>
							<?php else : ?>
								<div class="w-auto">
									<h4 class="text-xs font-medium line-clamp-2 min-[480px]:w-fit">
										<?php echo ! empty( $char['voice_actors'][0]['name'] ) ? $char['voice_actors'][0]['name'] : '-'; ?></h4>
									<span class="font-light text-xs text-secondary/90">
										<?php echo ! empty( $char['voice_actors'][0]['lang'] ) ? $char['voice_actors'][0]['lang'] : 'Japanese'; ?>
									</span>
								</div>
								<div class="rounded-full w-12 min-w-[3rem] relative h-12 overflow-hidden flex items-center justify-center">
									<img src="<?php echo ! empty( $char['voice_actors'][0]['image'] ) ? str_replace( '/large/', '/medium/', $char['voice_actors'][0]['image'] ) : KIRA_URI . '/avatar/no_image.png'; ?>" alt="<?php echo ! empty( $char['voice_actors'][0]['name'] ) ? $char['voice_actors'][0]['name'] : '-'; ?>" class="block inset-0 w-full h-auto" loading="lazy">
								</div>
								<?php
						endif;
						endif;
						?>
					</div>
				</div>
			<?php endforeach; ?>
		</div>
		<?php if ( count( $cast ) > 9 ) : ?>
			<div data-show-all-button class="col-span-full mbs-4 flex w-full items-center justify-center text-text-color hover:bg-secondary hover:shadow-lg ring-primary hover:drop-shadow-lg group h-max cursor-pointer gap-4 plb-2 transition-colors duration-200 ease-in-out">
				<small class="text-sm font-light w-max group-hover:font-medium"><?php _e( 'Show All', 'kiranime' ); ?></small>
				<svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
					<path stroke-linecap="round" stroke-linejoin="round" d="M19 9l-7 7-7-7" />
				</svg>
			</div>
			<div data-hide-all-button class="col-span-full hidden mbs-4 w-full items-center justify-center text-text-color hover:bg-secondary hover:shadow-lg ring-primary hover:drop-shadow-lg group h-max cursor-pointer gap-4 plb-2 transition-colors duration-200 ease-in-out">
				<svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
					<path stroke-linecap="round" stroke-linejoin="round" d="M5 15l7-7 7 7" />
				</svg>
				<small class="text-sm font-light w-max group-hover:font-medium"><?php _e( 'Close', 'kiranime' ); ?></small>
			</div>
		<?php endif; ?>
	</section>
<?php endif; ?>
