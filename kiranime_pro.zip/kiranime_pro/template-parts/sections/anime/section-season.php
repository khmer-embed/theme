<?php

$animes = $args['animes'];
if ( ! empty( $animes ) ) :
	?>
	<style>
		.before-bg::before {
			background-image: url('<?php echo KIRA_URI . '/avatar/default/grid-element.png'; ?>');
		}
	</style>
	<section class="mbe-5">
		<h2 class="font-semibold col-span-full text-accent-2 mbe-5 text-2xl leading-loose">
			<?php
			if ( get_theme_mod( '__show_season_label' ) ) {
				echo get_theme_mod( '__show_season_label' );
			} else {
				echo esc_html_e( 'More Season', 'kiranime' );
			}
			?>
		</h2>
		<div class="relative"> 
			<div class="swiper swiper-season">
				<div class="swiper-wrapper">
					<?php
					foreach ( $animes as $season ) :
						$anime = new Anime( $season->ID );
						$anime->get_featured( KiraType::anime )->gets( MetaPrefix::anime );

						?>
						<div class="swiper-slide">
							<a href="<?php echo $anime->url; ?>" class="
												<?php
												if ( get_the_ID() === $season->ID ) {
																	echo 'border-accent-2 border-2';
												}
												?>
																shadow-md drop-shadow-md shadow-tertiary rounded-md flex items-center justify-center p-1 h-16 relative before:absolute before:inset-0 before:z-[2] before:bg-repeat before-bg group overflow-hidden" title="<?php echo $season->post_title; ?>">
								<div class="text-xs font-medium group-hover:text-accent relative z-[4] line-clamp-2 text-center">
									<?php echo esc_html( $anime->meta['season'] ?? $anime->post->post_title ); ?></div>
								<div class="absolute -inset-3 z-0 blur-sm <?php echo get_the_ID() === $season->ID ? 'opacity-60' : 'opacity-30'; ?> group-hover:opacity-20" style="background-image: url('<?php echo esc_url( $anime->images['featured_url'] ); ?>');">
								</div>
							</a>
						</div>
					<?php endforeach; ?>
				</div>
			</div>
			<div class="absolute season-prev z-999 start-0 top-1/2 transform -translate-y-1/2 cursor-pointer opacity-30 shadow-accent-2 hover:shadow-lg hover:opacity-100 hover:bg-primary/50 h-full transition-all duration-300 flex items-center justify-center">
				<svg xmlns="http://www.w3.org/2000/svg" class="size-8" viewBox="0 0 16 16">
					<path fill="currentColor" fill-rule="evenodd" d="M11.354 1.646a.5.5 0 0 1 0 .708L5.707 8l5.647 5.646a.5.5 0 0 1-.708.708l-6-6a.5.5 0 0 1 0-.708l6-6a.5.5 0 0 1 .708 0" />
				</svg>
			</div>
			<div class="absolute season-next z-999 end-0 top-1/2 transform -translate-y-1/2 cursor-pointer opacity-30 shadow-accent-2 hover:shadow-lg hover:opacity-100 hover:bg-primary/50 h-full transition-all duration-300 flex items-center justify-center">
				<svg xmlns="http://www.w3.org/2000/svg" class="size-8" viewBox="0 0 16 16">
					<path fill="currentColor" fill-rule="evenodd" d="M4.646 1.646a.5.5 0 0 1 .708 0l6 6a.5.5 0 0 1 0 .708l-6 6a.5.5 0 0 1-.708-.708L10.293 8L4.646 2.354a.5.5 0 0 1 0-.708" />
				</svg>
			</div>

		</div>
	</section>
<?php endif; ?>
