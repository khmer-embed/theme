<?php
$is_anime = isset( $args['is_anime'] ) ? $args['is_anime'] : false;
$episodes = $args['episodes'];
foreach ( $episodes as $episode ) :
	$episode
		->gets( MetaPrefix::episode )
		->get_featured(
			type: KiraType::episode,
			size: 'featuredthumb',
			attributes: [
				'class' => 'w-full h-full object-cover',
				'alt'   => $episode->meta['title'],
			]
		);
	$image = $episode->images['featured_html'];
	$anime = isset( $episode->meta['parent_id'] ) && $episode->meta['parent_id'] ? new Anime( intval( $episode->meta['parent_id'] ) ) : null;
	$anime?->get_taxonomies( 'anime_attribute' )?->gets( MetaPrefix::anime );
	if ( ! $image && $anime ) {
		$anime->get_featured( type: KiraType::anime, size: 'kirathumb', attributes: [ 'class' => 'w-full h-full object-cover' ] );
		$image = $anime?->images['featured_html'];
	}

	$attr     = $anime?->taxonomies['anime_attribute'];
	$anititle = $anime?->post->post_title ?? $episode->meta['parent_name'];
	$en_title = $anime?->meta['english'] ?? '';
	?>
	<a href="<?php echo $episode->url; ?>" class="block w-full relative overflow-hidden rounded-md shadow-md ring-primary aspect-w-16 aspect-h-9 group">
		<div class="w-full absolute z-0">
			<?php echo $image; ?>
		</div>
		<span class="block absolute top-0 start-0 bg-accent-2 min-w-0 w-max h-max text-xs font-medium plb-1 pli-2 rounded-br-md shadow-md">
			<?php
			/* translators: Episode Number */
			printf( esc_html__( 'Episode %s', 'kiranime' ), esc_html( $episode->meta['number'] ?? 0 ) )
			?>
		</span>
		<div class="w-full p-1 absolute z-[1] top-auto bottom-0 h-fit inset-x-0 bg-primary/75">
			<?php if ( $is_anime ) : ?>
				<h4 class="text-xs font-medium line-clamp-1 plb-0.5 leading-6">
					<?php echo esc_html( $episode->meta['title'] ?? $episode->post->post_title ); ?>
				</h4>
			<?php else : ?>
				<h3 class="text-xs font-medium line-clamp-1 plb-0.5 leading-6">
					<?php echo esc_html( $episode->meta['title'] ?? $episode->post->post_title ); ?>
				</h3>
			<?php endif; ?>
			<div class="bg-white bg-opacity-10 h-0.5 w-full"></div>
			<span class="text-xs font-medium line-clamp-1 plb-0.5">
				<?php if ( ! empty( $en_title ) ) : ?>
					<span data-en-title><?php echo esc_html( $en_title ); ?></span>
					<span data-nt-title class="show"><?php echo esc_html( $anititle ); ?></span>
				<?php else : ?>
					<?php echo esc_html( $anititle ); ?>
				<?php endif; ?>
			</span>
		</div>
		<div class="absolute inset-0 w-full h-full bg-primary/30 z-[2] flex items-center justify-center group-hover:opacity-100 opacity-0 transition-opacity duration-200 ease-in-out">
			<span class="material-icons-round text-2xl">
				play_circle_filled
			</span>
		</div>
	</a>

<?php endforeach; ?>
