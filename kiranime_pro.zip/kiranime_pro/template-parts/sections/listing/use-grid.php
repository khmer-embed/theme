<?php

$animes         = $args['animes'];
$is_archive     = isset( $args['is_archive'] ) ? $args['is_archive'] : false;
$usestatus      = get_option( '__u_status_i_du' );
$completed_slug = get_option( '__u_status_completed_slug', 'completed' );

foreach ( $animes as $anime ) :
	$anime->get_featured( type: KiraType::anime, size: 'kirathumb', attributes: [ 'class' => 'absolute inset-0 object-cover w-full h-full rounded shadow' ] )->gets( MetaPrefix::anime )->get_taxonomies( 'type', 'anime_attribute', 'status' );
	$current_status = isset( $anime->taxonomies['status'] ) ? $anime->taxonomies['status'] : [];
	$attr           = isset( $anime->taxonomies['anime_attribute'] ) ? $anime->taxonomies['anime_attribute'] : [];
	$latest         = $anime->get_episodes( is_latest: true, return: true );
	$latest_meta    = ! empty( $latest->meta['number'] );
	$current_type   = isset( $anime->taxonomies['type'] ) ? $anime->taxonomies['type'] : [];
	$meta           = $anime->meta;

	$en_title      = $anime->meta['english'] ?? '';
	$current_title = $anime->post->post_title;
	?>
	<div class="w-full bg-gradient-to-t from-primary to-transparent rounded overflow-hidden shadow shadow-primary">
		<div class="block relative w-full group kira-anime add-rem overflow-hidden">
			<?php
			if ( ! empty( $usestatus ) && ! empty( $current_status ) && ! is_wp_error( $current_status ) ) :
				if ( $completed_slug === $current_status[0]->slug ) :
					?>
					<div class="status_show" style="background-color: var(--completed-status)">
						<span><?php echo esc_html( $current_status[0]->name ); ?></span>
					</div>
					<?php
				endif;
			endif;
			?>
			<?php echo $anime->images['featured_html'] ?? ''; ?>

			<div class="absolute inset-0 top-1/4" style="
					background: linear-gradient(0deg, rgba(var(--overlay-color), 1) 0, rgba(42, 44, 49, 0) 76%);
				"></div>
			<div class="flex items-center justify-between pli-3 pbe2 absolute bottom-0 inset-x-0">
				<!-- attribute -->
				<?php if ( ! is_wp_error( $attr ) && count( $attr ) > 0 ) : ?>
					<div class="min-w-max">
						<span class="text-text-accent block bg-accent-2/80 h-[25px] rounded-md text-[11px] p-1 mie-px font-medium">
							<?php
							$a = array_map(
								function ( $val ) {
									return $val->name;
								},
								$attr
							);
							echo esc_html( implode( '/', $a ) );
							?>
						</span>
					</div>
				<?php endif; ?>
				<!-- episode -->
				<?php if ( ! empty( $current_type[0] ) && 'movie' !== $current_type[0]->slug ) : ?>
					<span class="text-[11px] pli-2 plb-1 rounded-md font-medium h-[25px] text-text-accent bg-accent-3 mis-auto">
					<?php /* Translators: Episode number */ printf( esc_attr__( 'E %s', 'kiranime' ), $latest_meta ? esc_html( $latest->meta['number'] ) : '?' ); ?>
					</span>
				<?php endif; ?>
			</div>
			<a 
			<?php
			if ( get_theme_mod( '__show_tooltip', 'show' ) === 'show' ) :
				?>
				data-tippy-trigger data-tippy-content-to="<?php echo esc_attr( $anime->id ); ?>" <?php endif; ?> href="<?php echo esc_url( $anime->url ); ?>" class="group-hover:bg-opacity-75 bg-overlay hidden group-hover:flex items-center justify-center absolute inset-0">
				<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512" class="w-8 h-8">
					<path fill="currentColor" d="M424.4 214.7L72.4 6.6C43.8-10.3 0 6.1 0 47.9V464c0 37.5 40.7 60.1 72.4 41.3l352-208c31.4-18.5 31.5-64.1 0-82.6z" />
				</svg>
			</a>
			<?php if ( str_contains( $meta['rate'] ?? '', '18' ) ) : ?>
				<span class="bg-error-1 text-text-color text-xs font-semibold pli-2 plb-1 rounded-md absolute top-2 end-2">
					18+
				</span>
			<?php endif; ?>
		</div>

		<div style="min-height: 4.906rem" class="flex h-auto md:h-24 lg:h-24 flex-col justify-between p-2 bg-overlay relative">
			<!-- Title -->
			<?php echo $is_archive ? '<h2>' : '<h3>'; ?>
			<a href="<?php echo $anime->url; ?>" class="text-sm line-clamp-2 font-medium leading-snug lg:leading-normal">
				<?php if ( ! empty( $en_title ) ) : ?>
					<span data-en-title><?php echo esc_html( $en_title ); ?></span>
					<span data-nt-title class="show"><?php echo esc_html( $current_title ); ?></span>
				<?php else : ?>
					<?php echo esc_html( $current_title ); ?>
				<?php endif; ?>
			</a>
			<?php echo $is_archive ? '</h2>' : '</h3>'; ?>

			<!-- type and length -->
			<div class="text-xs text-text-color w-full line-clamp-1 absolute bottom-1 text-opacity-75">
				<span class="inline-block md:mlb-3 uppercase"><?php echo esc_html( ! is_wp_error( $current_type ) && count( $current_type ) > 0 ? $current_type[0]->name : 'TV' ); ?></span>
				<span class="inline-block bg-gray-600 w-1 h-1 mli-2"></span>
				<span class="inline-block md:mlb-3">
				<?php /* Translators: Anime duration */ printf( esc_attr__( '%sM', 'kiranime' ), number_format_i18n( absint( preg_replace( '/[^0-9]/mi', '', $meta['duration'] ?? '24' ) ) ) ); ?>
				</span>
			</div>
		</div>
	</div>
<?php endforeach; ?>
