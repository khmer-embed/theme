<?php
$dataposts = $args['posts'];

?>

<div class="w-full news-listing">
	<?php
	foreach ( $dataposts as $data ) {
		$news  = new Kiranime_News( $data->ID );
		$thumb = $news->thumbnail( 'kirathumb' );
		$tags  = wp_get_post_tags( $data->ID );
		?>
		<div class="flex mbe-5 bg-tertiary p-3 rounded shadow-md gap-5 cursor-pointer" onclick="(()=>{location.href='<?php the_permalink( $data->ID ); ?>'})()">
			<div class="flex-[80px] w-20 h-20 rounded-full flex-shrink-0 overflow-hidden">
				<?php echo $thumb; ?>
			</div>
			<div class="flex-[100%] flex-shrink-0 flex-grow" style="max-width: calc(100% - 6rem);">
				<h3 style="display: -webkit-box;-webkit-box-orient: vertical;overflow: hidden;-webkit-line-clamp: 2;">
					<a href="<?php the_permalink( $data->ID ); ?>"><?php echo esc_html( $data->post_title ); ?></a>
				</h3>
				<div class="post-meta text-sm">
					<?php if ( is_wp_error( $tags ) || empty( $tags ) ) : ?>
						<span>Posted:</span> <?php echo esc_html( $data->post_date ); ?>
					<?php else : ?>
						<?php
						$arr = array_slice( $tags, 0, 2 );
						foreach ( $arr as $datatag ) :
							?>
							<a href="<?php echo get_term_link( $datatag, 'post_tag' ); ?>" class="post-tags"><?php echo esc_html( $datatag->name ); ?></a>
						<?php endforeach; ?>
					<?php endif; ?>
				</div>
			</div>
		</div>

	<?php } ?>
</div>
