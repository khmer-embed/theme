<?php
$title = $args['title'];
?>
<section class="mbe-6 mbs-5 md:mbs-0">
	<div class="w-full mbe-4 flex items-center justify-between plb-2 sm:pli-0">
		<div class="mie-4">
			<h2 class="text-lg lg:text-xl xl:text-2xl leading-10 font-semibold p-0 m-0 text-accent">
				<?php echo $title; ?>
			</h2>
		</div>
	</div>
	<div id="scheduled-anime" class="bg-overlay rounded-t-md shadow drop-shadow-sm"></div>
</section>
