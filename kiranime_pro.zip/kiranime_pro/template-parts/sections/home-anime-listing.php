<?php
$title     = $args['title'];
$query     = new Kira_Query( $args['query'], 'anime' );
$slider    = $args['slider'];
$link      = $args['archive'];
$loop      = $args['loop'];
$type      = str_replace( ' ', '-', preg_replace( '/[^0-9a-zA-Z\s]+$/', '', strtolower( $title ) ) );
$is_widget = isset( $args['is_widget'] ) ? $args['is_widget'] : false;

?>

<?php if ( ! $query->empty ) : ?>
	<section class="mbe-6 mbs-5 md:mbs-0">
		<div class="w-full sm:mbe-4 flex md:items-center justify-between flex-row plb-2 sm:pli-0">
			<div class="mie-4">
				<h2 class="text-lg lg:text-xl xl:text-2xl leading-10 font-semibold p-0 m-0 text-accent">
					<?php echo $title; ?>
				</h2>
			</div>
			<div class="text-sm font-normal text-opacity-75 flex items-center justify-between gap-5">
				<?php if ( $slider ) : ?>
					<div class="swiper-navigation navigate-section hidden navigate-<?php echo $type; ?> sm:flex items-center justify-between gap-1 w-max">
						<div class="navigate-<?php echo $type; ?>-prev rtl:rotate-180 flex items-center justify-center cursor-pointer group plb-1 pli-2 rounded-l hover:bg-accent-2 hover:text-text-color">
							<span class="material-icons-round text-xl lg:text-2xl">
								navigate_before
							</span>
						</div>
						<div class="navigate-<?php echo $type; ?>-next rtl:rotate-180 flex items-center cursor-pointer group plb-1 pli-2 rounded-r hover:bg-accent-2 hover:text-text-color">
							<span class="material-icons-round text-xl lg:text-2xl">
								navigate_next
							</span>
						</div>
					</div>
				<?php endif; ?>
				<a class="flex items-center justify-end gap-1 text-xs" href="<?php echo $link; ?>">
					<?php _e( 'View More', 'kiranime' ); ?>
					<span class="material-icons-round text-xl rtl:hidden">
						navigate_next
					</span>
				</a>
			</div>
		</div>
		<?php if ( ! $slider ) : ?>
			<section class="kira-grid-listing mli-auto plb-2 md:pli-0 w-full flex-auto !gap-2 md:!gap-4">
				<?php
				get_template_part(
					'template-parts/sections/listing/use',
					'grid',
					[
						'animes' => $query->animes,
					]
				);
				?>
			</section>
		<?php else : ?>
			<section class="mli-auto w-full flex-auto plb-2 md:pli-0 overflow-hidden">
				<div data-current-slider="<?php echo $type; ?>" data-is-loop="<?php echo $loop ? '1' : '0'; ?>" class="swiper swiper-sections swiper-<?php echo $type; ?>">
					<div class="swiper-wrapper" style="min-width: 100vw;">
						<!-- Slides -->
						<?php
						get_template_part(
							'template-parts/sections/listing/use',
							'slider',
							[
								'animes' => $query->animes,
							]
						);
						?>
					</div>
				</div>
			</section>
		<?php endif; ?>
	</section>
<?php endif; ?>
