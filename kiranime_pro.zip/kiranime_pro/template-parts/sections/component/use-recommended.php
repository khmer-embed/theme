<?php

$current_id = intval( $args['id'] );
$display    = get_theme_mod( '__show_related_' . $args['post_type'] . '_display', 'grid' );
$obsf       = base64_encode(
	json_encode(
		[
			'id'        => $current_id,
			'post_type' => $args['post_type'],
			'display'   => $display,
		]
	)
);
?>
<section>
	<div data-lazy-load-components-id='<?php echo $obsf; ?>' data-component-name="recommended" style="height: 20rem;">
		<?php get_template_part( 'template-parts/sections/component/use', 'loader' ); ?>
	</div>
</section>
