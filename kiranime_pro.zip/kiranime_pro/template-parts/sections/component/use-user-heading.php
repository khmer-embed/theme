<?php

$is_public = isset( $args['public'] ) ? intval( $args['public'] ) !== get_current_user_id() : false;
$menus     = Kira_Utility::get_user_menu( $is_public );

if ( $is_public ) {
	$user_info = get_userdata( $args['public'] );
} else {
	$user_info = get_userdata( get_current_user_id() );
}

$display_name = $user_info->display_name;
?>
<section class="bg-overlay relative pbs-6 md:pbs-17 lg:mbs-5 lg:mbe-5">
	<div class="absolute inset-0 bg-cover blur-xl opacity-30 bg-center z-0 overflow-hidden" data-profile-background>
		<?php echo Kira_User::get_avatar( $user_info->ID, [ 'class' => 'absolute inset-0 w-full h-auto object-cover' ] ); ?>
	</div>
	<div class="container relative z-10">
		<div class="avatar-show flex items-center justify-center mlb-4">
			<?php echo Kira_User::get_avatar( $user_info->ID, [ 'class' => 'w-[72px] h-[72px] rounded-full' ] ); ?>
		</div>
		<h1 class="w-full block text-3xl font-medium text-center mbe-4 leading-relaxed">
			<?php echo esc_html( ucfirst( $display_name ) ); ?></h1>
		<ul class="flex items-center justify-center gap-4 h-12">
			<?php
			foreach ( $menus as $current_menu ) :
				if ( $current_menu['link'] ) :
					?>
					<li class="w-max h-auto">
						<a href="<?php echo $current_menu['link']; ?>" class="pli-4 plb-3 flex items-center gap-2  
											<?php
											$l = get_bloginfo( 'url' ) . ( $_SERVER['REQUEST_URI'] ?? '' );
											echo $l === $current_menu['link'] ? 'text-accent border-b-2 border-accent' : '';
											?>
											" title="<?php echo esc_html( $current_menu['name'] ); ?>">
							<span class="material-icons-round text-xl">
												<?php echo $current_menu['icon']; ?>
							</span>
							<span class="hidden lg:inline-block">
												<?php echo esc_html( $current_menu['name'] ); ?>
							</span>
						</a>
					</li>
							<?php
			endif;
			endforeach;
			?>
		</ul>
	</div>
</section>
