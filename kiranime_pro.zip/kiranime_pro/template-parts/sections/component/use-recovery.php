<div class="relative z-50 h-auto p-8 pli-10 overflow-hidden bg-primary rounded-md plb-7 w-full container lg:max-w-md md:max-w-xs">
	<input type="hidden" name="recovery_nonce" value="<?php echo wp_create_nonce( 'ajax-recovery-nonce' ); ?>">
	<h3 class="mbe-6 text-2xl font-medium text-center"><?php esc_html_e( 'Reset Password', 'kiranime' ); ?></h3>
	<input type="text" name="userlogin" class="block w-full plb-3 pli-4 mbe-4 text-sm border  border-transparent rounded-lg focus:ring focus:ring-accent-2 focus:outline-none text-primary" placeholder="Email or username">
	<input type="password" data-input-recovery-verification name="verification_code" class="hidden w-full plb-3 pli-4 mbe-4 text-sm border  border-transparent rounded-lg focus:ring focus:ring-accent-2 focus:outline-none text-primary" placeholder="Verification code">
	<input type="password" data-input-recovery-verification name="new_password_recovery" class="hidden w-full plb-3 pli-4 mbe-4 text-sm border  border-transparent rounded-lg focus:ring focus:ring-accent-2 focus:outline-none text-primary" placeholder="New Password">
	<input type="password" data-input-recovery-verification name="repeat_password_recovery" class="hidden w-full plb-3 pli-4 mbe-4 text-sm border  border-transparent rounded-lg focus:ring focus:ring-accent-2 focus:outline-none text-primary" placeholder="Repeat Password">
	<div class="captcha-placement data-recovery-template" style="width: -webkit-fill-available;
	transform: scale(0.9);
	display: flex;
	align-items: center;
	justify-content: center;
	margin-bottom: 1rem;"></div>
	<div class="block">
		<button data-recovery-button class="w-full plb-2 pli-3 text-sm font-medium text-text-color bg-accent-3 rounded-lg">
			<?php esc_html_e( 'Get Verification Code', 'kiranime' ); ?>
		</button>
		<button data-reset-button class="hidden w-full plb-2 pli-3 text-sm font-medium text-text-color bg-accent-3 rounded-lg">
			<?php esc_html_e( 'Save', 'kiranime' ); ?>
		</button>
	</div>
	<p data-recovery-error-info class="w-full mbs-4 text-sm text-center text-error"></p>
	<div class="flex align-center justify-center gap-4">
		<button data-kiranime-modal="data-register-template" class="text-accent-2 underline"><?php esc_html_e( 'Sign up here', 'kiranime' ); ?></button>
		<div class="w-1 h-full bg-primary"></div>
		<button data-kiranime-modal="data-login-template" class="text-accent-2 underline"><?php esc_html_e( 'Log in here', 'kiranime' ); ?></button>
	</div>

</div>
