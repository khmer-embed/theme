<div class="relative z-50 h-auto p-8 pli-10 overflow-hidden bg-primary rounded-lg plb-7">
	<?php if ( get_option( 'users_can_register' ) ) : ?>
		<input type="hidden" name="register_nonce" value="<?php echo wp_create_nonce( 'ajax-register-nonce' ); ?>">
		<h3 class="mbe-6 text-2xl font-medium text-center"><?php esc_html_e( 'Register New Account', 'kiranime' ); ?></h3>
		<input type="text" name="register_username" class="block w-full plb-3 pli-4 text-sm mbe-4 border  border-transparent rounded-lg focus:ring focus:ring-accent-2 focus:outline-none text-primary" placeholder="Username">
		<input type="email" name="register_email" class="block w-full plb-3 pli-4 text-sm mbe-4 border  border-transparent rounded-lg focus:ring focus:ring-accent-2 focus:outline-none text-primary" placeholder="Email">
		<input type="password" name="register_password" autocomplete="off" class="block w-full plb-3 pli-4 text-sm mbe-4 border  border-transparent rounded-lg focus:ring focus:ring-accent-2 focus:outline-none text-primary" placeholder="Password">
		<input type="password" name="register_confirm_password" autocomplete="off" class="block w-full plb-3 pli-4 text-sm mbe-4 border  border-transparent rounded-lg focus:ring focus:ring-accent-2 focus:outline-none text-primary" placeholder="Confirm Password">
		<div class="captcha-placement data-register-template" style="width: -webkit-fill-available;
	transform: scale(0.9);
	display: flex;
	align-items: center;
	justify-content: center;
	margin-bottom: 1rem;"></div>
		<div class="block">
			<button data-register-button class="w-full plb-2 pli-3 text-sm font-medium text-text-color bg-accent-3 rounded-lg">
				<?php esc_html_e( 'Sign up', 'kiranime' ); ?>
			</button>
		</div>
		<p data-register-error-info class="w-full mbs-4 text-sm text-center text-error"></p>
		<p class="w-full mbs-4 text-sm text-center text-accent">
			<?php esc_html_e( 'Already have an account?', 'kiranime' ); ?>
			<button data-kiranime-modal="data-login-template" class="text-accent-2 underline">
				<?php esc_html_e( 'Log in here', 'kiranime' ); ?>
			</button>
		</p>
	<?php else : ?>
		<p class="w-full mbs-4 text-[13px] font-semibold text-center text-error">
			<?php esc_html_e( 'Registration is currently disabled by Administrator. If you already have an account', 'kiranime' ); ?>,
			<button data-kiranime-modal="data-login-template" class="text-accent-2 underline"><?php esc_html_e( 'Log in here', 'kiranime' ); ?></button>.
		</p>
	<?php endif; ?>
</div>
