<?php
$downloads = ! empty( $args['downloads'] ) ? ( is_string( $args['downloads'] ) ? json_decode( $args['downloads'], true ) : $args['downloads'] ) : [];
$downloads = array_map( fn ( $val ) => is_object( $val ) ? json_decode( json_encode( $download ), true ) : $val, $downloads );
if ( ! empty( $downloads ) && $downloads[0] && $downloads[0]['resolution'] ) :
	?>
	<section class="download-section">
		<h3 class="download-section-title"><?php _e( 'Downloads', 'kiranime' ); ?></h3>
		<div class="download-section-lists">
			<?php
			foreach ( $downloads as $download ) :
				if ( $download['resolution'] ) :
					?>
					<div class="download-section-item">
						<div class="download-section-item-res">
							<?php echo $download['resolution']; ?>
						</div>
						<div class="download-section-item-data">
							<?php foreach ( $download['data'] as $link ) : ?>
								<a class="download-section-item-link" href="<?php echo esc_url( $link['url'] ); ?>" target="_blank" rel="nofollow"><?php echo esc_html( $link['provider'] ); ?></a>
							<?php endforeach; ?>
						</div>
					</div>
					<?php
			endif;
			endforeach;
			?>
		</div>
	</section>
<?php endif; ?>
