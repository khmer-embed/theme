<?php

$episode = $args['episode'] ?? null;

/**
 * Anime instance for current episode
 *
 * @var Anime $anime
 */
$anime = $args['anime'] ?? null;

if ( ! is_null( $episode ) ) :
	$players      = $episode->streams;
	$use_switcher = get_option( '__q_title_switcher', false );

	/**
	 * Array of episodes for the anime
	 *
	 * @var Episode[] $episode_lists
	 */
	$episode_lists      = ! empty( $anime->episodes ) ? array_reverse( json_decode( json_encode( $anime->episodes ), true ) ) : [];
	$episode_navigation = [
		'previous' => null,
		'next'     => null,
		'current'  => null,
	];

	if ( ( ! empty( $anime->taxonomies['status'][0]?->slug ) && 'airing' === $anime->taxonomies['status'][0]?->slug ) || ! empty( $anime->scheduled ) ) {
		$new_episode       = $episode_lists[ count( $episode_lists ) - 1 ];
		$last_episode_date = strtotime( $new_episode['post']['post_date_gmt'] );
		$default_schedule  = strtotime( '+7 days', $last_episode_date );

		$use_schedule = isset( $anime->scheduled->post->post_date_gmt )
			? strtotime( $anime->scheduled->post->post_date_gmt )
			: $default_schedule;

		$show_schedule = false;
		if ( $use_schedule ) {
			$show_schedule = time() < $use_schedule;
		}
	}
	foreach ( $episode_lists as $index => $ep ) {
		if ( $ep['meta']['number'] === $episode->meta['number'] ) {
			$episode_navigation['previous'] = 0 === $index ? null : $episode_lists[ $index - 1 ];
			$episode_navigation['next']     = is_countable( $episode_lists ) && ( count( $episode_lists ) - 1 ) === $index ? null : $episode_lists[ $index + 1 ];
			$episode_navigation['current']  = $ep;
			break;
		}
	}

	$f_player    = null;
	$player_data = [
		'sub' => [],
		'dub' => [],
	];

	$f_player_id = ! empty( $players[0] ) ? base64_encode( $players[0]['host'] . $players[0]['type'] ) : null;
	foreach ( $players as $index => $current ) {
		if ( $current['type'] ) {
			$p = [
				'name' => $current['host'],
				'id'   => base64_encode( $current['host'] . $current['type'] ),
				'url'  => base64_encode( $current['url'] ),
				'type' => $current['url_type'],
			];
			if ( ! $f_player ) {
				$f_player = $p;
			}
			$player_data[ $current['type'] ][] = $p;
		}
	}

	$is_movie = ! empty( $episode->taxonomies['episode_type'] )
		? 'movie' === $episode->taxonomies['episode_type'][0]->slug
		: ( ! empty( $anime?->taxonomies['type'] ) ? 'movie' === $anime?->taxonomies['type'][0]->slug : false );

	if ( empty( $players ) ) {
		$thumbnail = $episode->images['featured_html'];
	}

	$breadcrumbs = [
		[
			'url'  => '/',
			'name' => __( 'Home', 'kiranime' ),
		],
	];

	if ( $anime ) {
		if ( $anime->taxonomies['type'] ) {
			$breadcrumbs[] = [
				'url'  => get_term_link( $anime->taxonomies['type'][0] ),
				'name' => $anime->taxonomies['type'][0]->name,
			];
		}

		$breadcrumbs[] = [
			'url'  => $anime->url,
			'name' => $anime->post->post_title,
		];

		$anime->gets( MetaPrefix::anime );
	}

	$breadcrumbs[] = [
		'url'  => get_the_permalink(),
		'name' => get_the_title(),
	];
	?>
	<script>
		var episode_report =
			<?php
			echo json_encode(
				[
					'title' => $episode->post->post_title,
					'id'    => $episode->id,
					'url'   => site_url(),
				]
			);
			?>
			;
		var current_episode = "<?php echo ! empty( $episode->meta['number'] ) ? $episode->meta['number'] : get_the_title(); ?>";
	</script>
	<div class="episode-head <?php echo $is_movie || is_null( $anime ) ? 'is-movie' : ''; ?>" style="position: relative;z-index: 2;">
		<div class="episode-head-breadcrumb hidden lg:block <?php echo $is_movie || is_null( $anime ) ? 'xl:pli-12' : ''; ?>">
			<?php Kira_Utility::BreadCrumb( $breadcrumbs, function_exists( 'rank_math_the_breadcrumbs' ) ); ?>
		</div>
		<div class="episode-head-main-grid">
			<?php if ( ! $is_movie && ! is_null( $anime ) ) : ?>
				<!-- episode lists [only if anime is not movie] -->
				<div class="episode-head episode-list" style="min-height: 201.5px;">
					<div class="episode-list-search-box">
						<span><?php esc_html_e( 'Episode Lists', 'kiranime' ); ?></span>
						<label for="episode_number">
							<span class="material-icons-round">
								search
							</span>
							<input type="text" data-search-episode-from-list placeholder="<?php esc_html_e( 'Episode number', 'kiranime' ); ?>">
						</label>
					</div>
					<div class="w-full h-full flex items-center justify-center loading-lists">
						<?php get_template_part( 'template-parts/sections/component/use', 'loader' ); ?>
					</div>
					<div class="episode-list-display-box hidden">

						<?php
						foreach ( $episode_lists as $episode_item ) :
							$search_query = isset( $episode_item['meta']['number'] ) ? $episode_item['meta']['number'] : $episode_item['meta']['title'];
							if ( ! $search_query ) {
								$search_query = $episode_item['post']['post_title'];
							}
							?>
							<a href="<?php echo esc_url( $episode_item['url'] ); ?>" class="episode-list-display-box episode-list-item <?php echo get_the_ID() === $episode_item['id'] ? 'current-episode' : ''; ?>" data-episode-search-query="<?php echo esc_attr( $search_query ); ?>">
								<span class="episode-list-item-number">
									<?php echo esc_html( ! empty( $episode_item['meta']['number'] ) ? $episode_item['meta']['number'] : 0 ); ?>
								</span>
								<span class="episode-list-item-title">
									<?php echo esc_html( ! empty( $episode_item['meta']['title'] ) ? $episode_item['meta']['title'] : $episode_item['post']['post_title'] ); ?>
								</span>
							</a>
						<?php endforeach; ?>
					</div>
				</div>
				<!-- end episode lists -->
			<?php endif; ?>
			<!-- episode player area -->
			<div class="episode-head episode-player <?php echo $is_movie || is_null( $anime ) ? 'is-movie' : ''; ?>">
				<div class="episode-player-box <?php echo empty( $players ) ? 'no-player' : ''; ?> <?php echo isset( $f_episode_type ) && 'html' === $f_episode_type ? 'custom-element' : ''; ?>">

					<?php
					if ( $f_player ) :
						if ( 'html' === $f_player['type'] ) :
							echo base64_decode( $f_player['url'] );
						else :
							$decoded = base64_decode( $f_player['url'] );
							echo "<iframe src='{$decoded}' allow='accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share' allowfullscreen></iframe>";
						endif;
					else :
						echo isset( $thumbnail ) && ! empty( $thumbnail ) ? $thumbnail : $anime?->images['featured_html'];
					endif;
					?>

				</div>
				<div class="episode-player-tool">
					<div class="episode-player-tool start-side">
						<div class="start-side expand" data-expanded="0">
							<span data-expand-full class="material-icons-round text-2xl">
								fullscreen
							</span>
						</div>
						<div class="start-side report">
							<span class="material-icons-round text-lg"> report_problem </span>
							<span><?php esc_html_e( 'Report Problem', 'kiranime' ); ?></span>
						</div>
						<div class="start-side auto-next hidden">
							<input type="checkbox" name="auto_next" id="auto_next">
							<label for="auto_next"><?php esc_html_e( 'Auto Next', 'kiranime' ); ?></label>
						</div>
					</div>
					<div class="episode-player-tool end-side">
						<div class="end-side episode-navigation">
							<div data-open-nav-episode="<?php echo ! is_null( $episode_navigation['previous'] ) ? $episode_navigation['previous']['url'] : 'undefined'; ?>" class="episode-navigation previous-episode" style="<?php echo ! $episode_navigation['previous'] ? 'opacity: 0.5;' : ''; ?>">
								<span class="material-icons-round text-2xl rtl:rotate-180"> fast_rewind </span>
							</div>
							<div data-open-nav-episode="<?php echo ! is_null( $episode_navigation['next'] ) ? $episode_navigation['next']['url'] : 'undefined'; ?>" class="episode-navigation next-episode" style="<?php echo ! $episode_navigation['next'] ? 'opacity: 0.5;' : ''; ?>">
								<span class="material-icons-round text-2xl rtl:rotate-180"> fast_forward </span>
							</div>
						</div>
						<?php if ( $anime ) : ?>
							<div data-tippy-sub-trigger="<?php echo esc_attr( $anime->id ); ?>" class="end-side watchlist-button">
								<span class="material-icons-round text-2xl ">
									playlist_add_circle
								</span>
							</div>
						<?php endif; ?>
					</div>
				</div>
				<div class="episode-player-info">
					<div class="episode-player-info top-side">
						<div class="top-side episode-information">
							<span><?php esc_html_e( "You're watching", 'kiranime' ); ?></span>
							<span><?php echo $is_movie ? ( esc_html( $episode->meta['title'] ?? $episode->post->post_title ) ) : /* Translators: episode number. */ sprintf( esc_html__( 'Episode %d', 'kiranime' ), number_format_i18n( absint( $episode->meta['number'] ), 1 ) ); ?></span>
							<span><?php esc_html_e( 'If current player not working, select other server.', 'kiranime' ); ?></span>
						</div>
						<div class="top-side player-selection">
							<div class="player-selection player-sub flex-wrap">
								<span class="material-icons-round text-lg !inline-flex w-6 h-6 items-center justify-start"> closed_caption </span>
								<span class="!inline-flex w-9 h-6 items-center justify-start"><?php esc_html_e( 'SUB', 'kiranime' ); ?>:</span>
								<?php foreach ( $player_data['sub'] as $index => $sub ) : ?>
									<span data-embed-id="<?php echo $sub['id']; ?>:<?php echo $sub['url']; ?>" class="<?php echo $sub['id'] === $f_player_id ? 'active' : ''; ?> !inline-flex w-fit h-6 items-center justify-start">
										<?php echo esc_html( $sub['name'] ); ?>
									</span>
								<?php endforeach; ?>
							</div>
							<div class="player-selection player-dub">
								<span class="material-icons-round text-lg !inline-flex w-6 h-6 items-center justify-start"> mic </span>
								<span class="!inline-flex w-9 h-6 items-center justify-start"><?php esc_attr_e( 'DUB', 'kiranime' ); ?>:</span>
								<?php foreach ( $player_data['dub'] as $index => $dub ) : ?>
									<span data-embed-id="<?php echo $dub['id']; ?>:<?php echo $dub['url']; ?>" class="<?php echo $dub['id'] === $f_player_id ? 'active' : ''; ?> !inline-flex w-fit h-6 items-center justify-start">
										<?php echo esc_html( $dub['name'] ); ?>
									</span>
								<?php endforeach; ?>
							</div>
						</div>
					</div>
					<?php if ( ! empty( $use_schedule ) && ! empty( $show_schedule ) ) : ?>
						<div class="episode-player-info bottom-side">
							<div class="bottom-side next-scheduled-episode hidden">
								<span class="text-base mie-1">🚀</span>
								<span><?php esc_html_e( 'Estimated the next episode will come at', 'kiranime' ); ?></span>
								<span data-timezone="<?php echo wp_timezone_string(); ?>" data-countdown="<?php echo gmdate( 'Y-m-d H:i:s', $use_schedule ); ?>"></span>
							</div>
						</div>
					<?php endif; ?>
				</div>
			</div>
			<!-- end player area -->
			<!-- anime info -->
			<?php
			if ( $anime ) :
				$en_title      = $anime->meta['english'] ?? '';
				$current_title = $anime->post->post_title;
				?>
				<div class="episode-head episode-anime-info">
					<div class="anime-information">
						<div class="anime-featured">
							<?php echo $anime->images['featured_html'] ?: Kira_Utility::get_no_image(); ?>
						</div>
						<div class="anime-data">
							<h4>
								<a href="<?php echo esc_url( $anime->url ); ?>" title="<?php echo esc_attr( $anime->post->post_title ); ?>">
									<?php if ( ! empty( $en_title ) && ! empty( $use_switcher ) ) : ?>
										<span data-en-title class="line-clamp-2"><?php echo esc_html( $en_title ); ?></span>
										<span class="show line-clamp-2" data-nt-title><?php echo esc_html( $current_title ); ?></span>
									<?php else : ?>
										<span class="line-clamp-2"><?php echo esc_html( $current_title ); ?></span>
									<?php endif; ?>
								</a>
							</h4>
							<div class="anime-metadata">
								<?php
								if ( ! empty( $anime->meta['rate'] ) ) :
									$meta_rate = explode( ' ', $anime->meta['rate'] );
									?>
									<span><?php echo esc_html( $meta_rate[0] ); ?></span>
								<?php endif; ?>
								<?php
								if ( ! empty( $anime->taxonomies['anime_attribute'] ) ) :
									foreach ( $anime->taxonomies['anime_attribute'] as $attr ) :
										?>
										<span><?php echo esc_html( $attr->name ); ?></span>
																	<?php
									endforeach;
								endif;
								?>
								<?php
								if ( ! empty( $anime->taxonomies['type'] ) ) :
									foreach ( $anime->taxonomies['type'] as $current_type ) :
										?>
										<span><?php echo esc_html( $current_type->name ); ?></span>
																	<?php
								endforeach;
								endif;
								?>
								<span>
								<?php /* Translators: Anime duration */ printf( esc_attr__( '%sM', 'kiranime' ), number_format_i18n( absint( preg_replace( '/[^0-9]/mi', '', $anime->meta['duration'] ?? '24' ) ), 1 ) ); ?>
								</span>
							</div>
							<div class="anime-synopsis">
								<?php $info_ads = get_option( '__ads_replace_content_episode', false ); if ( ! empty( $info_ads ) ) : ?>
									<?php echo $info_ads; ?>
								<?php else : ?>
									<div class="anime-synopsis synopsis-content">
										<p>
											<?php echo wp_kses_post( $anime->post->post_content ); ?>
										</p>
									</div>
								<?php endif; ?>
							</div>
						</div>
					</div>
					<div class="anime-score-box">
						<div class="anime-score-header">
							<div class="anime-score-counts">
								<span class="material-icons-round star-icon">
									star
								</span>
								<span>
									<?php echo number_format_i18n( absint( empty( $anime->vote['vote_score'] ) ? 0 : floatval( $anime->vote['vote_score'] ) * 2 ) ); ?>
								</span>
								<span>
									<?php
									/* translators: number of voted users */
									printf( __( '( %d Voted)', 'kiranime' ), number_format_i18n( absint( empty( $anime->vote['voted'] ) ? 0 : $anime->vote['voted'] ) ) )
									?>
									</span>
							</div>
							<span>
								<?php esc_html_e( 'Vote Now!', 'kiranime' ); ?>
							</span>
						</div>
						<?php if ( empty( $anime->vote['status'] ) ) : ?>
							<span class="anime-score-rate-this">
								<?php esc_html_e( 'Rate this anime!', 'kiranime' ); ?>
							</span>
						<?php endif; ?>
						<div class="anime-score-emoticons 
						<?php
						if ( ! empty( $anime->vote['status'] ) ) :
							echo 'voted';
															endif;
						?>
															">
							<?php foreach ( $anime->vote['html'] as $index => $emoticon ) : ?>
								<div data-vote-note="<?php echo $index; ?>" class="<?php echo $anime->vote['status'] ? ( empty( $anime->vote['vote_data'] ) ? 'not-voted' : ( $anime->vote['vote_data']['value'] === $index ? 'selected' : 'not-voted' ) ) : 'not-voted'; ?>">
									<?php echo $emoticon; ?>
								</div>
							<?php endforeach; ?>
						</div>
					</div>
				</div>
			<?php endif; ?>
			<!-- end anime info -->
		</div>
	</div>
	<div class="hidden episode-modal-report">
		<div class="modal-inner">
			<div class="modal-header">
				<h5><?php esc_html_e( 'Please explain the problem you found on this episode.', 'kiranime' ); ?></h5>
			</div>
			<div class="modal-body">
				<textarea id="report-value" rows="4" class="pli-2 w-full text-sm text-white bg-secondary border-0 focus:ring-0" required="true"></textarea>
			</div>
			<div class="modal-footer">
				<div class="flex justify-end items-center gap-5 plb-2">
					<button data-report-cancel class="inline-flex items-center plb-2 pli-4 text-xs font-medium text-center text-white bg-error-1 rounded-lg focus:ring-2 focus:ring-error hover:bg-error-2">
						<?php esc_html_e( 'Cancel', 'kiranime' ); ?>
					</button>
					<button data-report-the-problem class="inline-flex items-center plb-2 pli-4 text-xs font-medium text-center text-white bg-accent-3 rounded-lg focus:ring-2 focus:ring-accent hover:bg-accent-4">
						<?php esc_html_e( 'Submit', 'kiranime' ); ?>
					</button>
				</div>
			</div>
		</div>
	</div>
	<?php
endif;
