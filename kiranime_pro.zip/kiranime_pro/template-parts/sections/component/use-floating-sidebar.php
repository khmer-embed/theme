<!-- overlay for menu sidebar when active -->
	<div data-sidebar-overlay class="hidden fixed inset-0 bg-primary bg-opacity-50 z-39"></div>

	<!-- Menu sidebar -->
	<div data-sidebar class="<?php echo is_admin_bar_showing() ? 'pbs-[2.875rem] lg:pbs-8' : ''; ?> w-full max-w-xs lg:w-72 fixed inset-0 transform -translate-x-full rtl:translate-x-full transition-transform duration-150 ease-in-out h-full bg-primary z-999 overflow-y-auto overflow-x-hidden">
		<div data-sidebar-closer class="cursor-pointer pli-4 plb-2 rounded-full w-max max-w-max flex items-center gap-3 bg-white bg-opacity-20 font-medium text-sm mlb-5 mli-3">
			<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512" class="w-4 h-4 rtl:rotate-180">
				<path fill="currentColor" d="M257.5 445.1l-22.2 22.2c-9.4 9.4-24.6 9.4-33.9 0L7 273c-9.4-9.4-9.4-24.6 0-33.9L201.4 44.7c9.4-9.4 24.6-9.4 33.9 0l22.2 22.2c9.5 9.5 9.3 25-.4 34.3L136.6 216H424c13.3 0 24 10.7 24 24v32c0 13.3-10.7 24-24 24H136.6l120.5 114.8c9.8 9.3 10 24.8.4 34.3z" />
			</svg>
		</div>
		<div data-default-header class="mbs-5 min-h-full">
			<?php
			if ( has_nav_menu( 'header_side' ) ) :
				wp_nav_menu(
					[
						'theme_location'  => 'header_side',
						'container_class' => 'w-full p-2',
						'menu_class'      => 'flex flex-col text-sm p-0 m-0 menu-header-side',
					]
				);
		endif
			?>
			<div class="mbs-5 border-t border-secondary">
				<?php get_template_part( 'template-parts/sections/component/use', 'genre' ); ?>
			</div>
		</div>
	</div>
