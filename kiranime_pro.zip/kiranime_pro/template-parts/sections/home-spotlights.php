<?php

$cache  = new Kiranime_Cache( 'widget_block' );
$cached = $cache->get( 'spotlight_data' );

if ( $cached ) {
	echo $cached;
} else {

	$query = new Kira_Query();
	$q     = $query->spotlight();
	ob_start();
	?>
<div class="w-full md:mbs-[50px] lg:mbs-0 sm:mbe-5 bg-accent-2 bg-opacity-0 flex items-center relative justify-center h-[75svw] sm:h-[45svh] lg:h-auto">
	<div class="swiper swiper-spotlight ">
		<!-- Additional required wrapper -->
		<div class="swiper-wrapper">
			<!-- Slides -->
			<?php

			if ( ! $q->empty ) :
				foreach ( $q->animes as $dx => $anime ) :
					$anime
						->gets( MetaPrefix::anime )
						->get_background(
							type: KiraType::anime,
							attr: [
								'alt'   => $anime->post->post_title,
								'class' => 'opacity-60 w-full h-full blur-0',
							],
							size: 'spotlight_thumb'
						)
										->get_taxonomies( 'type', 'anime_attribute' )
										->get_episodes( true );

					if ( empty( $anime->images['background_html'] ) ) {
						$anime->get_featured(
							type: KiraType::anime,
							attributes: [
								'class' => 'opacity-60 w-full h-full',
								'alt'   => $anime->post->post_title,
							],
							size: 'full'
						);
					}
									$meta          = $anime->meta;
									$current_type  = isset( $anime->taxonomies['type'][0] ) ? $anime->taxonomies['type'] : null;
									$attr          = isset( $anime->taxonomies['anime_attribute'][0] ) ? $anime->taxonomies['anime_attribute'] : null;
									$latest        = ! empty( $anime->episodes ) ? $anime->episodes[0] : [];
									$index         = $dx + 1;
									$current_title = $anime->post->post_title;
									$en_title      = $anime->meta['english'] ?? '';
					?>
					<div class="swiper-slide">
						<div class="w-full h-full absolute inset-0">
							<div class="w-full h-full absolute inset-0 overflow-hidden">
								<div class="after:absolute after:inset-0 w-full h-full z-[2] image-spotlight relative <?php echo empty( $anime->images['background_html'] ) ? ' ' : 'image-background'; ?>">
									<?php if ( empty( $anime->images['background_html'] ) ) : ?>
										<div class="bg-filler">
											<?php echo $anime->images['featured_html']; ?>
										</div>
										<div class="w-[55%] lg:w-[35%] inline-start-[45%] lg:inline-start-[60%] image-featured relative">
											<?php echo $anime->images['featured_html']; ?>
										</div>
									<?php else : ?>
										<?php echo $anime->images['background_html']; ?>
									<?php endif; ?>
									<div class="altering"></div>
								</div>
							</div>
							<div class="pie-16 sm:pie-24 pis-4 block-end-8 w-full lg:w-8/12 max-w-[800px] top-1/2 -translate-y-1/2 lg:-translate-y-1/4 absolute z-[3] lg:block-end-10 lg:pis-10">
								<div class="text-xs mbe-3 sm:text-sm lg:text-lg text-accent rtl:hidden">#<?php echo number_format_i18n( $index ); ?> <?php echo esc_html_e( 'Spotlight', 'kiranime' ); ?>
								</div>
								<a href="<?php echo esc_url( $anime->url ); ?>">
									<h2 class="text-base sm:text-lg md:text-2xl xl:text-5xl xl:font-bold max-h-36 lg:leading-relaxed font-semibold mbe-5">
										<?php if ( ! empty( $en_title ) ) : ?>
											<span data-en-title class="line-clamp-2"><?php echo esc_html( $en_title ); ?></span>
											<span data-nt-title class="show line-clamp-2"><?php echo esc_html( $current_title ); ?></span>
										<?php else : ?>
											<span class="line-clamp-2"> <?php echo esc_html( $current_title ); ?></span>

										<?php endif; ?>
									</h2>
								</a>
								<div class="hidden md:flex items-center justify-start gap-4 text-sm font-normal mbe-2.5 h-7 text-gray-300">
									<div class="uppercase flex items-center gap-1">
										<span class="material-icons-round">
											play_circle
										</span> 
										<?php
										if ( ! is_wp_error( $current_type ) && ! empty( $current_type ) ) {
													echo esc_html( $current_type[0]->name );
										}
										?>
									</div>
									<div class=" flex items-center gap-1">
										<span class="material-icons-round">
											watch_later
										</span>
										<?php /* Translators: Anime duration */ printf( esc_attr__( '%sM', 'kiranime' ), number_format_i18n( absint( preg_replace( '/[^0-9]/mi', '', $meta['duration'] ?? '24' ) ) ) ); ?>
									</div>
									<div class="flex items-center gap-1">
										<span class="material-icons-round">
											event
										</span>
														<?php echo esc_html( ! empty( $meta['aired'] ) ? trim( $meta['aired'] ) : $meta['premiered'] ); ?>
									</div>

									<div class="flex items-center gap-1">
														<?php
														if ( ! is_wp_error( $attr ) && ! empty( $attr ) ) :
															foreach ( $attr as $att ) :
																?>
												<span class="quality odd:bg-accent even:bg-white rounded pli-1 plb-0.5 text-gray-900 text-xs font-semibold">
																<?php echo esc_html( $att->name ); ?>
												</span>
																<?php
														endforeach;
														endif;
														?>
									</div>
								</div>
								<div class="text-[13px] leading-5 mbe-4 line-clamp-2 md:mbe-8 md:leading-6 text-gray-300">
													<?php echo strip_tags( $anime->post->post_content ); ?>
								</div>
								<div class="flex items-center justify-start gap-2.5">
									<a href="<?php echo isset( $latest->url ) ? $latest->url : $anime->url; ?>" class="pli-6 plb-2 bg-accent-2 hover:bg-accent rounded-full flex items-center gap-2 text-xs lg:text-sm font-medium">
										<span class="material-icons-round font-medium text-xl">
											play_circle
										</span>
										<span><?php esc_html_e( 'Watch Now', 'kiranime' ); ?></span>
													</a>
									<a href="<?php echo $anime->url; ?>" class="pli-6 plb-2 bg-secondary hover:brightness-105 rounded-full flex items-center gap-1 text-xs lg:text-sm font-medium">
										<span class="rtl:order-2"><?php esc_html_e( 'Detail', 'kiranime' ); ?></span>
									<span class="material-icons-round rtl:order-1 font-medium text-2xl">
											navigate_next
										</span>
									</a>
								</div>
							</div>
						</div>
					</div>
									<?php
				endforeach;
			endif;
			?>
		</div>
		<div class="swiper-navigation absolute bottom-5 end-5 z-10 hidden sm:block">
			<div class="mbe-2 bg-primary rounded-sm shadow-sm p-2 nav-next hover:bg-accent-3 rtl:rotate-180" tabindex="0" role="button" aria-label="Next slide">
				<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 192 512" class="w-6 h-6">
					<path fill="currentColor" d="M187.8 264.5L41 412.5c-4.7 4.7-12.3 4.7-17 0L4.2 392.7c-4.7-4.7-4.7-12.3 0-17L122.7 256 4.2 136.3c-4.7-4.7-4.7-12.3 0-17L24 99.5c4.7-4.7 12.3-4.7 17 0l146.8 148c4.7 4.7 4.7 12.3 0 17z" />
				</svg>
			</div>
			<div class="bg-primary rounded-sm shadow-sm p-2 nav-prev hover:bg-accent-3 rtl:rotate-180" tabindex="0" role="button" aria-label="Previous slide">
				<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 192 512" class="w-6 h-6">
					<path fill="currentColor" d="M4.2 247.5L151 99.5c4.7-4.7 12.3-4.7 17 0l19.8 19.8c4.7 4.7 4.7 12.3 0 17L69.3 256l118.5 119.7c4.7 4.7 4.7 12.3 0 17L168 412.5c-4.7 4.7-12.3 4.7-17 0L4.2 264.5c-4.7-4.7-4.7-12.3 0-17z" />
				</svg>
			</div>
		</div>
		<div class="spotlight-pagination swiper-pagination"></div>

	</div>
</div>
	<?php
	$cached = ob_get_clean();
	$cache->set( 'spotlight_data', $cached );
	echo $cached;
} ?>
