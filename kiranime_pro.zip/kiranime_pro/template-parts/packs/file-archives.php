<?php
$sidebar   = is_active_sidebar( 'archive-sidebar' );
$data      = $args['data'];
$max_pages = $data->pages;
?>

<?php if ( get_theme_mod( '__show_share_button', 'show' ) === 'show' ) : ?>
<div class="mbs-17 inline-block mbe-5 bg-darkest w-full">
	<div class="pli-4">
		<div class="pli-5 plb-0 relative flex items-center gap-5">
			<div class="block text-xs pis-5 plb-1 relative border-s-2 border-accent">
				<span
					class="text-sm font-semibold text-accent"><?php /* translators: page name. */ printf( esc_html__( 'Share %1$s', 'kiranime' ), get_bloginfo( 'name' ) ); ?></span>
				<p class="mbe-0"><?php esc_html_e( 'to your friends!', 'kiranime' ); ?></p>
			</div>
			<?php Kira_Utility::show( 'template-parts/sections/component/use', 'share' ); ?>
		</div>
	</div>
</div>
<?php else : ?>
<div class="mbs-17"></div>
<?php endif; ?>
<section class="mbe-17 grid grid-cols-12 plb-5 mli-auto w-full gap-5">
	<section class="col-span-full <?php echo $sidebar ? 'lg:col-span-9' : ''; ?>">
		<h1 class="mbe-4 text-2xl font-semibold leading-10 text-accent"><?php echo esc_html( $args['title'] ); ?></h1>
		<section
			class="grid grid-anime-auto-archive gap-2 sm:gap-4 justify-evenly w-11/12 mli-auto md:w-full flex-auto">
			<?php
			Kira_Utility::show(
				'template-parts/sections/listing/use',
				'grid',
				[
					'animes'     => $data->animes,
					'is_archive' => true,
				]
			);
			?>
		</section>
		<?php
		echo paginate_links(
			[
				'base'         => str_replace( 999999999, '%#%', esc_url( get_pagenum_link( 999999999 ) ) ),
				'total'        => $max_pages,
				'current'      => max( 1, get_query_var( 'paged' ) ),
				'format'       => '?paged=%#%',
				'show_all'     => false,
				'type'         => 'list',
				'end_size'     => 2,
				'mid_size'     => 1,
				'prev_next'    => false,
				'add_args'     => false,
				'add_fragment' => '',
			]
		);
		?>
	</section>
	<?php if ( $sidebar ) : ?>
	<aside class="col-span-full lg:col-span-3 ">
		<?php dynamic_sidebar( 'archive-sidebar' ); ?>
	</aside>
	<?php endif; ?>
</section>
