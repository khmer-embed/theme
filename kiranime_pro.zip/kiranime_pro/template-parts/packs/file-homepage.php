<!-- Spotlight Start -->
<?php if ( get_theme_mod( '__show_spotlight', 'show' ) === 'show' ) :
	Kira_Utility::show( 'template-parts/sections/home', 'spotlights' );
endif; ?>
<!-- Spotlight End -->
<!-- Trending Start -->
<?php
if ( get_theme_mod( '__show_trending', 'show' ) === 'show' ) :
	Kira_Utility::show( 'template-parts/sections/home', 'trendings' );
endif;
?>
<!-- Trending End -->
<!-- after trending ads -->
<?php do_action( 'kiranime_show_ads', '__ads_after_trending' ); ?>
<!-- end trending ads -->
<!-- Share button if enabled -->
<?php if ( get_theme_mod( '__show_share_button', 'show' ) === 'show' ) : ?>
	<div class="w-full lg:pli-5 plb-5 bg-secondary bg-opacity-100 md:flex gap-5 items-end mbe-9">
		<div class="w-full text-center pbe-4 md:pbe-0 md:w-max md:text-start md:pis-5 before:absolute before:hidden lg:before:block before:inset-0 before:h-full before:w-0.5 before:bg-accent-3 relative">
			<span class="text-sm font-semibold block text-accent">
				<?php /* translators: page name. */ printf( esc_attr__( 'Share %1$s', 'kiranime' ), get_bloginfo( 'name' ) ); ?>
			</span>
			<span class="block text-xs font-light">
				<?php esc_html_e( 'to your friends!', 'kiranime' ); ?>
			</span>
		</div>
		<?php Kira_Utility::show( 'template-parts/sections/component/use', 'share' ); ?>
	</div>
<?php endif; ?>
<!-- End share button -->
<!-- Start Featured lists -->
<?php if ( get_theme_mod( '__show_featured_list', 'show' ) === 'show' ) : ?>
	<section class="pli-0 sm:pli-4 lg:pli-5 kira-grid-featured justify-around gap-y-5 w-full gap-x-4 mlb-2 sm:mlb-5 lg:mlb-10" style="--column:<?php Render::active_featured(); ?>;">
		<?php Render::featured(); ?>
	</section>
<?php endif; ?>
<!-- after featured ads -->
<?php do_action( 'kiranime_show_ads', '__ads_after_featured' ); ?>
<!-- end featured ads -->
<!-- listing and sidebar -->
<section class="lg:flex justify-between md:pli-5 gap-5 sm:pli-4">

	<!-- main listing -->
	<section class="pli-2 lg:pli-0 <?php echo get_theme_mod( '__show_sidebar', 'show' ) === 'show' ? 'lg:w-3/4' : 'w-full'; ?>">
		<?php dynamic_sidebar( 'homepage-main-list' ); ?>
	</section>
	<!-- end main listing -->
	<?php if ( get_theme_mod( '__show_sidebar', 'show' ) === 'show' ) : ?>
		<!-- main sidebar -->
		<aside class="lg:w-1/4 pbe-2 pli-2 lg:pli-0">
			<?php dynamic_sidebar( 'homepage-sidebar' ); ?>
		</aside>
		<!-- end sidebar -->
	<?php endif; ?>
</section>
