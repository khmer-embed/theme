<?php

$use_schema = get_option( '__a_show_video_meta', '1' ) === '1';
$episode    = new Episode( get_the_ID() );
$episode
	->gets( MetaPrefix::episode )
	->get_taxonomies( 'episode_type' )->get_featured( type: KiraType::episode, size: 'full' )
	->get_download()
	->get_streams( KiraType::episode );
if ( $use_schema ) {
	$episode->get_video_meta();
}
$anime = isset( $episode->meta['parent_id'] ) && ! empty( $episode->meta['parent_id'] ) ? new Anime( $episode->meta['parent_id'] ) : null;

if ( ! is_null( $anime ) ) {
	$anime->get_featured( type: KiraType::anime, size: 'kirathumb' )->gets( MetaPrefix::anime )->get_taxonomies( 'type', 'anime_attribute', 'status' )->get_episodes( false, -1 )->get_votes()->get_scheduled();
}

$set_history = [
	'anime'       => $anime?->post?->post_title,
	/* translators: episode number */
	'number'      => sprintf( __( 'Episode %d', 'kiranime' ), $episode->meta['number'] ),
	'anime_url'   => $anime?->url,
	'image'       => isset( $episode->images['featured_html'] ) && ! empty( $episode->images['featured_html'] ) ? $episode->images['featured_html'] : $anime?->images['featured_html'],
	'episode_url' => $episode->url,
	'id'          => $episode->id,
];

if ( $use_schema ) {
	echo $episode->video_meta;
}
?>
<script>
	var current_post_data_id = <?php echo $anime?->id ?? 0; ?>;
	var history_add_data = "<?php echo base64_encode( json_encode( $set_history ) ); ?>";
</script>
<section role="heading" class="relative h-full min-h-100 lg:pbs-17 pbe-5">
	<div class="bg-cover bg-center opacity-30 blur-xl absolute inset-0 z-0" style="background-image: url('<?php echo esc_url( ! empty( $episode->images['featured_url'] ) ? $episode->images['featured_url'] : $anime?->images['featured_url'] ); ?>')">
	</div>
	<?php
	Kira_Utility::show(
		'template-parts/sections/component/episode',
		'player-section',
		[
			'episode' => $episode,
			'anime'   => $anime,
		]
	);
	?>
</section>
<section class="w-full max-[120rem] mli-auto">
	<?php if ( get_theme_mod( '__show_share_button', 'show' ) === 'show' ) : ?>
		<div class=" w-full lg:pli-10 plb-5 bg-darkest relative flex gap-5  items-end">
			<div class="w-6/12 lg:w-2/12 pis-5 before:absolute before:hidden lg:before:block before:inset-0 before:h-full before:w-0.5 before:bg-accent-3 relative">
				<span class="text-sm font-semibold block">
					<?php esc_html__( 'Share This Anime', 'kiranime' ); ?>
				</span>
				<span class="block text-xs font-light">
					<?php esc_html__( 'to your friends!', 'kiranime' ); ?>
				</span>
			</div>
			<?php Kira_Utility::show( 'template-parts/sections/component/use', 'share' ); ?>
		</div>
	<?php endif; ?>
	<!-- ads before episode body -->
	<?php do_action( 'kiranime_show_ads', '__ads_before_body_episode' ); ?>
	<!-- end before episode body -->
	<div class="lg:flex gap-10 lg:pli-10 pli-4 md:pli-5 plb-10">
		<section class="flex-auto lg:w-9/12 w-full">
			<!-- start download -->
			<?php
			if ( get_theme_mod( '__show_download_episode', 'show' ) === 'show' ) :
				Kira_Utility::show( 'template-parts/sections/component/use', 'download', [ 'downloads' => $episode->download ] );
			endif;
			?>
			<!-- end download -->
			<!-- Start comments -->
			<div class="plb-5 mlb-5">
				<?php
				// If comments are open or we have at least one comment, load up the comment template.
				if ( comments_open() || get_comments_number() ) :
					comments_template();
				endif;
				?>
			</div>
			<!-- end comments -->
			<!-- Start Recomended Anime -->
			<?php
			if ( get_theme_mod( '__show_related_episode', 'show' ) === 'show' ) :
				Kira_Utility::show(
					'template-parts/sections/component/use',
					'recommended',
					[
						'post_type' => 'episode',
						'id'        => $anime?->id,
					]
				);
			endif;
			?>
			<!-- End Recomended Anime -->
		</section>
		<aside class="w-full lg:w-3/12 flex-shrink-0 min-h-300 plb-4 mbs-5 lg:mbs-0">
			<?php
			if ( is_active_sidebar( 'anime-info-sidebar' ) ) :
				dynamic_sidebar( 'anime-info-sidebar' );
			endif;
			?>
		</aside>
	</div>
</section>
