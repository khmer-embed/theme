<?php

$anime = new Anime( get_the_ID() );

$anime
	->get_featured( type: KiraType::anime, size: 'featuredthumb' )
	->gets( MetaPrefix::anime )
	->get_background( type: KiraType::anime, attr: [ 'class' => 'object-cover h-full w-full' ] )
	->get_taxonomies( 'type', 'anime_attribute', 'producer', 'licensor', 'studio', 'genre' )
	->get_season()
	->get_episodes( false, get_theme_mod( '__show_episode_count', '-1' ) )
	->get_download();

$latest        = $anime->get_episodes( is_latest: true, return: true );
$first_episode = $anime->get_episodes( is_latest:false, count: 1, asc: true, return: true );
$total_views   = Kira_Utility::get_view_count( $anime->get( 'total_kiranime_views', true ) );
$meta          = $anime->meta;
$current_type  = $anime->taxonomies['type'];
$attr          = $anime->taxonomies['anime_attribute'];
$season_list   = $anime->seasons;
$en_title      = $anime?->meta['english'];
$current_title = $anime?->post?->post_title;

$show_meta = array_filter( $meta, fn ( $val ) => ! in_array( $val, [ 'spotlight', 'updated', 'voted', 'voted_by', 'vote_score', 'featured', 'characters', 'title', 'background', 'name', 'service_name', 'id', 'trailer' ] ), ARRAY_FILTER_USE_KEY );

$taxs = [
	'genre'    => [
		'name' => __( 'Genre', 'kiranime' ),
		'data' => array_map(
			function ( $v ) {
				return [
					'name' => $v->name,
					'url'  => get_term_link( $v ),
				];
			},
			$anime->taxonomies['genre'] ? $anime->taxonomies['genre'] : []
		),
	],
	'studio'   => [
		'name' => __( 'Studio', 'kiranime' ),
		'data' => array_map(
			function ( $v ) {
				return [
					'name' => $v->name,
					'url'  => get_term_link( $v ),
				];
			},
			$anime->taxonomies['studio'] ? $anime->taxonomies['studio'] : []
		),
	],
	'licensor' => [
		'name' => __( 'Licensor', 'kiranime' ),
		'data' => array_map(
			function ( $v ) {
				return [
					'name' => $v->name,
					'url'  => get_term_link( $v ),
				];
			},
			$anime->taxonomies['licensor'] ? $anime->taxonomies['licensor'] : []
		),
	],
	'producer' => [
		'name' => __( 'Producer', 'kiranime' ),
		'data' => array_map(
			function ( $v ) {
				return [
					'name' => $v->name,
					'url'  => get_term_link( $v ),
				];
			},
			$anime->taxonomies['producer'] ? $anime->taxonomies['producer'] : []
		),
	],
];
$img  = $anime->meta;
$tags = wp_get_post_tags( get_the_ID() );
?>
<script>
	const current_post_data_id = <?php echo get_the_ID(); ?>;
</script>
<div class="relative h-full min-h-100 pbs-[70px] md:pbs-[140px] pbe-17">

	<div class="opacity-30 blur-xl absolute inset-0 z-0 overflow-hidden background-image">
		<?php echo $anime->images['background_html'] ? $anime->images['background_html'] : str_ireplace( 'class="', 'class="object-cover h-full w-full ', $anime->images['featured_html'] ); ?>
	</div>
	<div class="xl:pis-16 plb-4 md:pli-5 w-full xl:w-9/12 h-auto flex flex-col sm:flex-row items-center justify-center sm:items-start sm:justify-start gap-10 z-10 relative sm:mbe-10 lg:mbe-0">
		<div class="anime-image">
			<?php echo $anime->images['featured_html']; ?>
		</div>
		<div class="xl:w-full w-full sm:w-3/4 md:pie-0 lg:pie-10 text-center sm:text-start">
			<!-- breadcrumb -->
			<?php
			if ( function_exists( 'rank_math_the_breadcrumbs' ) ) :
				rank_math_the_breadcrumbs();
			else :
				?>
				<nav aria-label="Breadcrumb" class="text-xs font-medium mbe-5 hidden lg:block">
					<ol class="flex gap-2 items-center flex-wrap">
						<li>
							<a href="/">
								<?php esc_html_e( 'Home', 'kiranime' ); ?>
							</a>
						</li>
						<?php if ( $current_type && $current_type[0] ) { ?>
							<span class="material-icons-round text-lg rtl:rotate-180">
								arrow_right
							</span>
							<li>
								<a class="uppercase" href="<?php echo esc_url( get_term_link( $current_type[0] ) ); ?>">
									<?php echo esc_html( $current_type[0]->name ); ?>
								</a>
							</li>
						<?php } ?>
						<span class="material-icons-round text-lg rtl:rotate-180">
							arrow_right
						</span>
						<li>
							<a href="<?php the_permalink(); ?>" aria-current="page" class="text-accent">
								<?php the_title(); ?>
							</a>
						</li>
					</ol>
				</nav>
			<?php endif; ?>
			<h1 class="md:text-4xl text-xl leading-tight font-medium mbe-5 md:text-start text-center">
				<?php if ( ! empty( $en_title ) ) : ?>
					<span data-en-title class="anime"><?php echo esc_html( $en_title ); ?></span>
					<span data-nt-title class="show anime"><?php echo esc_html( $current_title ); ?></span>
				<?php else : ?>
					<?php echo esc_html( $current_title ); ?>
				<?php endif; ?>
			</h1>
			<ul class="flex items-center justify-center flex-wrap lg:flex-nowrap sm:justify-start gap-0.5 mbe-7 anime-metadata">
				<?php
				if ( ! empty( $meta['rate'] ) ) :
					$current_rate = explode( ' ', $meta['rate'] );
					?>
					<li>
						<span><?php echo esc_html( $current_rate[0] ); ?></span>
					</li>
				<?php endif; ?>
				<?php
				if ( ! is_wp_error( $attr ) ) :
					foreach ( $attr as $att ) :
						?>
						<li>
							<span>
								<?php echo esc_html( $att->name ); ?>
							</span>
						</li>
									<?php
				endforeach;
				endif;
				?>
				<?php if ( $current_type && $current_type[0] ) : ?>
					<li>
						<a class="uppercase" href="<?php echo esc_url( get_term_link( $current_type[0] ) ); ?>">
							<?php echo esc_html( $current_type[0]->name ); ?>
						</a>
					</li>
				<?php else : ?>
					<li>
						<a href="/anime-type/tv">
							TV
						</a>
					</li>
					<?php
				endif;
				if ( ! empty( $latest ) ) :
					?>
					<li>
						<a href="<?php echo esc_url( $latest->url ); ?>">
						<?php /* Translators: Episode Number */ printf( esc_html__( 'E %s', 'kiranime' ), ! empty( $latest->meta['number'] ) ? esc_html( $latest->meta['number'] ) : '?' ); ?>
						</a>
					</li>
				<?php endif; ?>
				<li>
					<span>
					<?php /* Translators: Anime duration */ printf( esc_html__( '%sM', 'kiranime' ), number_format_i18n( floatval( preg_replace( '/[^0-9]/mi', '', $meta['duration'] ?? '24' ) ) ) ); ?>
					</span>
				</li>
				<li>
					<span class="!flex items-center">
						<svg xmlns="http://www.w3.org/2000/svg" class="w-[1.125rem] h-[1.125rem]" viewBox="0 0 24 24"><path fill="currentColor" d="M17.66 11.2c-.23-.3-.51-.56-.77-.82c-.67-.6-1.43-1.03-2.07-1.66C13.33 7.26 13 4.85 13.95 3c-.95.23-1.78.75-2.49 1.32c-2.59 2.08-3.61 5.75-2.39 8.9c.04.1.08.2.08.33c0 .22-.15.42-.35.5c-.23.1-.47.04-.66-.12a.6.6 0 0 1-.14-.17c-1.13-1.43-1.31-3.48-.55-5.12C5.78 10 4.87 12.3 5 14.47c.06.5.12 1 .29 1.5c.14.6.41 1.2.71 1.73c1.08 1.73 2.95 2.97 4.96 3.22c2.14.27 4.43-.12 6.07-1.6c1.83-1.66 2.47-4.32 1.53-6.6l-.13-.26c-.21-.46-.77-1.26-.77-1.26m-3.16 6.3c-.28.24-.74.5-1.1.6c-1.12.4-2.24-.16-2.9-.82c1.19-.28 1.9-1.16 2.11-2.05c.17-.8-.15-1.46-.28-2.23c-.12-.74-.1-1.37.17-2.06c.19.38.39.76.63 1.06c.77 1 1.98 1.44 2.24 2.8c.04.14.06.28.06.43c.03.82-.33 1.72-.93 2.27"/></svg>	
						<?php echo esc_html( $total_views ); ?>
					</span>
				</li>
			</ul>
			<div class="flex items-center justify-center sm:justify-start gap-2 mbe-5 relative">
				<?php if ( ! empty( $first_episode ) ) : ?>
				<a href="<?php echo $first_episode->url; ?>" class="flex items-center gap-1 text-sm md:text-base justify-center md:justify-start pli-3 md:pli-5 plb-2 bg-accent-3 rounded-full">
					<span class="material-icons-round text-xl">
						play_arrow
					</span>
					<?php esc_html_e( 'Watch Now', 'kiranime' ); ?>
				</a>
				<?php endif; ?>
				<span role="button" data-anime-tippy-add-list="<?php the_ID(); ?>" class="flex items-center cursor-pointer gap-1 text-sm md:text-base justify-center md:justify-start pli-3 md:pli-5 plb-2 bg-gray-50 rounded-full text-primary">
					<span class="material-icons-round text-xl">
						add
					</span>
					<?php esc_html_e( 'Add to List', 'kiranime' ); ?>
				</span>
				<?php if ( ! empty( $anime->meta['trailer'] ) ) : ?>
				<span role="button" onclick="openVideoEmbed('<?php echo esc_url( $anime->meta['trailer'] ); ?>')" class="flex items-center gap-1 text-sm md:text-base justify-center md:justify-start pli-3 md:pli-5 plb-2 bg-accent-3 rounded-full">
					<span class="material-icons-round text-xl">
						play_arrow
					</span>
					<?php esc_html_e( 'Watch Trailer', 'kiranime' ); ?>
				</span>
				<?php endif; ?>
			</div>
			<div class="font-light text-spec hidden sm:block text-start">
				<div data-synopsis class="line-clamp-3 ">
					<?php $content = strip_tags( get_the_content() ); ?>
					<?php echo esc_html( $content ); ?>
				</div>
				<?php if ( strlen( $content ) > 280 ) : ?>
					<span data-more-less data-ismore="true" class="font-medium cursor-pointer">+
						<?php esc_html_e( 'Show more', 'kiranime' ); ?></span>
				<?php endif; ?>
				<div class="mbs-5 flex items-center justify-start flex-wrap">
					<?php
					if ( ! is_wp_error( $tags ) && ! empty( $tags ) ) :
						$tag_len = count( $tags );
						?>
						<strong><?php esc_html_e( 'Tags' ); ?> :</strong> <?php foreach ( $tags as $index => $current_tag ) : ?>
							<a class="mis-1" href="<?php echo esc_url( get_tag_link( $current_tag ) ); ?>">
								<?php echo esc_html( $current_tag->name ); ?>
							</a>
							<?php echo $index < $tag_len - 1 ? ',' : ''; ?>
							<?php
					endforeach;
											endif;
					?>
				</div>
			</div>
			<?php if ( get_theme_mod( '__show_share_button', 'show' ) === 'show' ) : ?>
				<div class="w-full md:plb-5 bg-opacity-100 md:block gap-5 items-end anime-share">
					<div class="md:w-full lg:w-6/12 md:pli-0 text-start pis-5 lg:pis-5 before:absolute before:hidden lg:before:block before:inset-0 before:h-full before:w-0.5 before:bg-accent-3 relative plb-2">
						<span class="text-sm font-semibold md:block text-accent mbe-2 hidden text-start">
							<?php esc_html_e( 'Share This Anime', 'kiranime' ); ?>
						</span>
						<?php Kira_Utility::show( 'template-parts/sections/component/use', 'share' ); ?>
					</div>
				</div>
			<?php endif; ?>
		</div>
	</div>
	<section class="xl:absolute relative xl:top-0 xl:end-0 w-full pli-5 xl:plb-0 xl:max-w-xs bottom-0 bg-gradient-to-b from-white/20 via-white/10 to-transparent xl:w-79 space-y-1 flex flex-col justify-center text-sm font-medium plb-4 md:pli-7">
		<div class="leading-6 sm:hidden">
			<span class="font-semibold mie-1 block"><?php esc_html_e( 'Overview:', 'kiranime' ); ?></span>
			<span class="block w-full max-h-24 overflow-scroll mlb-3 overflow-x-hidden text-xs text-gray-200"><?php echo esc_html( $content ); ?></span>
		</div>
		<section class="max-h-full overflow-auto custom-scrollbar lg:max-h-[70%] lg:mbs-8">
			<ul class="text-[13px]">
				<?php
				foreach ( $show_meta as $dk => $dv ) :
					if ( ! empty( $dv ) ) :
						?>
						<li class="list-none mbe-1">
							<span class="font-semibold mie-1  leading-6">
								<?php echo esc_html( ucfirst( __( $dk, 'kiranime' ) ) ); ?>:
							</span>
							<span class=" font-normal leading-6">
								<?php echo esc_html( is_array( $dv ) ? implode( ', ', $dv ) : $dv ); ?>
							</span>
						</li>
						<?php
				endif;
				endforeach;
				?>
				<?php
				foreach ( $taxs as $tk => $tv ) :
					if ( ! empty( $tv['data'] ) ) :
						?>
						<li class="list-none 
						<?php
						if ( 'genre' === $tk ) {
													echo 'py-2 border-y border-white border-opacity-10';
						}
						?>
												">
							<span class="font-semibold mie-1 leading-6"><?php echo ucfirst( $tv['name'] ); ?>:</span>
							<span class="leading-6">
													<?php
													if ( 'genre' === $tk ) :
														foreach ( $tv['data'] as $ka => $kv ) :
															?>
										<a href="<?php echo esc_url( $kv['url'] ); ?>" class="inline-block rounded-md border border-white hover:border-accent-2 hover:text-accent pli-2 mlb-[1.5px] transition-colors duration-200 ease-in-out border-opacity-30 hover:border-opacity-100">
															<?php echo esc_html( $kv['name'] ); ?>
										</a>
																							<?php
														endforeach;
													elseif ( in_array( $tk, [ 'studio', 'producer' ] ) ) :
														$sc = count( $tv['data'] );
														foreach ( $tv['data'] as $st => $sv ) :
															?>
										<a href="<?php echo esc_url( $sv['url'] ); ?>" class="font-normal leading-6 hover:text-accent transition-colors duration-200 ease-in-out ">
																<?php echo esc_html( $sv['name'] ); ?>
										</a><?php echo $st < $sc - 1 ? ', ' : ''; ?>
															<?php
														endforeach;
													else :
														?>
									<span class="font-normal leading-6">
														<?php
															echo trim(
																implode(
																	', ',
																	array_map(
																		function ( $av ) {
																			return esc_html( $av['name'] );
																		},
																		$tv['data']
																	)
																)
															)
														?>
									</span>
													<?php endif; ?>
							</span>
						</li>
									<?php
				endif;
				endforeach;
				?>
			</ul>
		</section>
	</section>
</div>
<div class="lg:flex gap-10 space-y-5 lg:space-y-0 lg:pli-10 pli-4 md:pli-5 lg:plb-10 plb-5">
	<section class="flex-auto lg:w-9/12 w-full">
		<!-- character list start -->
		<?php
		if ( get_theme_mod( '__show_characters', 'show' ) === 'show' ) :
			Kira_Utility::show( 'template-parts/sections/anime/section', 'characters', [ 'characters' => $anime->meta['characters'] ] );
		endif;
		?>
		<!-- character list end -->
		<!-- ads after character list -->
		<?php do_action( 'kiranime_show_ads', '__ads_after_char_va' ); ?>
		<!-- end after character list -->
		<!-- season list -->
		<?php
		if ( get_theme_mod( '__show_season_list', 'show' ) === 'show' && ( isset( $anime->seasons ) && count( $anime->seasons ) > 1 ) ) :
			Kira_Utility::show( 'template-parts/sections/anime/section', 'season', [ 'animes' => $anime->seasons ] );
		endif;
		?>
		<!-- end season list -->
		<!-- episode list start -->
		<?php
		if ( get_theme_mod( '__show_episode', 'show' ) === 'show' ) :
			Kira_Utility::show(
				'template-parts/sections/anime/episode',
				'use-slider',
				[
					'anime'    => $anime,
					'is_anime' => true,
				]
			);
		endif;
		?>
		<!-- episode list end -->
		<!-- ads after episode list -->
		<?php do_action( 'kiranime_show_ads', '__ads_after_episode_lists' ); ?>
		<!-- end after episode list -->


		<section>
			<!-- start download -->
			<?php
			if ( get_theme_mod( '__show_download_anime', 'show' ) === 'show' ) :
				Kira_Utility::show( 'template-parts/sections/component/use', 'download', [ 'downloads' => $anime->download ] );
			endif;
			?>
			<!-- end download -->
		</section>
		<!-- Start comments -->
		<div class="plb-5 mlb-5">
			<?php
			// If comments are open or we have at least one comment, load up the comment template.
			if ( comments_open() || get_comments_number() ) :
				comments_template();
			endif;
			?>
		</div>
		<!-- end comments -->
		<?php
		if ( get_theme_mod( '__show_related_anime', 'show' ) === 'show' ) :
			Kira_Utility::show(
				'template-parts/sections/component/use',
				'recommended',
				[
					'post_type' => 'anime',
					'id'        => get_the_ID(),
				]
			);
		endif;
		?>
	</section>

	<!-- start second sidebar -->
	<aside class="w-full lg:w-3/12 flex-shrink-0 min-h-300 lg:p-4 plb-0 mbs-5 lg:mbs-0">
		<?php
		if ( is_active_sidebar( 'anime-info-sidebar' ) ) :
			dynamic_sidebar( 'anime-info-sidebar' );
		endif;
		?>
	</aside>
	<!-- end second sidebar -->
</div>
