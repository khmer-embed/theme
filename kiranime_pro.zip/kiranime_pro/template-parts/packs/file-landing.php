<header class="mbs-10 relative lg:max-w-[90vw] plb-5 lg:pli-0 xl:max-w-[85vw] w-full mli-auto">
	<?php if ( has_nav_menu( 'landing_header' ) ) : ?>
		<div class="hidden md:block menu-header-landing-lg">
			<?php
			wp_nav_menu(
				[
					'theme_location' => 'landing_header',
					'echo'           => true,
				]
			);
			?>
		</div>
		<div class="w-full flex items-center md:hidden">
			<div data-tippy-landing-menu-trigger class="flex items-center justify-center gap-4">
				<svg xmlns="http://www.w3.org/2000/svg" class="w-7 h-7" viewBox="0 0 448 512" fill="currentColor">
					<path d="M0 96C0 78.33 14.33 64 32 64H416C433.7 64 448 78.33 448 96C448 113.7 433.7 128 416 128H32C14.33 128 0 113.7 0 96zM0 256C0 238.3 14.33 224 32 224H416C433.7 224 448 238.3 448 256C448 273.7 433.7 288 416 288H32C14.33 288 0 273.7 0 256zM416 448H32C14.33 448 0 433.7 0 416C0 398.3 14.33 384 32 384H416C433.7 384 448 398.3 448 416C448 433.7 433.7 448 416 448z" />
				</svg>
				Menu
			</div>
			<div data-tippy-landing-menu class="bg-primary rounded-b-md">
				<?php
				wp_nav_menu(
					[
						'theme_location' => 'landing_header',
						'echo'           => true,
					]
				);
				?>
			</div>
		</div>
	<?php endif; ?>
</header>
<main class="relative flex items-center overflow-hidden top-landing">
	<?php if ( get_theme_mod( '__landing_bg' ) ) : ?>
		<div class="-z-20 absolute -inset-4 bg-cover" style="background-image: url('<?php echo get_theme_mod( '__landing_bg' ); ?>');background-position: 50% 25%;">
		</div>
	<?php endif; ?>
	<div class="-z-10 w-full h-full absolute inset-0 bg-gradient-to-b from-transparent via-accent-3/20 ">

	</div>
	<div class="lg:max-w-[1200px] plb-10 lg:pli-0 w-full pli-4 flex items-center relative mbs-8 mbe-5 mli-auto min-h-[60vh]">
		<div class="lg:w-8/12 w-full min-h-full pbe-5 mlb-5">
			<a href="/" id="logo" class="h-auto mli-0 pbe-5 w-79 flex items-center justify-center md:block overflow-hidden max-w-full">
				<?php
				if ( has_custom_logo() ) {
					the_custom_logo();
				} else {
					echo get_bloginfo( 'name' );
				}
				?>
			</a>
			<div class="z-0 gap-5">
				<form action="<?php echo Kira_Utility::page_link( 'pages/search.php' ); ?>" method="GET" autocomplete="off" class="w-full flex items-center justify-between gap-4">
					<input type="text" name="s_keyword" placeholder="<?php esc_attr_e( 'Search Anime Here...', 'kiranime' ); ?>" class="pli-4 plb-3 lg:pli-5 lg:plb-4 w-10/12 bg-white text-slate-800 rounded-full outline-none border-none focus:ring ring-accent-3 placeholder:text-slate-700">
					<button aria-label="<?php esc_attr_e( 'Search Anime Here...', 'kiranime' ); ?>" data-landing-search class="flex items-center justify-center cursor-pointer text-text-color p-3 lg:p-[1.15rem] rounded-full bg-accent-2">
						<svg xmlns="http://www.w3.org/2000/svg" class="w-6 h-6" fill="currentColor" viewBox="0 0 512 512">
							<path d="M500.3 443.7l-119.7-119.7c27.22-40.41 40.65-90.9 33.46-144.7C401.8 87.79 326.8 13.32 235.2 1.723C99.01-15.51-15.51 99.01 1.724 235.2c11.6 91.64 86.08 166.7 177.6 178.9c53.8 7.189 104.3-6.236 144.7-33.46l119.7 119.7c15.62 15.62 40.95 15.62 56.57 0C515.9 484.7 515.9 459.3 500.3 443.7zM79.1 208c0-70.58 57.42-128 128-128s128 57.42 128 128c0 70.58-57.42 128-128 128S79.1 278.6 79.1 208z" />
						</svg>
					</button>
				</form>
			</div>
			<div class="h-max w-full mbs-5">
				<span class="font-semibold text-sm min-w-max leading-6 mie-2">
					<?php esc_html_e( 'Top Anime:', 'kiranime' ); ?>
				</span>
				<?php
				$top = new Kira_Query(
					[
						'orderby'       => 'meta_value_num',
						'meta_key'      => gmdate( 'FY' ) . '_kiranime_views',
						'meta_value'    => 0,
						'meta_compare'  => '>',
						'no_found_rows' => true,
					]
				);
				if ( ! $top->empty ) :
					foreach ( $top->animes as $anime ) :
						?>

						<a href="<?php echo $anime->url; ?>" class="font-normal text-gray-300 inline-block hover:text-accent text-sm leading-6 mie-2">
												<?php echo strlen( $anime->post->post_title ) > 30 ? substr( $anime->post->post_title, 0, 30 ) . '...' : $anime->post->post_title; ?>,
						</a>
									<?php
				endforeach;
				endif;
				?>
			</div>
		</div>
		<?php if ( get_theme_mod( '__landing_char_image' ) ) : ?>
			<img src="<?php echo get_theme_mod( '__landing_char_image' ); ?>" alt="" class="absolute inset-y-0 end-0 w-72 h-auto pbe-5 hidden lg:block">
		<?php endif; ?>
	</div>

</main>
<section class="lg:max-w-[1200px] plb-5 lg:pli-0 mli-auto w-full">
	<a class="w-full text-lg font-medium flex items-center justify-center bg-accent-4 hover:bg-accent-3 rounded-b-[3rem] plb-5 xxl:plb-8 3xl:plb-10" href="<?php echo Kira_Utility::page_link( 'pages/homepage.php' ); ?>">
		<?php esc_html_e( 'View Full Site', 'kiranime' ); ?>
		<svg xmlns="http://www.w3.org/2000/svg" class="w-6 h-6 mis-5 rtl:hidden" fill="currentColor" viewBox="0 0 448 512">
			<path d="M438.6 278.6l-160 160C272.4 444.9 264.2 448 256 448s-16.38-3.125-22.62-9.375c-12.5-12.5-12.5-32.75 0-45.25L338.8 288H32C14.33 288 .0016 273.7 .0016 256S14.33 224 32 224h306.8l-105.4-105.4c-12.5-12.5-12.5-32.75 0-45.25s32.75-12.5 45.25 0l160 160C451.1 245.9 451.1 266.1 438.6 278.6z" />
		</svg>
	</a>
</section>
<?php if ( get_theme_mod( '__show_news_landing' ) ) : ?>
	<section class="lg:max-w-[1200px] plb-5 lg:pli-0 mli-auto w-full mbs-10">
		<h3 class="text-xl w-full font-medium text-center"><?php _e( 'Anime News', 'kiranime' ); ?></h3>
		<div class="mbs-5">
			<?php
			$current_posts = new Kira_Query(
				[
					'post_type'   => 'post',
					'post_status' => 'publish',
				],
				'post'
			);
			foreach ( $current_posts->posts as $current_post ) :
				?>
				<div class="w-full lg:flex gap-10 plb-5 border-b border-gray-400 border-opacity-75">
					<a href="<?php echo get_the_permalink( $current_post ); ?>" class="w-full lg:w-1/4 lg:min-w-25 h-auto max-h-60 lg:max-h-full ">
						<img src="<?php echo get_the_post_thumbnail_url( $current_post->ID, 'full' ); ?>" alt="<?php echo esc_attr( $current_post->post_title ); ?>" class=" object-cover w-full h-full">
					</a>
					<div class="w-full lg:w-3/4 space-y-5 lg:space-y-2 mbs-5 lg:mbs-0">
						<a href="<?php echo get_the_permalink( $current_post ); ?>">
							<h3 class="text-2xl font-semibold"><?php echo esc_html( $current_post->post_title ); ?></h3>
						</a>
						<div class="text-sm font-normal">
							<?php echo wp_trim_excerpt( '', $current_post ); ?>
						</div>
						<span class="inline-block text-sm text-accent">
							<?php
							$time = Kira_Utility::get_relative_time( get_the_time( 'U', $current_post ) );
							/* translators: time. */
							printf( esc_html__( '%1$s Ago.' ), $time )
							?>
						</span>
					</div>
				</div>
			<?php endforeach; ?>
		</div>
	</section>
<?php endif; ?>
